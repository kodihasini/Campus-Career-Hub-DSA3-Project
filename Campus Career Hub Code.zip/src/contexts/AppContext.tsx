import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { format } from 'date-fns';
import { jobs as seedJobs } from '../data/jobs';
import { seedApplications } from '../data/applications';
import { portfolioProjects } from '../data/projects';
import { recruiter } from '../data/recruiter';
import { sampleResume, targetRoles } from '../data/resume';
import { analyzeResume } from '../utils/resume';
import type { Application, Job } from '../types/jobs';
import type { Project } from '../types/portfolio';

export type Role = 'student' | 'recruiter';

export interface ResumeSummary {
  score: number;
  roleTitle: string;
  missing: string[];
}

export type NewJob = Omit<Job, 'id' | 'postedAt' | 'company'>;
export type NewProject = Omit<Project, 'id' | 'stars' | 'updated'>;

interface AppState {
  role: Role | null;
  signIn: (role: Role) => void;
  signOut: () => void;
  jobs: Job[];
  postJob: (job: NewJob) => Job;
  applications: Application[];
  apply: (jobId: string) => void;
  projects: Project[];
  addProject: (project: NewProject) => void;
  shortlist: Record<string, string[]>;
  toggleShortlist: (jobId: string, studentId: string) => boolean;
  resumeSummary: ResumeSummary | null;
  setResumeSummary: (summary: ResumeSummary) => void;
}

const AppContext = createContext<AppState | null>(null);

const initialAnalysis = analyzeResume(sampleResume, targetRoles[0]);

export function AppProvider({ initialRole, children }: {initialRole: Role | null;children: ReactNode;}) {
  const [role, setRole] = useState<Role | null>(initialRole);
  const [jobs, setJobs] = useState<Job[]>(seedJobs);
  const [applications, setApplications] = useState<Application[]>(seedApplications);
  const [projects, setProjects] = useState<Project[]>(portfolioProjects);
  const [shortlist, setShortlist] = useState<Record<string, string[]>>({ j1: ['s3'] });
  const [resumeSummary, setResumeSummary] = useState<ResumeSummary | null>({
    score: initialAnalysis.score,
    roleTitle: targetRoles[0].title,
    missing: initialAnalysis.missingSkills
  });

  const postJob = useCallback((input: NewJob) => {
    const job: Job = { ...input, id: `j${Date.now()}`, company: recruiter.company, postedAt: 'Just now' };
    setJobs((prev) => [job, ...prev]);
    return job;
  }, []);

  const apply = useCallback((jobId: string) => {
    setApplications((prev) =>
    prev.some((a) => a.jobId === jobId) ?
    prev :
    [{ jobId, status: 'Applied', appliedAt: format(new Date(), 'MMM d') }, ...prev]
    );
  }, []);

  const addProject = useCallback((input: NewProject) => {
    setProjects((prev) => [
    { ...input, id: `p${Date.now()}`, stars: 0, updated: format(new Date(), 'MMM d, yyyy') },
    ...prev]
    );
  }, []);

  const toggleShortlist = useCallback(
    (jobId: string, studentId: string) => {
      const current = shortlist[jobId] ?? [];
      const adding = !current.includes(studentId);
      setShortlist((prev) => {
        const list = prev[jobId] ?? [];
        return { ...prev, [jobId]: adding ? [...list, studentId] : list.filter((id) => id !== studentId) };
      });
      return adding;
    },
    [shortlist]
  );

  const value = useMemo<AppState>(
    () => ({
      role,
      signIn: setRole,
      signOut: () => setRole(null),
      jobs,
      postJob,
      applications,
      apply,
      projects,
      addProject,
      shortlist,
      toggleShortlist,
      resumeSummary,
      setResumeSummary
    }),
    [role, jobs, postJob, applications, apply, projects, addProject, shortlist, toggleShortlist, resumeSummary]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppState {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}