import React from 'react';

interface FitMeterProps {
  score: number;
  showLabel?: boolean;
}

export function FitMeter({ score, showLabel = true }: FitMeterProps) {
  const tone = score >= 75 ? 'bg-success' : score >= 50 ? 'bg-warning' : 'bg-muted/50';
  return (
    <div className="w-28" aria-label={`Skill fit ${score}%`}>
      <div className="flex items-baseline justify-between">
        {showLabel && <span className="text-xs text-muted">Skill fit</span>}
        <span className="ml-auto text-sm font-semibold tabular-nums text-ink">{score}%</span>
      </div>
      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-subtle">
        <div className={`h-full rounded-full ${tone}`} style={{ width: `${score}%` }} />
      </div>
    </div>);

}