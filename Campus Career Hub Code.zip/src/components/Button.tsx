import React from 'react';

type Variant = 'primary' | 'secondary' | 'ghost';
type Size = 'sm' | 'md';

export function buttonStyles(variant: Variant = 'primary', size: Size = 'md'): string {
  const base =
  'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg font-medium transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/30 focus-visible:ring-offset-1 disabled:cursor-not-allowed disabled:opacity-60';
  const sizes: Record<Size, string> = { sm: 'h-8 px-3 text-sm', md: 'h-10 px-4 text-sm' };
  const variants: Record<Variant, string> = {
    primary: 'bg-brand text-white hover:bg-brand-hover',
    secondary: 'border border-line bg-surface text-ink hover:bg-subtle',
    ghost: 'text-body hover:bg-subtle hover:text-ink'
  };
  return `${base} ${sizes[size]} ${variants[variant]}`;
}

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

export function Button({ variant = 'primary', size = 'md', className = '', type = 'button', ...rest }: ButtonProps) {
  return <button type={type} className={`${buttonStyles(variant, size)} ${className}`} {...rest} />;
}