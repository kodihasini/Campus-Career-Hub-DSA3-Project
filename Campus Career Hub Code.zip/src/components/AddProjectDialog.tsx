import React, { useState } from 'react';
import { toast } from 'sonner';
import { Button } from './Button';
import { Dialog } from './Dialog';
import { Field, inputClass } from './Field';
import { useApp } from '../contexts/AppContext';

interface AddProjectDialogProps {
  open: boolean;
  onClose: () => void;
}

export function AddProjectDialog({ open, onClose }: AddProjectDialogProps) {
  const { addProject } = useApp();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [tech, setTech] = useState('');
  const [repo, setRepo] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const reset = () => {
    setTitle('');
    setDescription('');
    setTech('');
    setRepo('');
    setErrors({});
  };

  const close = () => {
    reset();
    onClose();
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!title.trim()) next.title = 'Give your project a name.';
    if (description.trim().length < 20) next.description = 'Describe it in at least 20 characters.';
    const cleanRepo = repo.trim().replace(/^https?:\/\//, '');
    if (!/^github\.com\/[\w.-]+\/[\w.-]+$/.test(cleanRepo)) next.repo = 'Use a GitHub link like github.com/you/project.';
    setErrors(next);
    if (Object.keys(next).length) return;

    addProject({
      title: title.trim(),
      description: description.trim(),
      tech: tech.split(',').map((t) => t.trim()).filter(Boolean),
      repo: cleanRepo
    });
    toast.success('Project added to your portfolio');
    close();
  };

  return (
    <Dialog open={open} onClose={close} title="Add a project" description="Recruiters see this on your public portfolio.">
      <form onSubmit={submit} className="space-y-4" noValidate>
        <Field label="Project name" htmlFor="p-title" error={errors.title}>
          <input id="p-title" className={inputClass} value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label="What it does" htmlFor="p-desc" error={errors.description}>
          <textarea
            id="p-desc"
            rows={3}
            className={`${inputClass} h-auto resize-none py-2`}
            value={description}
            onChange={(e) => setDescription(e.target.value)} />
          
        </Field>
        <Field label="Tech used" htmlFor="p-tech" hint="Separate with commas, e.g. React, FastAPI">
          <input id="p-tech" className={inputClass} value={tech} onChange={(e) => setTech(e.target.value)} />
        </Field>
        <Field label="GitHub repository" htmlFor="p-repo" error={errors.repo}>
          <input
            id="p-repo"
            className={inputClass}
            placeholder="github.com/hasini-k/project"
            value={repo}
            onChange={(e) => setRepo(e.target.value)} />
          
        </Field>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={close}>
            Cancel
          </Button>
          <Button type="submit">Add project</Button>
        </div>
      </form>
    </Dialog>);

}