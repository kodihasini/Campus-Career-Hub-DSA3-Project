import React from 'react';
import { ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
import { Button } from './Button';
import { Drawer } from './Drawer';
import { Highlight } from './Highlight';
import { getDoc } from '../utils/notesSearch';

interface PagePreviewProps {
  target: {docId: string;page: number;} | null;
  terms: string[];
  onChange: (target: {docId: string;page: number;} | null) => void;
}

export function PagePreview({ target, terms, onChange }: PagePreviewProps) {
  const doc = target ? getDoc(target.docId) : undefined;
  const page = target?.page ?? 1;
  const total = doc?.pages.length ?? 0;

  return (
    <Drawer
      open={Boolean(doc)}
      onClose={() => onChange(null)}
      title={doc?.title ?? ''}
      footer={
      doc &&
      <div className="flex items-center justify-between">
            <Button
          variant="secondary"
          size="sm"
          disabled={page <= 1}
          onClick={() => onChange({ docId: doc.id, page: page - 1 })}>
          
              <ChevronLeftIcon className="h-4 w-4" aria-hidden="true" />
              Previous
            </Button>
            <span className="text-sm tabular-nums text-muted">
              Page {page} of {total}
            </span>
            <Button
          variant="secondary"
          size="sm"
          disabled={page >= total}
          onClick={() => onChange({ docId: doc.id, page: page + 1 })}>
          
              Next
              <ChevronRightIcon className="h-4 w-4" aria-hidden="true" />
            </Button>
          </div>

      }>
      
      {doc &&
      <div>
          <p className="text-sm text-muted">
            {doc.course} · {doc.kind}
          </p>
          <div className="mt-6 rounded-xl border border-line bg-canvas p-6">
            <p className="mb-4 text-xs font-medium tabular-nums text-muted">Page {page}</p>
            <p className="text-[15px] leading-7 text-ink">
              <Highlight text={doc.pages[page - 1]} terms={terms} />
            </p>
          </div>
        </div>
      }
    </Drawer>);

}