import React from 'react';
import { CheckIcon, ClockIcon, MapPinIcon, WalletIcon } from 'lucide-react';
import { Button } from './Button';
import { FitMeter } from './FitMeter';
import { SkillTag } from './SkillTag';
import type { FitResult, Job } from '../types/jobs';

interface JobRowProps {
  job: Job;
  fit: FitResult;
  applied: boolean;
  onApply: (job: Job) => void;
  compact?: boolean;
}

export function JobRow({ job, fit, applied, onApply, compact = false }: JobRowProps) {
  return (
    <article className="flex flex-col gap-4 p-5 sm:flex-row sm:items-start sm:justify-between">
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <h3 className="text-[15px] font-semibold text-ink">{job.title}</h3>
          <span className="rounded-md bg-subtle px-1.5 py-0.5 text-xs font-medium text-body">{job.type}</span>
        </div>
        <p className="mt-0.5 text-sm text-body">
          {job.company} <span className="text-muted">· {job.postedAt}</span>
        </p>
        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted">
          <span className="inline-flex items-center gap-1.5">
            <MapPinIcon className="h-3.5 w-3.5" aria-hidden="true" />
            {job.location}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <ClockIcon className="h-3.5 w-3.5" aria-hidden="true" />
            {job.hours}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <WalletIcon className="h-3.5 w-3.5" aria-hidden="true" />
            {job.pay}
          </span>
        </div>
        {!compact && <p className="mt-3 max-w-xl text-sm leading-relaxed text-body">{job.description}</p>}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {job.skills.map((skill) =>
          <SkillTag key={skill} label={skill} variant={fit.matched.includes(skill) ? 'matched' : 'missing'} />
          )}
        </div>
      </div>
      <div className="flex shrink-0 items-center justify-between gap-4 sm:flex-col sm:items-end">
        <FitMeter score={fit.score} />
        {applied ?
        <span className="inline-flex h-8 items-center gap-1.5 px-1 text-sm font-medium text-success">
            <CheckIcon className="h-4 w-4" aria-hidden="true" />
            Applied
          </span> :

        <Button size="sm" onClick={() => onApply(job)}>
            Apply
          </Button>
        }
      </div>
    </article>);

}