import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import type { Role } from '../contexts/AppContext';

export function RequireRole({ role }: {role: Role;}) {
  const { role: current } = useApp();
  if (!current) return <Navigate to="/login" replace />;
  if (current !== role) return <Navigate to={current === 'recruiter' ? '/recruiter' : '/'} replace />;
  return <Outlet />;
}