import React from 'react';
import type { ApplicationStatus } from '../types/jobs';

export function StatusPill({ status }: {status: ApplicationStatus;}) {
  const styles: Record<ApplicationStatus, string> = {
    Applied: 'bg-subtle text-body',
    'Under review': 'bg-warning-soft text-warning',
    Shortlisted: 'bg-success-soft text-success',
    Rejected: 'bg-brand-soft text-brand'
  };
  return (
    <span className={`inline-flex h-6 items-center whitespace-nowrap rounded-full px-2.5 text-xs font-medium ${styles[status]}`}>
      {status}
    </span>);

}