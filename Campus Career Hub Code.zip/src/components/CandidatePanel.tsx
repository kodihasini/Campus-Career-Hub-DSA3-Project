import React from 'react';
import { BookmarkCheckIcon, BookmarkIcon, ExternalLinkIcon, GitBranchIcon } from 'lucide-react';
import { Avatar } from './Avatar';
import { Button } from './Button';
import { Drawer } from './Drawer';
import { ScoreRing } from './ScoreRing';
import { SkillTag } from './SkillTag';
import type { Ranked } from '../utils/matching';
import type { Student } from '../types/students';

interface CandidatePanelProps {
  candidate: Ranked<Student> | null;
  shortlisted: boolean;
  onToggleShortlist: (student: Student) => void;
  onClose: () => void;
}

export function CandidatePanel({ candidate, shortlisted, onToggleShortlist, onClose }: CandidatePanelProps) {
  const student = candidate?.item;
  return (
    <Drawer
      open={Boolean(candidate)}
      onClose={onClose}
      title="Candidate profile"
      footer={
      student &&
      <Button
        variant={shortlisted ? 'secondary' : 'primary'}
        className="w-full"
        onClick={() => onToggleShortlist(student)}>
        
            {shortlisted ? <BookmarkCheckIcon className="h-4 w-4" /> : <BookmarkIcon className="h-4 w-4" />}
            {shortlisted ? 'Remove from shortlist' : 'Shortlist candidate'}
          </Button>

      }>
      
      {candidate && student &&
      <div className="space-y-8">
          <div className="flex items-center gap-4">
            <Avatar initials={student.initials} size="lg" />
            <div className="min-w-0">
              <p className="text-lg font-semibold text-ink">{student.name}</p>
              <p className="text-sm text-body">{student.headline}</p>
              <p className="mt-0.5 text-sm text-muted">
                {student.branch} · Year {student.year}
              </p>
            </div>
          </div>

          <section>
            <div className="flex items-baseline justify-between">
              <h3 className="text-sm font-semibold text-ink">Skill fit for this role</h3>
              <span className="text-2xl font-semibold tabular-nums text-ink">{candidate.fit.score}%</span>
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {candidate.fit.matched.map((s) =>
            <SkillTag key={s} label={s} variant="matched" />
            )}
              {candidate.fit.missing.map((s) =>
            <SkillTag key={s} label={s} variant="missing" />
            )}
            </div>
          </section>

          <section className="flex items-center gap-4 rounded-xl border border-line p-4">
            <ScoreRing score={student.atsScore} size={64} stroke={6} />
            <div>
              <p className="text-sm font-semibold text-ink">Resume ATS score</p>
              <p className="text-sm text-muted">Verified by the Campus Career Hub resume analyzer</p>
            </div>
          </section>

          <section>
            <h3 className="text-sm font-semibold text-ink">Portfolio</h3>
            <ul className="mt-3 divide-y divide-line rounded-xl border border-line">
              {student.projects.map((project) =>
            <li key={project.repo} className="flex items-center justify-between gap-3 p-4">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-ink">{project.title}</p>
                    <p className="mt-0.5 truncate text-xs text-muted">{project.tech.join(' · ')}</p>
                  </div>
                  <a
                href={`https://${project.repo}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex shrink-0 items-center gap-1.5 text-sm font-medium text-brand hover:text-brand-hover">
                
                    <GitBranchIcon className="h-3.5 w-3.5" aria-hidden="true" />
                    Repo
                  </a>
                </li>
            )}
            </ul>
            <a
            href={`https://${student.github}`}
            target="_blank"
            rel="noreferrer"
            className="mt-3 inline-flex items-center gap-1.5 text-sm text-body hover:text-ink">
            
              {student.github}
              <ExternalLinkIcon className="h-3.5 w-3.5" aria-hidden="true" />
            </a>
          </section>

          <section>
            <h3 className="text-sm font-semibold text-ink">All skills</h3>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {student.skills.map((s) =>
            <SkillTag key={s} label={s} />
            )}
            </div>
          </section>
        </div>
      }
    </Drawer>);

}