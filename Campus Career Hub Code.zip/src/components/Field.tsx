import React from 'react';
import type { ReactNode } from 'react';

export const inputClass =
'h-10 w-full rounded-lg border border-line bg-surface px-3 text-sm text-ink placeholder:text-muted/70 transition-colors duration-150 focus:border-brand/50 focus:outline-none focus:ring-2 focus:ring-brand/15';

interface FieldProps {
  label: string;
  htmlFor: string;
  error?: string;
  hint?: string;
  children: ReactNode;
}

export function Field({ label, htmlFor, error, hint, children }: FieldProps) {
  return (
    <div>
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-medium text-ink">
        {label}
      </label>
      {children}
      {error ?
      <p className="mt-1.5 text-xs text-brand" role="alert">
          {error}
        </p> :
      hint ?
      <p className="mt-1.5 text-xs text-muted">{hint}</p> :
      null}
    </div>);

}