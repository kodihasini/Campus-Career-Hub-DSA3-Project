import React from 'react';
import { escapeRegExp } from '../utils/text';

interface HighlightProps {
  text: string;
  terms: string[];
}

export function Highlight({ text, terms }: HighlightProps) {
  if (!terms.length) return <>{text}</>;
  const pattern = new RegExp(
    `\\b(${[...terms].sort((a, b) => b.length - a.length).map(escapeRegExp).join('|')})`,
    'gi'
  );
  const parts = text.split(pattern);
  return (
    <>
      {parts.map((part, i) =>
      i % 2 === 1 ?
      <mark key={i} className="rounded-sm bg-highlight px-0.5 font-medium text-ink">
            {part}
          </mark> :

      <React.Fragment key={i}>{part}</React.Fragment>

      )}
    </>);

}