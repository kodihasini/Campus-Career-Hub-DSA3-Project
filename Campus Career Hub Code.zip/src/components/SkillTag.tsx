import React from 'react';
import { CheckIcon } from 'lucide-react';

interface SkillTagProps {
  label: string;
  variant?: 'matched' | 'missing' | 'neutral';
}

export function SkillTag({ label, variant = 'neutral' }: SkillTagProps) {
  const styles = {
    matched: 'bg-success-soft text-success',
    missing: 'border border-dashed border-brand/40 text-brand',
    neutral: 'bg-subtle text-body'
  }[variant];

  return (
    <span className={`inline-flex h-6 items-center gap-1 whitespace-nowrap rounded-md px-2 text-xs font-medium ${styles}`}>
      {variant === 'matched' && <CheckIcon className="h-3 w-3" aria-hidden="true" />}
      {label}
      {variant === 'missing' && <span className="sr-only">(missing)</span>}
    </span>);

}