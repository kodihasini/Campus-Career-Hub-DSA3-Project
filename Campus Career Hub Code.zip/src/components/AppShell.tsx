import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { BriefcaseIcon, FileTextIcon, FolderOpenIcon, HomeIcon, LogOutIcon, PlusIcon, SearchIcon, UsersIcon, BoxIcon } from "lucide-react";
import { Avatar } from "./Avatar";
import { useApp } from "../contexts/AppContext";
import { currentStudent } from "../data/students";
import { recruiter } from "../data/recruiter";
interface NavItem {
  to: string;
  label: string;
  icon: BoxIcon;
  end?: boolean;
}
const studentNav: NavItem[] = [{
  to: '/',
  label: 'Home',
  icon: HomeIcon,
  end: true
}, {
  to: '/notes',
  label: 'Notes Search',
  icon: SearchIcon
}, {
  to: '/resume',
  label: 'Resume Analyzer',
  icon: FileTextIcon
}, {
  to: '/jobs',
  label: 'Jobs & Internships',
  icon: BriefcaseIcon
}, {
  to: '/portfolio',
  label: 'Portfolio',
  icon: FolderOpenIcon
}];
const recruiterNav: NavItem[] = [{
  to: '/recruiter',
  label: 'Candidates',
  icon: UsersIcon,
  end: true
}, {
  to: '/recruiter/post',
  label: 'Post a job',
  icon: PlusIcon
}];
const linkClass = ({
  isActive


}: {isActive: boolean;}) => `flex h-9 items-center gap-3 whitespace-nowrap rounded-lg px-3 text-sm font-medium transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/30 ${isActive ? 'bg-brand-soft text-brand' : 'text-body hover:bg-subtle hover:text-ink'}`;
function Brand() {
  return <div className="flex items-center gap-2.5">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand text-xs font-bold tracking-tight text-white">
        CH
      </span>
      <div className="leading-tight">
        <p className="text-sm font-semibold text-ink">Campus Career Hub</p>
        <p className="text-[11px] text-muted">KL University Hyderabad</p>
      </div>
    </div>;
}
export function AppShell() {
  const {
    role,
    signOut
  } = useApp();
  const nav = role === 'recruiter' ? recruiterNav : studentNav;
  const user = role === 'recruiter' ? {
    name: recruiter.name,
    sub: `${recruiter.title}, ${recruiter.company}`,
    initials: recruiter.initials
  } : {
    name: currentStudent.name,
    sub: `${currentStudent.branch} · Year ${currentStudent.year}`,
    initials: currentStudent.initials
  };
  return <div className="flex min-h-screen w-full bg-canvas">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-line bg-surface lg:flex">
        <div className="px-5 py-5">
          <Brand />
        </div>
        <nav aria-label="Main" className="flex-1 space-y-0.5 px-3 py-2">
          {nav.map((item) => <NavLink key={item.to} to={item.to} end={item.end} className={linkClass}>
              <item.icon className="h-4 w-4" aria-hidden="true" />
              {item.label}
            </NavLink>)}
        </nav>
        <div className="flex items-center gap-3 border-t border-line p-4">
          <Avatar initials={user.initials} size="sm" />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-ink">{user.name}</p>
            <p className="truncate text-xs text-muted">{user.sub}</p>
          </div>
          <button type="button" onClick={signOut} aria-label="Sign out" className="rounded-md p-1.5 text-muted transition-colors duration-150 hover:bg-subtle hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/30">
            <LogOutIcon className="h-4 w-4" />
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 border-b border-line bg-surface lg:hidden">
          <div className="flex items-center justify-between px-5 py-3">
            <Brand />
            <button type="button" onClick={signOut} className="inline-flex items-center gap-1.5 rounded-md px-2 py-1.5 text-sm text-muted hover:bg-subtle hover:text-ink">
              <LogOutIcon className="h-4 w-4" aria-hidden="true" />
              Sign out
            </button>
          </div>
          <nav aria-label="Main" className="flex gap-1 overflow-x-auto px-3 pb-2">
            {nav.map((item) => <NavLink key={item.to} to={item.to} end={item.end} className={linkClass}>
                <item.icon className="h-4 w-4" aria-hidden="true" />
                {item.label}
              </NavLink>)}
          </nav>
        </header>
        <main className="flex-1 px-5 py-8 sm:px-8 lg:px-12 lg:py-10">
          <div className="mx-auto max-w-6xl">
            <Outlet />
          </div>
        </main>
      </div>
    </div>;
}