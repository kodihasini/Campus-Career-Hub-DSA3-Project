import { notes } from '../data/notes';
import { InvertedIndex } from './invertedIndex';
import { Trie } from './trie';
import { tokenize } from './text';
import type { NoteDoc, SearchHit } from '../types/notes';

const index = new InvertedIndex();
const trie = new Trie();

notes.forEach((doc) => {
  doc.pages.forEach((text, i) => {
    index.addPage(doc.id, i + 1, text).forEach((term) => trie.insert(term));
  });
});

export interface NotesSearchResult {
  hits: SearchHit[];
  ms: number;
  terms: string[];
}

export function suggestTerms(prefix: string, limit = 6): string[] {
  const clean = prefix.toLowerCase().replace(/[^a-z0-9+#]/g, '');
  return clean ? trie.suggest(clean, limit) : [];
}

export function searchNotes(query: string): NotesSearchResult {
  const start = performance.now();
  const tokens = tokenize(query);
  if (!tokens.length) return { hits: [], ms: 0, terms: [] };

  const groups = tokens.map((token) => {
    const group = new Set<string>();
    if (index.has(token)) group.add(token);
    trie.suggest(token, 12).forEach((word) => group.add(word));
    return Array.from(group);
  });

  const hits = index.search(groups);
  return {
    hits,
    ms: performance.now() - start,
    terms: Array.from(new Set(groups.flat()))
  };
}

export function getDoc(id: string): NoteDoc | undefined {
  return notes.find((doc) => doc.id === id);
}