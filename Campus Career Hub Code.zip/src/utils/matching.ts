import { PriorityQueue } from './priorityQueue';
import type { FitResult, Job } from '../types/jobs';
import type { Student } from '../types/students';

export interface Ranked<T> {
  item: T;
  fit: FitResult;
}

const norm = (skill: string) => skill.trim().toLowerCase();

export function computeFit(have: string[], need: string[]): FitResult {
  const owned = new Set(have.map(norm));
  const matched = need.filter((s) => owned.has(norm(s)));
  const missing = need.filter((s) => !owned.has(norm(s)));
  return {
    score: need.length ? Math.round(matched.length / need.length * 100) : 0,
    matched,
    missing
  };
}

function rank<T>(entries: Ranked<T>[], tieBreak: (a: T, b: T) => number): Ranked<T>[] {
  const queue = new PriorityQueue<Ranked<T>>(
    (a, b) =>
    a.fit.score - b.fit.score ||
    a.fit.matched.length - b.fit.matched.length ||
    tieBreak(b.item, a.item)
  );
  entries.forEach((entry) => queue.push(entry));
  const ordered: Ranked<T>[] = [];
  while (queue.size) ordered.push(queue.pop() as Ranked<T>);
  return ordered;
}

export function rankJobsForStudent(skills: string[], jobs: Job[]): Ranked<Job>[] {
  return rank(
    jobs.map((job) => ({ item: job, fit: computeFit(skills, job.skills) })),
    (a, b) => a.title.localeCompare(b.title)
  );
}

/** Traverses a skill → student graph from the required skills, then ranks reachable students by fit. */
export function rankStudentsForJob(skillsNeeded: string[], students: Student[]): Ranked<Student>[] {
  const graph = new Map<string, Set<string>>();
  students.forEach((student) => {
    student.skills.forEach((skill) => {
      const key = norm(skill);
      if (!graph.has(key)) graph.set(key, new Set());
      graph.get(key)?.add(student.id);
    });
  });

  const reachable = new Set<string>();
  skillsNeeded.forEach((skill) => graph.get(norm(skill))?.forEach((id) => reachable.add(id)));

  return rank(
    students.
    filter((s) => reachable.has(s.id)).
    map((s) => ({ item: s, fit: computeFit(s.skills, skillsNeeded) })),
    (a, b) => a.name.localeCompare(b.name)
  );
}