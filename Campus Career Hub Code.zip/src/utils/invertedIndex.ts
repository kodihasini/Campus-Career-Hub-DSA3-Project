import { tokenize } from './text';
import type { SearchHit } from '../types/notes';

type PageCounts = Map<number, number>;

/** term → document → page → occurrence count */
export class InvertedIndex {
  private index = new Map<string, Map<string, PageCounts>>();

  addPage(docId: string, page: number, text: string): string[] {
    const tokens = tokenize(text);
    for (const token of tokens) {
      let docs = this.index.get(token);
      if (!docs) {
        docs = new Map();
        this.index.set(token, docs);
      }
      let pages = docs.get(docId);
      if (!pages) {
        pages = new Map();
        docs.set(docId, pages);
      }
      pages.set(page, (pages.get(page) ?? 0) + 1);
    }
    return tokens;
  }

  has(term: string): boolean {
    return this.index.has(term);
  }

  /** Each group holds alternative terms (a word plus its prefix expansions). A page must match every group. */
  search(groups: string[][]): SearchHit[] {
    let acc: Map<string, SearchHit> | null = null;

    for (const group of groups) {
      const current = new Map<string, SearchHit>();
      for (const term of group) {
        const docs = this.index.get(term);
        if (!docs) continue;
        docs.forEach((pages, docId) => {
          pages.forEach((count, page) => {
            const key = `${docId}:${page}`;
            const hit = current.get(key) ?? { docId, page, score: 0, terms: [] };
            hit.score += count;
            if (!hit.terms.includes(term)) hit.terms.push(term);
            current.set(key, hit);
          });
        });
      }

      if (acc === null) {
        acc = current;
      } else {
        const previous: Map<string, SearchHit> = acc;
        const next = new Map<string, SearchHit>();
        current.forEach((hit, key) => {
          const prev = previous.get(key);
          if (prev) {
            next.set(key, {
              ...prev,
              score: prev.score + hit.score,
              terms: [...prev.terms, ...hit.terms.filter((t) => !prev.terms.includes(t))]
            });
          }
        });
        acc = next;
      }
      if (acc.size === 0) break;
    }

    if (!acc) return [];
    return Array.from(acc.values()).sort(
      (a, b) => b.score - a.score || a.docId.localeCompare(b.docId) || a.page - b.page
    );
  }
}