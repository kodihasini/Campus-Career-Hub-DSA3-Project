class TrieNode {
  children = new Map<string, TrieNode>();
  isWord = false;
  frequency = 0;
  word = '';
}

/** Prefix tree used for O(L) autocomplete over every indexed term. */
export class Trie {
  private root = new TrieNode();

  insert(word: string): void {
    let node = this.root;
    for (const char of word) {
      let next = node.children.get(char);
      if (!next) {
        next = new TrieNode();
        node.children.set(char, next);
      }
      node = next;
    }
    node.isWord = true;
    node.frequency += 1;
    node.word = word;
  }

  suggest(prefix: string, limit = 6): string[] {
    let node: TrieNode | undefined = this.root;
    for (const char of prefix) {
      node = node.children.get(char);
      if (!node) return [];
    }
    const found: {word: string;frequency: number;}[] = [];
    const stack: TrieNode[] = [node];
    while (stack.length) {
      const current = stack.pop() as TrieNode;
      if (current.isWord) found.push({ word: current.word, frequency: current.frequency });
      current.children.forEach((child) => stack.push(child));
    }
    return found.
    sort((a, b) => b.frequency - a.frequency || a.word.localeCompare(b.word)).
    slice(0, limit).
    map((f) => f.word);
  }
}