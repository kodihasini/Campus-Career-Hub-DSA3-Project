import { skillDictionary } from '../data/resume';
import { escapeRegExp } from './text';
import type { ResumeAnalysis, TargetRole } from '../types/resume';

const ACTION_VERBS = ['built', 'developed', 'designed', 'implemented', 'led', 'optimized', 'created', 'improved', 'deployed', 'automated'];

const SECTIONS = [
{ label: 'Education', patterns: ['education'] },
{ label: 'Skills', patterns: ['skills'] },
{ label: 'Projects', patterns: ['projects', 'project'] },
{ label: 'Experience', patterns: ['experience', 'internship'] }];


function containsTerm(lowerText: string, term: string): boolean {
  return new RegExp(`(^|[^a-z0-9+#.])${escapeRegExp(term.toLowerCase())}(?=$|[^a-z0-9+#])`).test(lowerText);
}

export function analyzeResume(text: string, role: TargetRole): ResumeAnalysis {
  const lower = text.toLowerCase();

  const detectedSkills = skillDictionary.filter((skill) => containsTerm(lower, skill));
  const detectedSet = new Set(detectedSkills.map((s) => s.toLowerCase()));
  const matchedSkills = role.skills.filter((s) => detectedSet.has(s.toLowerCase()));
  const missingSkills = role.skills.filter((s) => !detectedSet.has(s.toLowerCase()));

  const sectionsFound = SECTIONS.filter((section) => section.patterns.some((p) => containsTerm(lower, p)));
  const sectionsMissing = SECTIONS.filter((section) => !sectionsFound.includes(section));
  const keywordsFound = role.keywords.filter((k) => containsTerm(lower, k));

  const hasEmail = /[^\s@]+@[^\s@]+\.[a-z]{2,}/i.test(text);
  const hasPhone = /\+?\d[\d\s-]{8,}\d/.test(text);
  const verbCount = ACTION_VERBS.filter((v) => containsTerm(lower, v)).length;
  const quantified = /\d+\s?%|\b\d{2,}\+?\s?(users|students|requests|ms|records|people|customers)/i.test(text);
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  const lengthOk = words >= 150 && words <= 900;

  const skillsPts = Math.round(matchedSkills.length / role.skills.length * 40);
  const sectionPts = Math.round(sectionsFound.length / SECTIONS.length * 25);
  const keywordPts = Math.round(keywordsFound.length / role.keywords.length * 15);
  const impactPts =
  (hasEmail ? 5 : 0) + (hasPhone ? 3 : 0) + Math.min(verbCount, 3) * 2 + (quantified ? 4 : 0) + (lengthOk ? 2 : 0);

  return {
    score: skillsPts + sectionPts + keywordPts + impactPts,
    detectedSkills,
    matchedSkills,
    missingSkills,
    breakdown: [
    { label: 'Required skills', value: skillsPts, max: 40 },
    { label: 'Resume sections', value: sectionPts, max: 25 },
    { label: 'Role keywords', value: keywordPts, max: 15 },
    { label: 'Impact & contact', value: impactPts, max: 20 }],

    checks: [
    {
      label: 'Contact details',
      passed: hasEmail && hasPhone,
      detail: hasEmail && hasPhone ? 'Email and phone number found' : `Add your ${!hasEmail ? 'email' : ''}${!hasEmail && !hasPhone ? ' and ' : ''}${!hasPhone ? 'phone number' : ''}`
    },
    {
      label: 'Standard sections',
      passed: sectionsMissing.length === 0,
      detail: sectionsMissing.length === 0 ? 'Education, Skills, Projects and Experience found' : `Missing: ${sectionsMissing.map((s) => s.label).join(', ')}`
    },
    {
      label: 'Action verbs',
      passed: verbCount >= 3,
      detail: `${verbCount} strong verb${verbCount === 1 ? '' : 's'} found — aim for 3 or more`
    },
    {
      label: 'Quantified impact',
      passed: quantified,
      detail: quantified ? 'Results are backed by numbers' : 'Add numbers, e.g. “used by 120+ students”'
    },
    {
      label: 'Length',
      passed: lengthOk,
      detail: `${words} words — ATS systems prefer 150–900`
    }]

  };
}