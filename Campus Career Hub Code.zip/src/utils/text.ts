const STOPWORDS = new Set([
'a', 'an', 'the', 'and', 'or', 'of', 'to', 'in', 'on', 'for', 'is', 'are', 'be', 'by', 'with', 'as',
'at', 'it', 'its', 'this', 'that', 'from', 'can', 'each', 'every', 'which', 'where', 'than', 'into',
'after', 'their', 'so', 'all', 'any', 'per']
);

export function tokenize(text: string): string[] {
  return text.
  toLowerCase().
  replace(/[^a-z0-9+#\s-]/g, ' ').
  split(/[\s-]+/).
  filter((t) => t.length > 1 && !STOPWORDS.has(t));
}

export function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function makeSnippet(text: string, terms: string[], length = 220): string {
  if (text.length <= length) return text;
  const lower = text.toLowerCase();
  let idx = -1;
  for (const term of terms) {
    const match = new RegExp(`\\b${escapeRegExp(term)}`).exec(lower);
    if (match && (idx === -1 || match.index < idx)) idx = match.index;
  }
  if (idx === -1) idx = 0;
  let start = Math.max(0, idx - Math.floor(length / 4));
  let end = Math.min(text.length, start + length);
  if (start > 0) {
    const space = text.indexOf(' ', start);
    if (space !== -1) start = space + 1;
  }
  if (end < text.length) {
    const space = text.lastIndexOf(' ', end);
    if (space > start) end = space;
  }
  return `${start > 0 ? '…' : ''}${text.slice(start, end)}${end < text.length ? '…' : ''}`;
}