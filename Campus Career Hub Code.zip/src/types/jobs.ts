export type JobType = 'Part-time' | 'Internship';

export interface Job {
  id: string;
  title: string;
  company: string;
  type: JobType;
  location: string;
  hours: string;
  pay: string;
  skills: string[];
  description: string;
  postedAt: string;
}

export type ApplicationStatus = 'Applied' | 'Under review' | 'Shortlisted' | 'Rejected';

export interface Application {
  jobId: string;
  status: ApplicationStatus;
  appliedAt: string;
}

export interface FitResult {
  score: number;
  matched: string[];
  missing: string[];
}