export interface TargetRole {
  id: string;
  title: string;
  skills: string[];
  keywords: string[];
}

export interface ResumeCheck {
  label: string;
  passed: boolean;
  detail: string;
}

export interface ScoreBreakdown {
  label: string;
  value: number;
  max: number;
}

export interface ResumeAnalysis {
  score: number;
  detectedSkills: string[];
  matchedSkills: string[];
  missingSkills: string[];
  breakdown: ScoreBreakdown[];
  checks: ResumeCheck[];
}