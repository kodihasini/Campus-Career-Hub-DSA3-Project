export interface StudentProject {
  title: string;
  repo: string;
  tech: string[];
}

export interface Student {
  id: string;
  name: string;
  initials: string;
  branch: string;
  year: number;
  headline: string;
  skills: string[];
  atsScore: number;
  github: string;
  projects: StudentProject[];
}