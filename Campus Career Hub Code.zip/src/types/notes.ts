export type NoteKind = 'Notes' | 'PYQ' | 'Assignment' | 'Lecture';

export interface NoteDoc {
  id: string;
  title: string;
  course: string;
  kind: NoteKind;
  pages: string[];
}

export interface SearchHit {
  docId: string;
  page: number;
  score: number;
  terms: string[];
}