export interface Project {
  id: string;
  title: string;
  description: string;
  tech: string[];
  repo: string;
  stars: number;
  updated: string;
}