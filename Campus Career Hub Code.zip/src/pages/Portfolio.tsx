import React, { useState } from 'react';
import { CopyIcon, ExternalLinkIcon, GitBranchIcon, PlusIcon, StarIcon } from 'lucide-react';
import { toast } from 'sonner';
import { AddProjectDialog } from '../components/AddProjectDialog';
import { Avatar } from '../components/Avatar';
import { Button } from '../components/Button';
import { PageHeader } from '../components/PageHeader';
import { SkillTag } from '../components/SkillTag';
import { useApp } from '../contexts/AppContext';
import { currentStudent } from '../data/students';

export function Portfolio() {
  const { projects } = useApp();
  const [adding, setAdding] = useState(false);
  const publicUrl = `campuscareerhub.in/p/${currentStudent.github.split('/').pop()}`;

  const copyLink = () => {
    if (!navigator.clipboard) {
      toast.error('Copy is not available in this browser');
      return;
    }
    navigator.clipboard.
    writeText(`https://${publicUrl}`).
    then(() => toast.success('Public link copied', { description: publicUrl })).
    catch(() => toast.error('Could not copy the link'));
  };

  return (
    <div>
      <PageHeader
        title="Portfolio"
        description="What recruiters and faculty see when they open your profile."
        actions={
        <>
            <Button variant="secondary" onClick={copyLink}>
              <CopyIcon className="h-4 w-4" aria-hidden="true" />
              Copy public link
            </Button>
            <Button onClick={() => setAdding(true)}>
              <PlusIcon className="h-4 w-4" aria-hidden="true" />
              Add project
            </Button>
          </>
        } />
      

      <section className="flex flex-col gap-6 border-b border-line pb-8 md:flex-row md:items-start md:justify-between">
        <div className="flex items-center gap-4">
          <Avatar initials={currentStudent.initials} size="lg" />
          <div>
            <p className="text-xl font-semibold text-ink">{currentStudent.name}</p>
            <p className="text-sm text-body">{currentStudent.headline}</p>
            <p className="mt-0.5 text-sm text-muted">
              B.Tech {currentStudent.branch} · Year {currentStudent.year} · KL University Hyderabad
            </p>
          </div>
        </div>
        <div className="md:max-w-sm md:text-right">
          <a
            href={`https://${currentStudent.github}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-ink hover:text-brand">
            
            {currentStudent.github}
            <ExternalLinkIcon className="h-3.5 w-3.5" aria-hidden="true" />
          </a>
          <div className="mt-3 flex flex-wrap gap-1.5 md:justify-end">
            {currentStudent.skills.map((s) =>
            <SkillTag key={s} label={s} />
            )}
          </div>
        </div>
      </section>

      <section className="mt-8" aria-labelledby="projects-heading">
        <h2 id="projects-heading" className="mb-4 text-base font-semibold text-ink">
          Projects <span className="ml-1 font-normal tabular-nums text-muted">{projects.length}</span>
        </h2>
        {projects.length ?
        <div className="grid gap-4 md:grid-cols-2">
            {projects.map((project) =>
          <article key={project.id} className="flex flex-col rounded-xl border border-line bg-surface p-5">
                <div className="flex-1">
                  <h3 className="font-semibold text-ink">{project.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-body">{project.description}</p>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {project.tech.map((t) =>
                <SkillTag key={t} label={t} />
                )}
                  </div>
                </div>
                <div className="mt-5 flex items-center justify-between gap-3 border-t border-line pt-4 text-sm">
                  <a
                href={`https://${project.repo}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-w-0 items-center gap-1.5 font-medium text-brand hover:text-brand-hover">
                
                    <GitBranchIcon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                    <span className="truncate">{project.repo.replace('github.com/', '')}</span>
                  </a>
                  <div className="flex shrink-0 items-center gap-3 text-muted">
                    <span className="inline-flex items-center gap-1 tabular-nums">
                      <StarIcon className="h-3.5 w-3.5" aria-hidden="true" />
                      {project.stars}
                    </span>
                    <span>{project.updated}</span>
                  </div>
                </div>
              </article>
          )}
          </div> :

        <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-14 text-center">
            <p className="font-medium text-ink">No projects yet</p>
            <p className="mt-1 text-sm text-muted">Add your first project so recruiters can see your work.</p>
          </div>
        }
      </section>

      <AddProjectDialog open={adding} onClose={() => setAdding(false)} />
    </div>);

}