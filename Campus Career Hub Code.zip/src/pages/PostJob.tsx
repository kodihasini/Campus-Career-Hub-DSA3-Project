import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LoaderCircleIcon, XIcon } from 'lucide-react';
import { toast } from 'sonner';
import { Avatar } from '../components/Avatar';
import { Button } from '../components/Button';
import { Field, inputClass } from '../components/Field';
import { PageHeader } from '../components/PageHeader';
import { SegmentedControl } from '../components/SegmentedControl';
import { useApp } from '../contexts/AppContext';
import { skillDictionary } from '../data/resume';
import { students } from '../data/students';
import { rankStudentsForJob } from '../utils/matching';
import type { JobType } from '../types/jobs';

export function PostJob() {
  const { postJob } = useApp();
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [type, setType] = useState<JobType>('Part-time');
  const [location, setLocation] = useState('Hyderabad · Hybrid');
  const [hours, setHours] = useState('12');
  const [pay, setPay] = useState('');
  const [description, setDescription] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const skillSuggestions = skillInput.trim() ?
  skillDictionary.
  filter((s) => s.toLowerCase().includes(skillInput.trim().toLowerCase()) && !skills.includes(s)).
  slice(0, 6) :
  [];

  const matches = useMemo(() => rankStudentsForJob(skills, students), [skills]);
  const strong = matches.filter((m) => m.fit.score >= 75).length;

  const addSkill = (raw: string) => {
    const value = raw.trim();
    if (!value) return;
    const canonical = skillDictionary.find((d) => d.toLowerCase() === value.toLowerCase()) ?? value;
    if (!skills.some((s) => s.toLowerCase() === canonical.toLowerCase())) setSkills([...skills, canonical]);
    setSkillInput('');
  };

  const onSkillKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addSkill(skillSuggestions[0] ?? skillInput);
    } else if (e.key === 'Backspace' && !skillInput && skills.length) {
      setSkills(skills.slice(0, -1));
    }
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    const h = Number(hours);
    if (!title.trim()) next.title = 'Add a role title.';
    if (!skills.length) next.skills = 'Add at least one skill so we can match students.';
    if (!Number.isFinite(h) || h < 1 || h > 40) next.hours = 'Enter between 1 and 40 hours.';
    if (!pay.trim()) next.pay = 'Add the pay, e.g. ₹10,000/month.';
    setErrors(next);
    if (Object.keys(next).length) return;

    setSaving(true);
    window.setTimeout(() => {
      const job = postJob({
        title: title.trim(),
        type,
        location: location.trim() || 'On campus',
        hours: `${h} hrs/week`,
        pay: pay.trim(),
        skills,
        description: description.trim() || 'Details will be shared with shortlisted students.'
      });
      toast.success('Job posted', { description: `${matches.length} students matched to ${job.title}` });
      navigate(`/recruiter?job=${job.id}`);
    }, 500);
  };

  return (
    <div>
      <PageHeader
        title="Post a part-time job"
        description="Describe the role and the skills you need. Students are matched and ranked the moment you post." />
      

      <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_320px]">
        <form onSubmit={submit} className="space-y-5" noValidate>
          <Field label="Role title" htmlFor="title" error={errors.title}>
            <input
              id="title"
              className={inputClass}
              placeholder="e.g. React Developer"
              value={title}
              onChange={(e) => setTitle(e.target.value)} />
            
          </Field>

          <div>
            <span className="mb-1.5 block text-sm font-medium text-ink">Job type</span>
            <SegmentedControl
              label="Job type"
              value={type}
              onChange={setType}
              options={[
              { value: 'Part-time', label: 'Part-time' },
              { value: 'Internship', label: 'Internship' }]
              } />
            
          </div>

          <Field label="Skills needed" htmlFor="skills" error={errors.skills} hint="Press Enter to add a skill">
            <div className="relative">
              <div className="flex min-h-10 flex-wrap items-center gap-1.5 rounded-lg border border-line bg-surface px-2 py-1.5 transition-colors duration-150 focus-within:border-brand/50 focus-within:ring-2 focus-within:ring-brand/15">
                {skills.map((s) =>
                <span key={s} className="inline-flex h-6 items-center gap-1 rounded-md bg-subtle pl-2 pr-1 text-xs font-medium text-ink">
                    {s}
                    <button
                    type="button"
                    onClick={() => setSkills(skills.filter((x) => x !== s))}
                    aria-label={`Remove ${s}`}
                    className="rounded p-0.5 text-muted hover:bg-line hover:text-ink">
                    
                      <XIcon className="h-3 w-3" />
                    </button>
                  </span>
                )}
                <input
                  id="skills"
                  value={skillInput}
                  onChange={(e) => setSkillInput(e.target.value)}
                  onKeyDown={onSkillKey}
                  placeholder={skills.length ? '' : 'React, Python, SQL…'}
                  autoComplete="off"
                  className="h-7 min-w-[120px] flex-1 bg-transparent px-1 text-sm text-ink placeholder:text-muted/70 focus:outline-none" />
                
              </div>
              {skillSuggestions.length > 0 &&
              <ul className="absolute left-0 right-0 top-full z-10 mt-1 overflow-hidden rounded-lg border border-line bg-surface py-1 shadow-lg">
                  {skillSuggestions.map((s) =>
                <li key={s}>
                      <button
                    type="button"
                    onMouseDown={(e) => {
                      e.preventDefault();
                      addSkill(s);
                    }}
                    className="w-full px-3 py-1.5 text-left text-sm text-body hover:bg-subtle hover:text-ink">
                    
                        {s}
                      </button>
                    </li>
                )}
                </ul>
              }
            </div>
          </Field>

          <div className="grid gap-5 sm:grid-cols-3">
            <Field label="Location" htmlFor="location">
              <input id="location" className={inputClass} value={location} onChange={(e) => setLocation(e.target.value)} />
            </Field>
            <Field label="Hours per week" htmlFor="hours" error={errors.hours}>
              <input
                id="hours"
                type="number"
                min={1}
                max={40}
                className={inputClass}
                value={hours}
                onChange={(e) => setHours(e.target.value)} />
              
            </Field>
            <Field label="Pay" htmlFor="pay" error={errors.pay}>
              <input
                id="pay"
                className={inputClass}
                placeholder="₹10,000/month"
                value={pay}
                onChange={(e) => setPay(e.target.value)} />
              
            </Field>
          </div>

          <Field label="Description" htmlFor="description" hint="Optional — what will the student work on?">
            <textarea
              id="description"
              rows={4}
              className={`${inputClass} h-auto resize-none py-2`}
              value={description}
              onChange={(e) => setDescription(e.target.value)} />
            
          </Field>

          <div className="flex gap-2 pt-2">
            <Button type="submit" disabled={saving}>
              {saving && <LoaderCircleIcon className="h-4 w-4 animate-spin" aria-hidden="true" />}
              Post job
            </Button>
            <Button variant="secondary" onClick={() => navigate('/recruiter')}>
              Cancel
            </Button>
          </div>
        </form>

        <aside aria-live="polite" className="h-fit rounded-xl border border-line bg-surface p-5 lg:sticky lg:top-10">
          <h2 className="text-sm font-semibold text-ink">Matching preview</h2>
          {skills.length ?
          <>
              <p className="mt-4 text-4xl font-semibold tabular-nums text-ink">{matches.length}</p>
              <p className="text-sm text-muted">
                students have at least one skill · <span className="text-ink">{strong}</span> strong fit
              </p>
              {matches.length > 0 &&
            <ul className="mt-5 space-y-3 border-t border-line pt-4">
                  {matches.slice(0, 4).map(({ item, fit }) =>
              <li key={item.id} className="flex items-center gap-3">
                      <Avatar initials={item.initials} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-ink">{item.name}</p>
                        <p className="text-xs text-muted">
                          {item.branch} · Year {item.year}
                        </p>
                      </div>
                      <span className="text-sm font-semibold tabular-nums text-ink">{fit.score}%</span>
                    </li>
              )}
                </ul>
            }
            </> :

          <p className="mt-3 text-sm text-muted">Add skills to see which students would be matched to this role.</p>
          }
        </aside>
      </div>
    </div>);

}