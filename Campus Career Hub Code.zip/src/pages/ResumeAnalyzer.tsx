import React, { useRef, useState } from 'react';
import { CircleAlertIcon, CircleCheckIcon, FileTextIcon, LoaderCircleIcon, UploadIcon } from 'lucide-react';
import { Button } from '../components/Button';
import { inputClass } from '../components/Field';
import { PageHeader } from '../components/PageHeader';
import { ScoreRing } from '../components/ScoreRing';
import { SkillTag } from '../components/SkillTag';
import { useApp } from '../contexts/AppContext';
import { sampleResume, targetRoles } from '../data/resume';
import { analyzeResume } from '../utils/resume';
import type { ResumeAnalysis } from '../types/resume';

type Status = 'idle' | 'loading' | 'done';

export function ResumeAnalyzer() {
  const { setResumeSummary } = useApp();
  const [roleId, setRoleId] = useState(targetRoles[0].id);
  const [text, setText] = useState('');
  const [fileName, setFileName] = useState<string | null>(null);
  const [status, setStatus] = useState<Status>('idle');
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const timer = useRef<number>();
  const fileRef = useRef<HTMLInputElement>(null);

  const role = targetRoles.find((r) => r.id === roleId) ?? targetRoles[0];

  const finish = (result: ResumeAnalysis, roleTitle: string) => {
    setAnalysis(result);
    setStatus('done');
    setResumeSummary({ score: result.score, roleTitle, missing: result.missingSkills });
  };

  const run = () => {
    if (!text.trim()) {
      setError('Paste your resume text or upload a .txt file first.');
      return;
    }
    setError(null);
    setStatus('loading');
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => finish(analyzeResume(text, role), role.title), 600);
  };

  const changeRole = (id: string) => {
    setRoleId(id);
    const next = targetRoles.find((r) => r.id === id);
    if (status === 'done' && next) finish(analyzeResume(text, next), next.title);
  };

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.txt')) {
      setError('This prototype reads .txt files. For a PDF, copy its text and paste it below.');
      return;
    }
    file.text().then((content) => {
      setText(content);
      setFileName(file.name);
      setError(null);
    });
  };

  const verdict = (score: number) =>
  score >= 80 ? 'Strong — ready to send' : score >= 60 ? 'Good — a few gaps to close' : 'Needs work before you apply';

  return (
    <div>
      <PageHeader
        title="Resume Analyzer"
        description="Check how an applicant tracking system reads your resume for a specific role, and see exactly which skills are missing." />
      

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <section aria-labelledby="input-heading" className="flex flex-col">
          <h2 id="input-heading" className="sr-only">
            Your resume
          </h2>
          <label htmlFor="role" className="mb-1.5 block text-sm font-medium text-ink">
            Target role
          </label>
          <select id="role" value={roleId} onChange={(e) => changeRole(e.target.value)} className={inputClass}>
            {targetRoles.map((r) =>
            <option key={r.id} value={r.id}>
                {r.title}
              </option>
            )}
          </select>

          <div className="mb-1.5 mt-5 flex items-center justify-between">
            <label htmlFor="resume-text" className="text-sm font-medium text-ink">
              Resume text
            </label>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setText(sampleResume);
                  setFileName(null);
                  setError(null);
                }}>
                
                Use sample
              </Button>
              <Button variant="ghost" size="sm" onClick={() => fileRef.current?.click()}>
                <UploadIcon className="h-3.5 w-3.5" aria-hidden="true" />
                Upload .txt
              </Button>
              <input ref={fileRef} type="file" accept=".txt,text/plain" className="hidden" onChange={onFile} />
            </div>
          </div>
          <textarea
            id="resume-text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Paste the full text of your resume here…"
            className={`${inputClass} h-auto min-h-[380px] flex-1 resize-y py-3 font-mono text-[13px] leading-relaxed`} />
          
          <div className="mt-2 flex min-h-[20px] items-center justify-between text-xs">
            {error ?
            <p className="text-brand" role="alert">
                {error}
              </p> :

            <p className="text-muted">{fileName ? `Loaded ${fileName}` : 'Your resume stays in this browser.'}</p>
            }
            <span className="tabular-nums text-muted">{text.trim() ? text.trim().split(/\s+/).length : 0} words</span>
          </div>
          <Button className="mt-4 self-start" onClick={run} disabled={status === 'loading'}>
            {status === 'loading' && <LoaderCircleIcon className="h-4 w-4 animate-spin" aria-hidden="true" />}
            {status === 'done' ? 'Analyze again' : 'Analyze resume'}
          </Button>
        </section>

        <section aria-live="polite" aria-labelledby="result-heading" className="rounded-xl border border-line bg-surface p-6">
          <h2 id="result-heading" className="sr-only">
            Analysis
          </h2>
          {status === 'idle' &&
          <div className="flex h-full min-h-[380px] flex-col items-center justify-center text-center">
              <FileTextIcon className="h-8 w-8 text-muted/60" aria-hidden="true" />
              <p className="mt-4 font-medium text-ink">Your score will appear here</p>
              <p className="mt-1 max-w-xs text-sm text-muted">
                We check required skills, standard sections, role keywords and measurable impact.
              </p>
            </div>
          }

          {status === 'loading' &&
          <div className="animate-pulse space-y-6" aria-label="Analyzing resume">
              <div className="flex items-center gap-5">
                <div className="h-[120px] w-[120px] rounded-full bg-subtle" />
                <div className="flex-1 space-y-2">
                  <div className="h-5 w-2/3 rounded bg-subtle" />
                  <div className="h-4 w-1/2 rounded bg-subtle" />
                </div>
              </div>
              {[0, 1, 2, 3].map((i) =>
            <div key={i} className="h-3 rounded bg-subtle" />
            )}
            </div>
          }

          {status === 'done' && analysis &&
          <div className="space-y-8">
              <div className="flex items-center gap-5">
                <ScoreRing score={analysis.score} />
                <div>
                  <p className="text-lg font-semibold text-ink">{verdict(analysis.score)}</p>
                  <p className="mt-1 text-sm text-muted">
                    {analysis.matchedSkills.length} of {role.skills.length} skills for {role.title} found.
                  </p>
                </div>
              </div>

              <dl className="space-y-3">
                {analysis.breakdown.map((row) =>
              <div key={row.label}>
                    <div className="flex justify-between text-sm">
                      <dt className="text-body">{row.label}</dt>
                      <dd className="tabular-nums text-ink">
                        {row.value}
                        <span className="text-muted"> / {row.max}</span>
                      </dd>
                    </div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-subtle">
                      <div className="h-full rounded-full bg-ink/80" style={{ width: `${row.value / row.max * 100}%` }} />
                    </div>
                  </div>
              )}
              </dl>

              {analysis.missingSkills.length > 0 &&
            <div>
                  <h3 className="text-sm font-semibold text-ink">Missing skills</h3>
                  <p className="mt-0.5 text-sm text-muted">Add these if you have them — they carry the most weight.</p>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {analysis.missingSkills.map((s) =>
                <SkillTag key={s} label={s} variant="missing" />
                )}
                  </div>
                </div>
            }

              {analysis.matchedSkills.length > 0 &&
            <div>
                  <h3 className="text-sm font-semibold text-ink">Skills found</h3>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {analysis.matchedSkills.map((s) =>
                <SkillTag key={s} label={s} variant="matched" />
                )}
                  </div>
                </div>
            }

              <div>
                <h3 className="text-sm font-semibold text-ink">Checks</h3>
                <ul className="mt-2 divide-y divide-line">
                  {analysis.checks.map((check) =>
                <li key={check.label} className="flex items-start gap-3 py-2.5">
                      {check.passed ?
                  <CircleCheckIcon className="mt-0.5 h-4 w-4 shrink-0 text-success" aria-label="Passed" /> :

                  <CircleAlertIcon className="mt-0.5 h-4 w-4 shrink-0 text-warning" aria-label="Needs attention" />
                  }
                      <div>
                        <p className="text-sm font-medium text-ink">{check.label}</p>
                        <p className="text-sm text-muted">{check.detail}</p>
                      </div>
                    </li>
                )}
                </ul>
              </div>
            </div>
          }
        </section>
      </div>
    </div>);

}