import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { Building2Icon, GraduationCapIcon, LoaderCircleIcon } from 'lucide-react';
import { Button } from '../components/Button';
import { Field, inputClass } from '../components/Field';
import { useApp } from '../contexts/AppContext';
import type { Role } from '../contexts/AppContext';

const MODULES = [
{ name: 'Smart Notes Search', text: 'Find the exact page in notes, PYQs and assignments.' },
{ name: 'Resume Analyzer', text: 'Get an ATS score and the skills you are missing.' },
{ name: 'Job & Internship Matching', text: 'Roles ranked by how well your skills fit.' },
{ name: 'Portfolio Showcase', text: 'Projects and GitHub repos, ready for recruiters.' }];


const ROLE_OPTIONS: {value: Role;label: string;hint: string;email: string;icon: typeof GraduationCapIcon;}[] = [
{ value: 'student', label: 'Student', hint: 'Notes, resume, jobs', email: 'hasini.k@klh.edu.in', icon: GraduationCapIcon },
{ value: 'recruiter', label: 'Recruiter', hint: 'Post part-time jobs', email: 'arjun@nimbuslabs.in', icon: Building2Icon }];


export function Login() {
  const { role, signIn } = useApp();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [selected, setSelected] = useState<Role>('student');
  const [name, setName] = useState('');
  const [email, setEmail] = useState(ROLE_OPTIONS[0].email);
  const [password, setPassword] = useState('password');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  if (role) return <Navigate to={role === 'recruiter' ? '/recruiter' : '/'} replace />;

  const chooseRole = (value: Role) => {
    setSelected(value);
    setEmail(ROLE_OPTIONS.find((o) => o.value === value)?.email ?? '');
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (mode === 'signup' && !name.trim()) next.name = 'Enter your full name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = 'Enter a valid email address.';
    if (password.length < 6) next.password = 'Password must be at least 6 characters.';
    setErrors(next);
    if (Object.keys(next).length) return;
    setLoading(true);
    window.setTimeout(() => signIn(selected), 500);
  };

  return (
    <div className="flex min-h-screen w-full bg-canvas">
      <aside className="hidden w-[44%] flex-col justify-between bg-brand p-12 text-white lg:flex">
        <div className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white text-xs font-bold text-brand">CH</span>
          <span className="text-sm font-semibold">Campus Career Hub</span>
        </div>
        <div className="max-w-md">
          <h1 className="text-4xl font-semibold leading-tight tracking-tight">Study smarter. Get hired sooner.</h1>
          <p className="mt-4 text-base leading-relaxed text-white/85">
            Your notes, resume, job search and portfolio in one place — built for KL University students and the
            recruiters who hire them.
          </p>
          <dl className="mt-10 divide-y divide-white/20 border-y border-white/20">
            {MODULES.map((m) =>
            <div key={m.name} className="py-3.5">
                <dt className="text-sm font-semibold">{m.name}</dt>
                <dd className="mt-0.5 text-sm text-white/80">{m.text}</dd>
              </div>
            )}
          </dl>
        </div>
        <p className="text-xs text-white/70">DSA-3 (25CS2103E) · Team 13 · Section 11</p>
      </aside>

      <main className="flex flex-1 items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <h2 className="text-2xl font-semibold tracking-tight text-ink">
            {mode === 'signin' ? 'Sign in' : 'Create your account'}
          </h2>
          <p className="mt-1.5 text-sm text-muted">
            {mode === 'signin' ? 'Welcome back. Choose how you use Campus Career Hub.' : 'It takes less than a minute.'}
          </p>

          <form onSubmit={submit} className="mt-8 space-y-5" noValidate>
            <div role="radiogroup" aria-label="I am a" className="grid grid-cols-2 gap-2">
              {ROLE_OPTIONS.map((option) => {
                const active = selected === option.value;
                return (
                  <button
                    key={option.value}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => chooseRole(option.value)}
                    className={`rounded-xl border p-3 text-left transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/30 ${
                    active ? 'border-brand bg-brand-soft' : 'border-line bg-surface hover:border-muted/40'}`
                    }>
                    
                    <option.icon className={`h-4 w-4 ${active ? 'text-brand' : 'text-muted'}`} aria-hidden="true" />
                    <p className="mt-2 text-sm font-semibold text-ink">{option.label}</p>
                    <p className="text-xs text-muted">{option.hint}</p>
                  </button>);

              })}
            </div>

            {mode === 'signup' &&
            <Field label="Full name" htmlFor="name" error={errors.name}>
                <input id="name" className={inputClass} value={name} onChange={(e) => setName(e.target.value)} />
              </Field>
            }
            <Field label="Email" htmlFor="email" error={errors.email}>
              <input
                id="email"
                type="email"
                autoComplete="email"
                className={inputClass}
                value={email}
                onChange={(e) => setEmail(e.target.value)} />
              
            </Field>
            <Field label="Password" htmlFor="password" error={errors.password}>
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                className={inputClass}
                value={password}
                onChange={(e) => setPassword(e.target.value)} />
              
            </Field>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <LoaderCircleIcon className="h-4 w-4 animate-spin" aria-hidden="true" />}
              {mode === 'signin' ? 'Continue' : 'Create account'}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-muted">
            {mode === 'signin' ? 'New to Campus Career Hub?' : 'Already have an account?'}{' '}
            <button
              type="button"
              onClick={() => {
                setMode(mode === 'signin' ? 'signup' : 'signin');
                setErrors({});
              }}
              className="font-medium text-brand hover:text-brand-hover">
              
              {mode === 'signin' ? 'Create an account' : 'Sign in'}
            </button>
          </p>
        </div>
      </main>
    </div>);

}