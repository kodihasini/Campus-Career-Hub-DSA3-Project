import React, { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { ArrowRightIcon, SearchIcon } from 'lucide-react';
import { toast } from 'sonner';
import { JobRow } from '../components/JobRow';
import { ScoreRing } from '../components/ScoreRing';
import { SkillTag } from '../components/SkillTag';
import { StatusPill } from '../components/StatusPill';
import { useApp } from '../contexts/AppContext';
import { currentStudent } from '../data/students';
import { rankJobsForStudent } from '../utils/matching';
import type { Job } from '../types/jobs';

export function Dashboard() {
  const { jobs, applications, apply, resumeSummary } = useApp();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');

  const topMatches = useMemo(() => rankJobsForStudent(currentStudent.skills, jobs).slice(0, 3), [jobs]);
  const appliedIds = new Set(applications.map((a) => a.jobId));
  const firstName = currentStudent.name.split(' ').pop();
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';

  const handleApply = (job: Job) => {
    apply(job.id);
    toast.success(`Applied to ${job.title}`, { description: job.company });
  };

  return (
    <div className="space-y-10">
      <header>
        <p className="text-sm text-muted">{format(new Date(), 'EEEE, d MMMM')}</p>
        <h1 className="mt-1 text-3xl font-semibold tracking-tight text-ink">
          Good {greeting}, {firstName}
        </h1>
      </header>

      <form
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          navigate(query.trim() ? `/notes?q=${encodeURIComponent(query.trim())}` : '/notes');
        }}
        className="relative">
        
        <label htmlFor="home-search" className="sr-only">
          Search your study material
        </label>
        <SearchIcon className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" aria-hidden="true" />
        <input
          id="home-search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search notes, PYQs and assignments — try “dijkstra”"
          className="h-14 w-full rounded-xl border border-line bg-surface pl-12 pr-28 text-base text-ink shadow-sm placeholder:text-muted/80 transition-colors duration-150 focus:border-brand/50 focus:outline-none focus:ring-2 focus:ring-brand/15" />
        
        <button
          type="submit"
          className="absolute right-2 top-2 h-10 rounded-lg bg-brand px-4 text-sm font-medium text-white transition-colors duration-150 hover:bg-brand-hover">
          
          Search
        </button>
      </form>

      <div className="grid gap-8 lg:grid-cols-3">
        <section className="lg:col-span-2" aria-labelledby="matches-heading">
          <div className="mb-3 flex items-end justify-between">
            <div>
              <h2 id="matches-heading" className="text-base font-semibold text-ink">
                Best matches for your skills
              </h2>
              <p className="text-sm text-muted">Ranked by skill-fit against your profile</p>
            </div>
            <Link to="/jobs" className="inline-flex items-center gap-1 text-sm font-medium text-brand hover:text-brand-hover">
              All jobs
              <ArrowRightIcon className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
          <div className="divide-y divide-line rounded-xl border border-line bg-surface">
            {topMatches.map(({ item, fit }) =>
            <JobRow key={item.id} job={item} fit={fit} applied={appliedIds.has(item.id)} onApply={handleApply} compact />
            )}
          </div>
        </section>

        <aside className="space-y-6">
          <section className="rounded-xl border border-line bg-surface p-5" aria-labelledby="resume-heading">
            <div className="flex items-center justify-between">
              <h2 id="resume-heading" className="text-sm font-semibold text-ink">
                Resume health
              </h2>
              <Link to="/resume" className="text-sm font-medium text-brand hover:text-brand-hover">
                Improve
              </Link>
            </div>
            {resumeSummary ?
            <>
                <div className="mt-4 flex items-center gap-4">
                  <ScoreRing score={resumeSummary.score} size={76} stroke={7} />
                  <div>
                    <p className="text-sm text-muted">ATS score for</p>
                    <p className="text-sm font-medium text-ink">{resumeSummary.roleTitle}</p>
                  </div>
                </div>
                {resumeSummary.missing.length > 0 &&
              <div className="mt-5">
                    <p className="text-xs font-medium text-muted">Add these to raise your score</p>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {resumeSummary.missing.slice(0, 4).map((s) =>
                  <SkillTag key={s} label={s} variant="missing" />
                  )}
                    </div>
                  </div>
              }
              </> :

            <p className="mt-3 text-sm text-muted">Analyze your resume to see your ATS score.</p>
            }
          </section>

          <section className="rounded-xl border border-line bg-surface p-5" aria-labelledby="apps-heading">
            <div className="flex items-center justify-between">
              <h2 id="apps-heading" className="text-sm font-semibold text-ink">
                Your applications
              </h2>
              <Link to="/jobs?tab=applications" className="text-sm font-medium text-brand hover:text-brand-hover">
                Track
              </Link>
            </div>
            {applications.length ?
            <ul className="mt-3 divide-y divide-line">
                {applications.slice(0, 4).map((app) => {
                const job = jobs.find((j) => j.id === app.jobId);
                if (!job) return null;
                return (
                  <li key={app.jobId} className="flex items-center justify-between gap-3 py-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-ink">{job.title}</p>
                        <p className="truncate text-xs text-muted">
                          {job.company} · {app.appliedAt}
                        </p>
                      </div>
                      <StatusPill status={app.status} />
                    </li>);

              })}
              </ul> :

            <p className="mt-3 text-sm text-muted">You haven't applied anywhere yet.</p>
            }
          </section>
        </aside>
      </div>
    </div>);

}