import React, { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { BookmarkCheckIcon, BookmarkIcon, ClockIcon, MapPinIcon, PlusIcon, WalletIcon } from 'lucide-react';
import { toast } from 'sonner';
import { Avatar } from '../components/Avatar';
import { buttonStyles } from '../components/Button';
import { CandidatePanel } from '../components/CandidatePanel';
import { FitMeter } from '../components/FitMeter';
import { SkillTag } from '../components/SkillTag';
import { useApp } from '../contexts/AppContext';
import { recruiter } from '../data/recruiter';
import { students } from '../data/students';
import { rankStudentsForJob } from '../utils/matching';
import type { Student } from '../types/students';

export function RecruiterCandidates() {
  const { jobs, shortlist, toggleShortlist } = useApp();
  const [params, setParams] = useSearchParams();
  const [onlyShortlisted, setOnlyShortlisted] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);

  const myJobs = jobs.filter((j) => j.company === recruiter.company);
  const job = myJobs.find((j) => j.id === params.get('job')) ?? myJobs[0];
  const ranked = useMemo(() => job ? rankStudentsForJob(job.skills, students) : [], [job]);
  const listed = job ? shortlist[job.id] ?? [] : [];
  const visible = onlyShortlisted ? ranked.filter((r) => listed.includes(r.item.id)) : ranked;
  const openCandidate = ranked.find((r) => r.item.id === openId) ?? null;

  const handleToggle = (student: Student) => {
    if (!job) return;
    const added = toggleShortlist(job.id, student.id);
    toast.success(added ? `${student.name} shortlisted` : `${student.name} removed from shortlist`, {
      description: job.title
    });
  };

  if (!job) {
    return (
      <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-16 text-center">
        <p className="font-medium text-ink">You haven't posted a job yet</p>
        <p className="mt-1 text-sm text-muted">Post a part-time role and we'll rank matching students for you.</p>
        <Link to="/recruiter/post" className={`${buttonStyles()} mt-5`}>
          Post a job
        </Link>
      </div>);

  }

  return (
    <div className="grid gap-8 lg:grid-cols-[240px_minmax(0,1fr)]">
      <aside aria-labelledby="postings-heading">
        <div className="mb-3 flex items-center justify-between">
          <h2 id="postings-heading" className="text-sm font-semibold text-ink">
            Your postings
          </h2>
          <Link to="/recruiter/post" className="inline-flex items-center gap-1 text-sm font-medium text-brand hover:text-brand-hover">
            <PlusIcon className="h-3.5 w-3.5" aria-hidden="true" />
            New
          </Link>
        </div>
        <ul className="space-y-1">
          {myJobs.map((j) => {
            const active = j.id === job.id;
            const matches = rankStudentsForJob(j.skills, students).length;
            return (
              <li key={j.id}>
                <button
                  type="button"
                  onClick={() => {
                    setParams({ job: j.id });
                    setOnlyShortlisted(false);
                  }}
                  aria-current={active ? 'true' : undefined}
                  className={`w-full rounded-lg px-3 py-2.5 text-left transition-colors duration-150 ${
                  active ? 'bg-surface shadow-sm ring-1 ring-line' : 'hover:bg-surface/70'}`
                  }>
                  
                  <p className={`truncate text-sm font-medium ${active ? 'text-ink' : 'text-body'}`}>{j.title}</p>
                  <p className="text-xs text-muted">
                    {matches} matches · {(shortlist[j.id] ?? []).length} shortlisted
                  </p>
                </button>
              </li>);

          })}
        </ul>
      </aside>

      <section aria-labelledby="job-heading" className="min-w-0">
        <header className="mb-6">
          <p className="text-sm text-muted">
            {job.type} · Posted {job.postedAt.toLowerCase()}
          </p>
          <h1 id="job-heading" className="mt-1 text-2xl font-semibold tracking-tight text-ink">
            {job.title}
          </h1>
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted">
            <span className="inline-flex items-center gap-1.5">
              <MapPinIcon className="h-3.5 w-3.5" aria-hidden="true" />
              {job.location}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <ClockIcon className="h-3.5 w-3.5" aria-hidden="true" />
              {job.hours}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <WalletIcon className="h-3.5 w-3.5" aria-hidden="true" />
              {job.pay}
            </span>
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {job.skills.map((s) =>
            <SkillTag key={s} label={s} />
            )}
          </div>
        </header>

        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-body">
            <span className="font-medium text-ink">{ranked.length}</span> students ranked by skill-fit
          </p>
          <label className="inline-flex cursor-pointer items-center gap-2 text-sm text-body">
            <input
              type="checkbox"
              checked={onlyShortlisted}
              onChange={(e) => setOnlyShortlisted(e.target.checked)}
              className="h-4 w-4 rounded border-line accent-[#C00000]" />
            
            Shortlisted only ({listed.length})
          </label>
        </div>

        {visible.length ?
        <div className="overflow-x-auto rounded-xl border border-line bg-surface">
            <table className="w-full min-w-[640px] text-left">
              <thead className="text-xs text-muted">
                <tr>
                  <th className="py-3 pl-5 pr-3 font-medium">#</th>
                  <th className="px-3 py-3 font-medium">Candidate</th>
                  <th className="px-3 py-3 font-medium">Skill fit</th>
                  <th className="hidden px-3 py-3 font-medium xl:table-cell">Matched skills</th>
                  <th className="px-3 py-3 font-medium">ATS</th>
                  <th className="py-3 pl-3 pr-5">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {visible.map(({ item, fit }) => {
                const isListed = listed.includes(item.id);
                const rank = ranked.findIndex((r) => r.item.id === item.id) + 1;
                return (
                  <tr
                    key={item.id}
                    onClick={() => setOpenId(item.id)}
                    className="cursor-pointer border-t border-line transition-colors duration-150 hover:bg-canvas">
                    
                      <td className="py-4 pl-5 pr-3 text-sm tabular-nums text-muted">{rank}</td>
                      <td className="px-3 py-4">
                        <div className="flex items-center gap-3">
                          <Avatar initials={item.initials} size="sm" />
                          <div className="min-w-0">
                            <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setOpenId(item.id);
                            }}
                            className="text-sm font-medium text-ink hover:text-brand focus-visible:underline focus-visible:outline-none">
                            
                              {item.name}
                            </button>
                            <p className="text-xs text-muted">
                              {item.branch} · Year {item.year}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-4">
                        <FitMeter score={fit.score} showLabel={false} />
                      </td>
                      <td className="hidden px-3 py-4 xl:table-cell">
                        <div className="flex flex-wrap gap-1">
                          {fit.matched.slice(0, 3).map((s) =>
                        <SkillTag key={s} label={s} variant="matched" />
                        )}
                          {fit.matched.length > 3 &&
                        <span className="self-center text-xs text-muted">+{fit.matched.length - 3}</span>
                        }
                        </div>
                      </td>
                      <td className="px-3 py-4 text-sm tabular-nums text-ink">{item.atsScore}</td>
                      <td className="py-4 pl-3 pr-5 text-right">
                        <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggle(item);
                        }}
                        aria-pressed={isListed}
                        className={`${buttonStyles(isListed ? 'secondary' : 'ghost', 'sm')} ${isListed ? 'text-success' : ''}`}>
                        
                          {isListed ? <BookmarkCheckIcon className="h-4 w-4" /> : <BookmarkIcon className="h-4 w-4" />}
                          {isListed ? 'Shortlisted' : 'Shortlist'}
                        </button>
                      </td>
                    </tr>);

              })}
              </tbody>
            </table>
          </div> :

        <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-14 text-center">
            <p className="font-medium text-ink">{onlyShortlisted ? 'No one shortlisted yet' : 'No matching students'}</p>
            <p className="mt-1 text-sm text-muted">
              {onlyShortlisted ? 'Shortlist candidates from the full ranking.' : 'Try adding more common skills to this posting.'}
            </p>
          </div>
        }
      </section>

      <CandidatePanel
        candidate={openCandidate}
        shortlisted={openCandidate ? listed.includes(openCandidate.item.id) : false}
        onToggleShortlist={handleToggle}
        onClose={() => setOpenId(null)} />
      
    </div>);

}