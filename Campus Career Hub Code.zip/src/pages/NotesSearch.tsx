import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ChevronRightIcon, SearchIcon, XIcon } from 'lucide-react';
import { Highlight } from '../components/Highlight';
import { PageHeader } from '../components/PageHeader';
import { PagePreview } from '../components/PagePreview';
import { SegmentedControl } from '../components/SegmentedControl';
import { notes } from '../data/notes';
import { getDoc, searchNotes, suggestTerms } from '../utils/notesSearch';
import { makeSnippet } from '../utils/text';
import type { NoteKind } from '../types/notes';

type KindFilter = 'All' | NoteKind;
const KINDS: KindFilter[] = ['All', 'Notes', 'PYQ', 'Assignment', 'Lecture'];
const EXAMPLES = ['dijkstra', 'avl rotation', 'priority queue', 'normalization', 'trie prefix'];

export function NotesSearch() {
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState(params.get('q') ?? '');
  const [kind, setKind] = useState<KindFilter>('All');
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const [preview, setPreview] = useState<{docId: string;page: number;} | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const result = useMemo(() => searchNotes(query), [query]);
  const lastToken = /\s$/.test(query) ? '' : query.trim().split(/\s+/).pop() ?? '';
  const suggestions = useMemo(
    () => suggestTerms(lastToken).filter((s) => s !== lastToken.toLowerCase()),
    [lastToken]
  );
  const showSuggestions = open && suggestions.length > 0;

  useEffect(() => {
    const q = query.trim();
    setParams(q ? { q } : {}, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  const counts = useMemo(() => {
    const c: Record<KindFilter, number> = { All: result.hits.length, Notes: 0, PYQ: 0, Assignment: 0, Lecture: 0 };
    result.hits.forEach((hit) => {
      const doc = getDoc(hit.docId);
      if (doc) c[doc.kind] += 1;
    });
    return c;
  }, [result]);

  const hits = result.hits.filter((hit) => kind === 'All' || getDoc(hit.docId)?.kind === kind);
  const docCount = new Set(hits.map((h) => h.docId)).size;
  const hasQuery = query.trim().length > 0;

  const applySuggestion = (word: string) => {
    const parts = query.trimEnd().split(/\s+/);
    parts[parts.length - 1] = word;
    setQuery(`${parts.join(' ')} `);
    setActive(-1);
    setOpen(false);
    inputRef.current?.focus();
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!showSuggestions) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActive((i) => (i + 1) % suggestions.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActive((i) => i <= 0 ? suggestions.length - 1 : i - 1);
    } else if (e.key === 'Enter' && active >= 0) {
      e.preventDefault();
      applySuggestion(suggestions[active]);
    } else if (e.key === 'Escape') {
      setOpen(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="Notes Search"
        description="Search across notes, previous year questions, assignments and lecture material. Every result points to the exact page." />
      

      <div className="relative">
        <label htmlFor="notes-search" className="sr-only">
          Search study material
        </label>
        <SearchIcon className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" aria-hidden="true" />
        <input
          ref={inputRef}
          id="notes-search"
          role="combobox"
          aria-expanded={showSuggestions}
          aria-controls="notes-suggestions"
          aria-autocomplete="list"
          aria-activedescendant={active >= 0 ? `suggestion-${active}` : undefined}
          autoComplete="off"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
            setActive(-1);
          }}
          onFocus={() => setOpen(true)}
          onBlur={() => window.setTimeout(() => setOpen(false), 120)}
          onKeyDown={onKeyDown}
          placeholder="Search a topic, e.g. “binary heap” or “bcnf”"
          className="h-14 w-full rounded-xl border border-line bg-surface pl-12 pr-12 text-base text-ink shadow-sm placeholder:text-muted/80 transition-colors duration-150 focus:border-brand/50 focus:outline-none focus:ring-2 focus:ring-brand/15" />
        
        {hasQuery &&
        <button
          type="button"
          onClick={() => {
            setQuery('');
            inputRef.current?.focus();
          }}
          aria-label="Clear search"
          className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-muted hover:bg-subtle hover:text-ink">
          
            <XIcon className="h-4 w-4" />
          </button>
        }
        {showSuggestions &&
        <ul
          id="notes-suggestions"
          role="listbox"
          className="absolute left-0 right-0 top-full z-20 mt-2 overflow-hidden rounded-xl border border-line bg-surface py-1 shadow-lg">
          
            {suggestions.map((word, i) =>
          <li
            key={word}
            id={`suggestion-${i}`}
            role="option"
            aria-selected={i === active}
            onMouseDown={(e) => {
              e.preventDefault();
              applySuggestion(word);
            }}
            onMouseEnter={() => setActive(i)}
            className={`flex cursor-pointer items-center gap-3 px-4 py-2 text-sm ${i === active ? 'bg-subtle' : ''}`}>
            
                <SearchIcon className="h-3.5 w-3.5 text-muted" aria-hidden="true" />
                <span className="text-muted">{lastToken.toLowerCase()}</span>
                <span className="-ml-3 font-medium text-ink">{word.slice(lastToken.length)}</span>
              </li>
          )}
          </ul>
        }
      </div>

      {hasQuery ?
      <section className="mt-6" aria-live="polite">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <SegmentedControl
            label="Filter by type"
            value={kind}
            onChange={setKind}
            options={KINDS.map((k) => ({ value: k, label: k, count: counts[k] }))} />
          
            <p className="text-sm text-muted">
              <span className="font-medium text-ink">{hits.length}</span> page{hits.length === 1 ? '' : 's'} in{' '}
              {docCount} document{docCount === 1 ? '' : 's'} · {result.ms.toFixed(2)} ms
            </p>
          </div>

          {hits.length ?
        <ul className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-surface">
              {hits.map((hit) => {
            const doc = getDoc(hit.docId);
            if (!doc) return null;
            return (
              <li key={`${hit.docId}-${hit.page}`}>
                    <button
                  type="button"
                  onClick={() => setPreview({ docId: hit.docId, page: hit.page })}
                  className="flex w-full items-start gap-5 px-5 py-4 text-left transition-colors duration-150 hover:bg-canvas focus-visible:bg-canvas focus-visible:outline-none">
                  
                      <div className="w-12 shrink-0 pt-0.5 text-center">
                        <p className="text-[11px] font-medium text-muted">Page</p>
                        <p className="text-2xl font-semibold tabular-nums leading-tight text-ink">{hit.page}</p>
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                          <span className="font-medium text-ink">{doc.title}</span>
                          <span className="rounded-md bg-subtle px-1.5 py-0.5 text-xs font-medium text-body">{doc.kind}</span>
                        </div>
                        <p className="text-xs text-muted">{doc.course}</p>
                        <p className="mt-2 text-sm leading-relaxed text-body">
                          <Highlight text={makeSnippet(doc.pages[hit.page - 1], hit.terms)} terms={hit.terms} />
                        </p>
                      </div>
                      <ChevronRightIcon className="mt-1 h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
                    </button>
                  </li>);

          })}
            </ul> :

        <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-14 text-center">
              <p className="font-medium text-ink">No pages match “{query.trim()}”</p>
              <p className="mt-1 text-sm text-muted">Try fewer words, or a broader term like “graph” or “tree”.</p>
            </div>
        }
        </section> :

      <div className="mt-6 space-y-10">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm text-muted">Try</span>
            {EXAMPLES.map((ex) =>
          <button
            key={ex}
            type="button"
            onClick={() => setQuery(ex)}
            className="h-8 rounded-full border border-line bg-surface px-3 text-sm text-body transition-colors duration-150 hover:border-muted/40 hover:text-ink">
            
                {ex}
              </button>
          )}
          </div>

          <section aria-labelledby="library-heading">
            <h2 id="library-heading" className="mb-3 text-base font-semibold text-ink">
              Indexed library
            </h2>
            <div className="overflow-x-auto rounded-xl border border-line bg-surface">
              <table className="w-full min-w-[560px] text-left text-sm">
                <thead className="text-xs text-muted">
                  <tr>
                    <th className="px-5 py-3 font-medium">Document</th>
                    <th className="px-5 py-3 font-medium">Course</th>
                    <th className="px-5 py-3 font-medium">Type</th>
                    <th className="px-5 py-3 text-right font-medium">Pages</th>
                  </tr>
                </thead>
                <tbody>
                  {notes.map((doc) =>
                <tr
                  key={doc.id}
                  onClick={() => setPreview({ docId: doc.id, page: 1 })}
                  className="cursor-pointer border-t border-line transition-colors duration-150 hover:bg-canvas">
                  
                      <td className="px-5 py-3">
                        <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setPreview({ docId: doc.id, page: 1 });
                      }}
                      className="font-medium text-ink hover:text-brand focus-visible:outline-none focus-visible:underline">
                      
                          {doc.title}
                        </button>
                      </td>
                      <td className="px-5 py-3 text-body">{doc.course}</td>
                      <td className="px-5 py-3 text-body">{doc.kind}</td>
                      <td className="px-5 py-3 text-right tabular-nums text-body">{doc.pages.length}</td>
                    </tr>
                )}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      }

      <PagePreview target={preview} terms={hasQuery ? result.terms : []} onChange={setPreview} />
    </div>);

}