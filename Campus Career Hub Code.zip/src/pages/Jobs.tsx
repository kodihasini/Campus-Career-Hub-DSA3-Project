import React, { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SearchIcon } from 'lucide-react';
import { toast } from 'sonner';
import { inputClass } from '../components/Field';
import { JobRow } from '../components/JobRow';
import { PageHeader } from '../components/PageHeader';
import { SegmentedControl } from '../components/SegmentedControl';
import { SkillTag } from '../components/SkillTag';
import { StatusPill } from '../components/StatusPill';
import { useApp } from '../contexts/AppContext';
import { currentStudent } from '../data/students';
import { rankJobsForStudent } from '../utils/matching';
import type { ApplicationStatus, Job, JobType } from '../types/jobs';

type Tab = 'matches' | 'applications';
const STEPS: ApplicationStatus[] = ['Applied', 'Under review', 'Shortlisted'];

export function Jobs() {
  const { jobs, applications, apply } = useApp();
  const [params, setParams] = useSearchParams();
  const tab: Tab = params.get('tab') === 'applications' ? 'applications' : 'matches';
  const [type, setType] = useState<'All' | JobType>('All');
  const [search, setSearch] = useState('');

  const ranked = useMemo(() => rankJobsForStudent(currentStudent.skills, jobs), [jobs]);
  const appliedIds = new Set(applications.map((a) => a.jobId));
  const q = search.trim().toLowerCase();
  const visible = ranked.filter(
    ({ item }) =>
    (type === 'All' || item.type === type) && (
    !q || item.title.toLowerCase().includes(q) || item.company.toLowerCase().includes(q))
  );

  const handleApply = (job: Job) => {
    apply(job.id);
    toast.success(`Applied to ${job.title}`, { description: `${job.company} will see your resume and portfolio.` });
  };

  const tabClass = (value: Tab) =>
  `-mb-px border-b-2 px-1 pb-3 text-sm font-medium transition-colors duration-150 ${
  tab === value ? 'border-brand text-ink' : 'border-transparent text-muted hover:text-ink'}`;


  return (
    <div>
      <PageHeader
        title="Jobs & Internships"
        description="Part-time roles and internships from campus and local employers, ranked by how well your skills fit." />
      

      <div role="tablist" className="mb-6 flex gap-6 border-b border-line">
        <button role="tab" aria-selected={tab === 'matches'} className={tabClass('matches')} onClick={() => setParams({})}>
          Recommended
        </button>
        <button
          role="tab"
          aria-selected={tab === 'applications'}
          className={tabClass('applications')}
          onClick={() => setParams({ tab: 'applications' })}>
          
          My applications <span className="ml-1 tabular-nums text-muted">{applications.length}</span>
        </button>
      </div>

      {tab === 'matches' ?
      <>
          <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <SegmentedControl
              label="Job type"
              value={type}
              onChange={setType}
              options={[
              { value: 'All', label: 'All' },
              { value: 'Part-time', label: 'Part-time' },
              { value: 'Internship', label: 'Internship' }]
              } />
            
              <div className="relative sm:w-64">
                <SearchIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden="true" />
                <input
                aria-label="Filter by role or company"
                placeholder="Role or company"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className={`${inputClass} pl-9`} />
              
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="mr-1 text-xs text-muted">Matching on</span>
              {currentStudent.skills.slice(0, 5).map((s) =>
            <SkillTag key={s} label={s} />
            )}
              <span className="text-xs text-muted">+{currentStudent.skills.length - 5}</span>
            </div>
          </div>

          {visible.length ?
        <div className="divide-y divide-line rounded-xl border border-line bg-surface">
              {visible.map(({ item, fit }) =>
          <JobRow key={item.id} job={item} fit={fit} applied={appliedIds.has(item.id)} onApply={handleApply} />
          )}
            </div> :

        <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-14 text-center">
              <p className="font-medium text-ink">No roles match these filters</p>
              <p className="mt-1 text-sm text-muted">Clear the search or switch the job type.</p>
            </div>
        }
        </> :
      applications.length ?
      <ul className="divide-y divide-line rounded-xl border border-line bg-surface">
          {applications.map((app) => {
          const job = jobs.find((j) => j.id === app.jobId);
          if (!job) return null;
          const stepIndex = STEPS.indexOf(app.status);
          return (
            <li key={app.jobId} className="grid gap-4 p-5 md:grid-cols-[minmax(0,1fr)_auto_auto] md:items-center md:gap-8">
                <div className="min-w-0">
                  <p className="font-medium text-ink">{job.title}</p>
                  <p className="text-sm text-muted">
                    {job.company} · Applied {app.appliedAt}
                  </p>
                </div>
                <ol className="flex items-center gap-2" aria-label="Application progress">
                  {STEPS.map((step, i) => {
                  const done = stepIndex >= i;
                  return (
                    <li key={step} className="flex items-center gap-2">
                        <span className={`h-2 w-2 rounded-full ${done ? 'bg-success' : 'bg-line'}`} aria-hidden="true" />
                        <span className={`whitespace-nowrap text-xs ${done ? 'text-ink' : 'text-muted'}`}>{step}</span>
                        {i < STEPS.length - 1 && <span className="h-px w-5 bg-line" aria-hidden="true" />}
                      </li>);

                })}
                </ol>
                <div className="md:justify-self-end">
                  <StatusPill status={app.status} />
                </div>
              </li>);

        })}
        </ul> :

      <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-14 text-center">
          <p className="font-medium text-ink">No applications yet</p>
          <p className="mt-1 text-sm text-muted">Apply to a recommended role and track it here.</p>
        </div>
      }
    </div>);

}