export const recruiter = {
  name: 'Arjun Mehta',
  initials: 'AM',
  title: 'Founder',
  company: 'Nimbus Labs'
};