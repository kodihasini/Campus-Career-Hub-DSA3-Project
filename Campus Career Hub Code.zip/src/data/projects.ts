import type { Project } from '../types/portfolio';

export const portfolioProjects: Project[] = [
{
  id: 'p1',
  title: 'Campus Career Hub',
  description: 'One platform for notes search, resume scoring and skill-based job matching, built on tries, inverted indexes and priority queues.',
  tech: ['React', 'FastAPI', 'PostgreSQL'],
  repo: 'github.com/hasini-k/campus-career-hub',
  stars: 48,
  updated: 'Sep 24, 2026'
},
{
  id: 'p2',
  title: 'Expense Splitter',
  description: 'A responsive app for splitting shared hostel expenses, used by 120+ students every month.',
  tech: ['React', 'JavaScript', 'CSS'],
  repo: 'github.com/hasini-k/expense-splitter',
  stars: 21,
  updated: 'Aug 30, 2026'
},
{
  id: 'p3',
  title: 'Pathfinding Visualizer',
  description: "Step-by-step animation of BFS, DFS and Dijkstra's algorithm on an editable grid.",
  tech: ['JavaScript', 'HTML', 'CSS'],
  repo: 'github.com/hasini-k/pathfinding-visualizer',
  stars: 35,
  updated: 'Jul 12, 2026'
},
{
  id: 'p4',
  title: 'DSA Practice Tracker',
  description: 'Logs solved problems by topic and suggests the weakest area to practise next.',
  tech: ['Python', 'SQL'],
  repo: 'github.com/hasini-k/dsa-tracker',
  stars: 9,
  updated: 'Jun 3, 2026'
}];