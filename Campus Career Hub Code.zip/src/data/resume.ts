import type { TargetRole } from '../types/resume';

export const targetRoles: TargetRole[] = [
{
  id: 'frontend',
  title: 'Frontend Developer Intern',
  skills: ['React', 'JavaScript', 'TypeScript', 'HTML', 'CSS', 'Git', 'REST APIs', 'Tailwind CSS'],
  keywords: ['responsive', 'component', 'accessibility', 'performance', 'UI']
},
{
  id: 'backend',
  title: 'Backend Developer Intern',
  skills: ['Python', 'FastAPI', 'PostgreSQL', 'SQL', 'REST APIs', 'Docker', 'Git', 'Data Structures'],
  keywords: ['API', 'database', 'scalable', 'authentication', 'testing']
},
{
  id: 'data',
  title: 'Data Analyst Intern',
  skills: ['Python', 'SQL', 'Excel', 'Pandas', 'Power BI', 'Statistics', 'Data Visualization'],
  keywords: ['dashboard', 'insights', 'analysis', 'reporting', 'dataset']
},
{
  id: 'sde',
  title: 'Software Engineer Intern',
  skills: ['Java', 'Python', 'Data Structures', 'Algorithms', 'Git', 'SQL', 'OOP', 'Problem Solving'],
  keywords: ['algorithm', 'optimized', 'complexity', 'system', 'debugging']
}];


export const skillDictionary: string[] = [
'React', 'JavaScript', 'TypeScript', 'HTML', 'CSS', 'Tailwind CSS', 'Git', 'REST APIs',
'Python', 'FastAPI', 'PostgreSQL', 'SQL', 'Docker', 'Data Structures', 'Algorithms',
'Excel', 'Pandas', 'Power BI', 'Statistics', 'Data Visualization', 'Java', 'OOP',
'Problem Solving', 'C++', 'Node.js', 'MongoDB', 'Machine Learning', 'Figma',
'Communication', 'Linux', 'AWS', 'Kotlin', 'Flutter'];


export const sampleResume = `K. HASINI
Hyderabad, India · hasini.k@klh.edu.in · +91 98765 43210 · github.com/hasini-k

SUMMARY
Second-year Computer Science student at KL University Hyderabad with a strong base in data structures and web development. Looking for a frontend or backend internship where I can ship real features for real users.

EDUCATION
B.Tech in Computer Science and Engineering, KL University Hyderabad, 2024 to 2028. CGPA 9.1 / 10.

SKILLS
Python, JavaScript, React, HTML, CSS, SQL, Git, Data Structures, Algorithms

PROJECTS
Campus Career Hub: Built a notes search engine using a trie and an inverted index that returns page-accurate results in under 50 ms. Developed a resume analyzer that scores resumes against target roles.
Expense Splitter: Designed a responsive React app to split shared expenses between friends, used by 120+ students in the hostel.
Pathfinding Visualizer: Implemented BFS, DFS and Dijkstra's algorithm with a step-by-step animation for every component of the grid.

EXPERIENCE
Volunteer, KLH Coding Club: Led weekly DSA practice sessions for 40 first-year students and improved average contest scores by 25%.

ACHIEVEMENTS
Top 5% in the college-wide hackathon, 2025.`;