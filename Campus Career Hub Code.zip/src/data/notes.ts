import type { NoteDoc } from '../types/notes';

export const notes: NoteDoc[] = [
{
  id: 'n1',
  title: 'Trees & Tries — Unit 3 Notes',
  course: 'DSA-3 (25CS2103E)',
  kind: 'Notes',
  pages: [
  'A binary search tree stores keys so that the left subtree holds smaller keys and the right subtree holds larger keys. Search, insert and delete run in O(h) time where h is the height of the tree.',
  'AVL trees keep the tree balanced by tracking a balance factor at every node. Rotations (left, right, left-right, right-left) restore balance after insertion or deletion, guaranteeing O(log n) height.',
  'A trie is a prefix tree where each edge represents a character. Tries support prefix search and autocomplete in O(L) time, where L is the length of the query string, independent of the number of stored words.',
  'Applications of tries include dictionary lookup, spell checking, IP routing with longest prefix match, and search engine autocomplete suggestions.']

},
{
  id: 'n2',
  title: 'Graph Algorithms — Lecture 14',
  course: 'DSA-3 (25CS2103E)',
  kind: 'Lecture',
  pages: [
  'A graph G = (V, E) can be represented with an adjacency matrix or an adjacency list. Adjacency lists use O(V + E) space and suit sparse graphs.',
  'Breadth first search explores vertices level by level using a queue. Depth first search uses a stack or recursion and is used for cycle detection and topological sort.',
  "Dijkstra's algorithm finds shortest paths from a single source in graphs with non-negative weights. Using a priority queue (binary heap) it runs in O((V + E) log V).",
  'Bipartite matching pairs vertices from two disjoint sets. It is used to match students to jobs, where edges represent shared skills.']

},
{
  id: 'n3',
  title: 'End Semester PYQ — 2025',
  course: 'DSA-3 (25CS2103E)',
  kind: 'PYQ',
  pages: [
  'Q1. Construct an AVL tree by inserting 30, 20, 40, 10, 25, 35, 50, 5. Show every rotation and the balance factor of each node. (10 marks)',
  'Q2. Explain how a priority queue is implemented using a binary heap. Derive the time complexity of insert and extract-max. (8 marks)',
  "Q3. Apply Dijkstra's algorithm on the given graph starting from vertex A and list the shortest path to every vertex. (12 marks)"]

},
{
  id: 'n4',
  title: 'Hashing & Inverted Index — Assignment 2',
  course: 'DSA-3 (25CS2103E)',
  kind: 'Assignment',
  pages: [
  'Implement a hash table with separate chaining. Report the average number of probes as the load factor grows from 0.25 to 2.0.',
  'Build an inverted index for a collection of 50 documents. Each term should map to a posting list of document ids and page numbers.',
  'Use the inverted index to answer multi-word queries by intersecting posting lists. Compare the running time against a linear scan.']

},
{
  id: 'n5',
  title: 'Normalization Notes',
  course: 'Database Management Systems',
  kind: 'Notes',
  pages: [
  'Normalization removes redundancy from relational tables. First normal form requires atomic values; second normal form removes partial dependencies on a composite key.',
  'Third normal form removes transitive dependencies. Boyce-Codd normal form requires every determinant to be a candidate key.',
  'Indexing in PostgreSQL uses B-tree indexes by default. A B-tree keeps data sorted and allows searches, sequential access and insertions in logarithmic time.']

},
{
  id: 'n6',
  title: 'Mid Semester PYQ — 2024',
  course: 'Database Management Systems',
  kind: 'PYQ',
  pages: [
  'Q1. Normalize the given relation up to BCNF and justify each decomposition step. (10 marks)',
  'Q2. Write SQL queries using joins and group by to find the top three departments by average salary. (8 marks)']

},
{
  id: 'n7',
  title: 'CPU Scheduling — Lecture 6',
  course: 'Operating Systems',
  kind: 'Lecture',
  pages: [
  'CPU scheduling decides which process runs next. First come first served is simple but suffers from the convoy effect.',
  'Priority scheduling uses a priority queue of ready processes. Aging gradually raises the priority of waiting processes to prevent starvation.',
  'Round robin assigns a fixed time quantum to each process and is widely used in time-sharing systems.']

},
{
  id: 'n8',
  title: 'Routing Notes',
  course: 'Computer Networks',
  kind: 'Notes',
  pages: [
  'Routers forward packets using longest prefix match on the destination IP address. Tries are a common data structure for fast routing table lookup.',
  "Link state routing uses Dijkstra's algorithm on the network graph to compute shortest paths to every router."]

}];