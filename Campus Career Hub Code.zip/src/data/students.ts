import type { Student } from '../types/students';

export const students: Student[] = [
{
  id: 's1',
  name: 'K. Hasini',
  initials: 'KH',
  branch: 'CSE',
  year: 2,
  headline: 'Frontend developer with a strong DSA foundation',
  skills: ['Python', 'JavaScript', 'React', 'HTML', 'CSS', 'SQL', 'Git', 'Data Structures', 'Algorithms'],
  atsScore: 76,
  github: 'github.com/hasini-k',
  projects: [
  { title: 'Campus Career Hub', repo: 'github.com/hasini-k/campus-career-hub', tech: ['React', 'FastAPI'] },
  { title: 'Expense Splitter', repo: 'github.com/hasini-k/expense-splitter', tech: ['React'] }]

},
{
  id: 's2',
  name: 'L. Lavanya',
  initials: 'LL',
  branch: 'CSE',
  year: 2,
  headline: 'Backend developer focused on APIs and databases',
  skills: ['Python', 'FastAPI', 'PostgreSQL', 'SQL', 'Git', 'Data Structures', 'React', 'JavaScript'],
  atsScore: 81,
  github: 'github.com/lavanya-l',
  projects: [
  { title: 'Notes Indexer API', repo: 'github.com/lavanya-l/notes-indexer', tech: ['FastAPI', 'PostgreSQL'] },
  { title: 'Library Tracker', repo: 'github.com/lavanya-l/library-tracker', tech: ['Python', 'SQL'] }]

},
{
  id: 's3',
  name: 'Rohan Varma',
  initials: 'RV',
  branch: 'CS&IT',
  year: 3,
  headline: 'Frontend engineer who cares about accessibility',
  skills: ['React', 'JavaScript', 'TypeScript', 'Tailwind CSS', 'HTML', 'CSS', 'Git', 'Node.js'],
  atsScore: 84,
  github: 'github.com/rohanv',
  projects: [
  { title: 'Design Token Playground', repo: 'github.com/rohanv/token-playground', tech: ['React', 'TypeScript'] }]

},
{
  id: 's4',
  name: 'Sneha Reddy',
  initials: 'SR',
  branch: 'AI&DS',
  year: 3,
  headline: 'Data analyst who turns messy data into decisions',
  skills: ['Python', 'Pandas', 'SQL', 'Excel', 'Power BI', 'Statistics', 'Machine Learning'],
  atsScore: 79,
  github: 'github.com/sneha-r',
  projects: [
  { title: 'Hostel Mess Demand Forecast', repo: 'github.com/sneha-r/mess-forecast', tech: ['Python', 'Pandas'] }]

},
{
  id: 's5',
  name: 'Aditya Kumar',
  initials: 'AK',
  branch: 'CSE',
  year: 4,
  headline: 'Competitive programmer, Java and systems',
  skills: ['Java', 'Python', 'Data Structures', 'Algorithms', 'OOP', 'SQL', 'Git', 'Communication'],
  atsScore: 72,
  github: 'github.com/adityak',
  projects: [
  { title: 'Graph Algorithms Library', repo: 'github.com/adityak/graphlib', tech: ['Java'] },
  { title: 'Contest Stats Bot', repo: 'github.com/adityak/contest-bot', tech: ['Python'] }]

},
{
  id: 's6',
  name: 'Meghana Rao',
  initials: 'MR',
  branch: 'ECE',
  year: 2,
  headline: 'UI designer learning frontend development',
  skills: ['Figma', 'HTML', 'CSS', 'JavaScript', 'Communication'],
  atsScore: 68,
  github: 'github.com/meghana-rao',
  projects: [{ title: 'Club Website Redesign', repo: 'github.com/meghana-rao/club-site', tech: ['HTML', 'CSS'] }]
},
{
  id: 's7',
  name: 'Karthik Naidu',
  initials: 'KN',
  branch: 'CSE',
  year: 3,
  headline: 'Android developer shipping side projects',
  skills: ['Kotlin', 'Flutter', 'REST APIs', 'Git', 'Java'],
  atsScore: 70,
  github: 'github.com/karthikn',
  projects: [{ title: 'Bus Pass Wallet', repo: 'github.com/karthikn/bus-pass', tech: ['Flutter'] }]
},
{
  id: 's8',
  name: 'Priya Sharma',
  initials: 'PS',
  branch: 'CS&IT',
  year: 2,
  headline: 'Full stack developer on the MERN stack',
  skills: ['React', 'Node.js', 'MongoDB', 'JavaScript', 'HTML', 'CSS', 'Git'],
  atsScore: 74,
  github: 'github.com/priya-sharma',
  projects: [{ title: 'Event RSVP App', repo: 'github.com/priya-sharma/rsvp', tech: ['React', 'Node.js'] }]
}];


export const currentStudent = students[0];