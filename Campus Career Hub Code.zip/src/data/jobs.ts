import type { Job } from '../types/jobs';

export const jobs: Job[] = [
{
  id: 'j1',
  title: 'Frontend Developer',
  company: 'Nimbus Labs',
  type: 'Part-time',
  location: 'Hyderabad · Hybrid',
  hours: '15 hrs/week',
  pay: '₹12,000/month',
  skills: ['React', 'JavaScript', 'HTML', 'CSS', 'Git'],
  description: 'Build and polish customer-facing screens for an early-stage SaaS product alongside the founding team.',
  postedAt: '2 days ago'
},
{
  id: 'j2',
  title: 'Python Backend Intern',
  company: 'Ledgerly Fintech',
  type: 'Internship',
  location: 'Remote',
  hours: '20 hrs/week',
  pay: '₹15,000/month',
  skills: ['Python', 'FastAPI', 'PostgreSQL', 'SQL', 'Git'],
  description: 'Design REST endpoints and database queries for a personal finance app used by 40,000 people.',
  postedAt: '3 days ago'
},
{
  id: 'j3',
  title: 'Data Analyst Intern',
  company: 'Campus Eats',
  type: 'Internship',
  location: 'On campus',
  hours: '12 hrs/week',
  pay: '₹8,000/month',
  skills: ['Python', 'SQL', 'Excel', 'Power BI'],
  description: 'Turn canteen order data into weekly dashboards that help vendors plan stock and reduce waste.',
  postedAt: '5 days ago'
},
{
  id: 'j4',
  title: 'DSA Teaching Assistant',
  company: 'KLH CS&IT Department',
  type: 'Part-time',
  location: 'On campus',
  hours: '8 hrs/week',
  pay: '₹6,000/month',
  skills: ['Data Structures', 'Algorithms', 'Python', 'Communication'],
  description: 'Run lab sessions and doubt-clearing hours for first-year students taking Data Structures.',
  postedAt: '1 week ago'
},
{
  id: 'j5',
  title: 'Mobile App Intern',
  company: 'Swiftcart',
  type: 'Internship',
  location: 'Bengaluru · On-site',
  hours: '20 hrs/week',
  pay: '₹14,000/month',
  skills: ['Kotlin', 'Flutter', 'REST APIs', 'Git'],
  description: 'Ship features for a quick-commerce Android app with a small mobile team.',
  postedAt: '1 week ago'
},
{
  id: 'j6',
  title: 'Full Stack Intern',
  company: 'Orbit Health',
  type: 'Internship',
  location: 'Remote',
  hours: '20 hrs/week',
  pay: '₹16,000/month',
  skills: ['React', 'Node.js', 'MongoDB', 'JavaScript', 'Git'],
  description: 'Work across the stack on an appointment-booking platform for small clinics.',
  postedAt: '4 days ago'
},
{
  id: 'j7',
  title: 'UI Designer',
  company: 'Studio Kora',
  type: 'Part-time',
  location: 'Remote',
  hours: '10 hrs/week',
  pay: '₹9,000/month',
  skills: ['Figma', 'HTML', 'CSS', 'Communication'],
  description: 'Design landing pages and social assets for a boutique branding studio.',
  postedAt: '6 days ago'
},
{
  id: 'j8',
  title: 'Machine Learning Intern',
  company: 'Vectorwise AI',
  type: 'Internship',
  location: 'Hyderabad · On-site',
  hours: '20 hrs/week',
  pay: '₹18,000/month',
  skills: ['Python', 'Machine Learning', 'Pandas', 'Statistics'],
  description: 'Clean datasets and train baseline models for a document classification product.',
  postedAt: '2 days ago'
},
{
  id: 'j9',
  title: 'Backend Support Intern',
  company: 'Nimbus Labs',
  type: 'Internship',
  location: 'Hyderabad · Hybrid',
  hours: '16 hrs/week',
  pay: '₹10,000/month',
  skills: ['Python', 'FastAPI', 'SQL', 'REST APIs', 'Git'],
  description: 'Maintain internal APIs, write tests, and help debug production issues with the backend lead.',
  postedAt: '1 day ago'
}];