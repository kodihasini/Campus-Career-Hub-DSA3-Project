import type { Application } from '../types/jobs';

export const seedApplications: Application[] = [
{ jobId: 'j4', status: 'Under review', appliedAt: 'Sep 22' },
{ jobId: 'j6', status: 'Applied', appliedAt: 'Sep 25' }];