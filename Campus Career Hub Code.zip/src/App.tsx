import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { MotionConfig } from 'framer-motion';
import { Toaster } from 'sonner';
import { AppShell } from './components/AppShell';
import { RequireRole } from './components/RequireRole';
import { AppProvider } from './contexts/AppContext';
import { Dashboard } from './pages/Dashboard';
import { Jobs } from './pages/Jobs';
import { Login } from './pages/Login';
import { NotesSearch } from './pages/NotesSearch';
import { Portfolio } from './pages/Portfolio';
import { PostJob } from './pages/PostJob';
import { RecruiterCandidates } from './pages/RecruiterCandidates';
import { ResumeAnalyzer } from './pages/ResumeAnalyzer';

interface AppProps {
  initialRole?: 'signedOut' | 'student' | 'recruiter';
}

export function App({ initialRole = 'student' }: AppProps) {
  return (
    <MotionConfig reducedMotion="user">
      <AppProvider initialRole={initialRole === 'signedOut' ? null : initialRole}>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route element={<RequireRole role="student" />}>
              <Route element={<AppShell />}>
                <Route index element={<Dashboard />} />
                <Route path="notes" element={<NotesSearch />} />
                <Route path="resume" element={<ResumeAnalyzer />} />
                <Route path="jobs" element={<Jobs />} />
                <Route path="portfolio" element={<Portfolio />} />
              </Route>
            </Route>
            <Route path="/recruiter" element={<RequireRole role="recruiter" />}>
              <Route element={<AppShell />}>
                <Route index element={<RecruiterCandidates />} />
                <Route path="post" element={<PostJob />} />
              </Route>
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
        <Toaster position="bottom-right" richColors={false} closeButton />
      </AppProvider>
    </MotionConfig>);

}