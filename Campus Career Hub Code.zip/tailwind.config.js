export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        canvas: '#F7F7F5',
        surface: '#FFFFFF',
        subtle: '#F3F3F1',
        line: '#E6E5E1',
        ink: '#18181B',
        body: '#3F3F46',
        muted: '#6B6B73',
        highlight: '#FCE9B2',
        brand: { DEFAULT: '#C00000', hover: '#9E0000', soft: '#FCEEEE' },
        success: { DEFAULT: '#15803D', soft: '#EAF6EE' },
        warning: { DEFAULT: '#B45309', soft: '#FDF3E3' },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
    },
  },
};
