import React, { useState, useMemo } from 'react';
import { JobPosting, UserProfile, JobMatchResult } from '../types';
import { matchStudentToJobs } from '../utils/dsaEngine';
import { Briefcase, Building2, MapPin, IndianRupee, Calendar, CheckCircle, XCircle, ArrowUpRight, Check, Award, Layers } from 'lucide-react';

interface JobMatchingModuleProps {
  jobs: JobPosting[];
  currentUser: UserProfile;
}

export const JobMatchingModule: React.FC<JobMatchingModuleProps> = ({
  jobs,
  currentUser,
}) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [appliedJobs, setAppliedJobs] = useState<Record<string, boolean>>({});
  const [activeJobDetails, setActiveJobDetails] = useState<JobMatchResult | null>(null);

  // Compute graph-based matches & max-heap ranking
  const rankedMatches: JobMatchResult[] = useMemo(() => {
    return matchStudentToJobs(currentUser.skills, currentUser.cgpa, jobs);
  }, [currentUser, jobs]);

  // Apply filters
  const filteredMatches = useMemo(() => {
    if (filterType === 'all') return rankedMatches;
    return rankedMatches.filter((m) => m.job.type.toLowerCase() === filterType.toLowerCase());
  }, [rankedMatches, filterType]);

  const handleApply = (jobId: string, company: string, role: string) => {
    setAppliedJobs((prev) => ({ ...prev, [jobId]: true }));
    alert(`Application submitted for ${role} at ${company}!\nVerified academic transcript (CGPA: ${currentUser.cgpa}) and GitHub portfolio attached.`);
  };

  return (
    <div className="space-y-8">
      {/* Module Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 border border-rose-200 text-rose-700 text-xs font-mono mb-2">
              <Layers className="w-3.5 h-3.5" />
              <span>Slide 3 & 6: Bipartite Graph Matching & Max-Heap Priority Ranking</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              Job & Internship Matching Engine
            </h1>
            <p className="text-slate-600 text-sm max-w-2xl mt-1">
              Evaluates student skill adjacency against corporate requirements using bipartite graph edge coverage, then ranks opportunities via a logarithmic binary Max-Heap priority queue.
            </p>
          </div>

          {/* Student Profile Snapshot */}
          <div className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.name}
              referrerPolicy="no-referrer"
              className="w-11 h-11 rounded-full object-cover border border-slate-300"
            />
            <div className="text-xs">
              <div className="font-bold text-slate-900">{currentUser.name}</div>
              <div className="text-slate-500 font-mono">CGPA: {currentUser.cgpa} · {currentUser.semester}</div>
              <div className="text-slate-400 text-[11px] truncate max-w-[180px]">
                {currentUser.skills.slice(0, 4).join(', ')}...
              </div>
            </div>
          </div>
        </div>

        {/* Filter row */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Filter By Type:</span>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
              {['all', 'internship', 'full-time'].map((type) => (
                <button
                  key={type}
                  onClick={() => setFilterType(type)}
                  className={`px-3 py-1 rounded-md font-medium capitalize transition-colors cursor-pointer ${
                    filterType === type ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div className="text-slate-500 font-mono hidden sm:block">
            Priority Queue Capacity: {filteredMatches.length} Opportunities Extracted
          </div>
        </div>
      </div>

      {/* Main Layout: Job Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Job Cards List (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {filteredMatches.map((item) => {
            const isApplied = appliedJobs[item.job.id];
            const isSelected = activeJobDetails?.job.id === item.job.id;

            return (
              <div
                key={item.job.id}
                onClick={() => setActiveJobDetails(item)}
                className={`bg-white rounded-xl p-5 border transition-all cursor-pointer relative ${
                  isSelected
                    ? 'border-rose-500 ring-2 ring-rose-100 shadow-md'
                    : 'border-slate-200 hover:border-slate-300 hover:shadow-xs'
                }`}
              >
                {/* Top Bar with Heap Priority Rank & Match Score */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-white bg-slate-900 px-2 py-0.5 rounded">
                      Heap Rank #{item.heapPriorityRank}
                    </span>
                    <span className="text-xs font-mono text-slate-500">
                      {item.job.type}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold">
                    <Award className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{item.matchScore}% Match Fit</span>
                  </div>
                </div>

                {/* Company & Role */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-slate-600 text-xs">
                    <Building2 className="w-4 h-4 text-slate-400" />
                    <span className="font-semibold text-slate-800">{item.job.company}</span>
                    <span>·</span>
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{item.job.location}</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900">
                    {item.job.role}
                  </h3>
                </div>

                {/* Stipend & Deadline */}
                <div className="flex items-center gap-4 text-xs text-slate-600 my-3 font-mono">
                  <div className="flex items-center gap-1 text-slate-900 font-bold">
                    <IndianRupee className="w-3.5 h-3.5 text-rose-600" />
                    <span>{item.job.stipend}</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-500">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Deadline: {item.job.deadline}</span>
                  </div>
                  <div className="text-slate-500 hidden sm:block">
                    Min CGPA: {item.job.minCgpa}
                  </div>
                </div>

                {/* Skill Overlap Preview */}
                <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-slate-500 text-[11px]">Matched Skills:</span>
                    {item.matchedSkills.slice(0, 4).map((skill) => (
                      <span
                        key={skill}
                        className="px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-[11px] font-mono"
                      >
                        ✓ {skill}
                      </span>
                    ))}
                    {item.missingSkills.length > 0 && (
                      <span className="text-[11px] text-rose-600 font-mono">
                        +{item.missingSkills.length} missing
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleApply(item.job.id, item.job.company, item.job.role);
                      }}
                      disabled={isApplied}
                      className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                        isApplied
                          ? 'bg-emerald-100 text-emerald-800 cursor-default'
                          : 'bg-rose-600 hover:bg-rose-700 text-white'
                      }`}
                    >
                      {isApplied ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Applied</span>
                        </>
                      ) : (
                        <>
                          <span>1-Click Apply</span>
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Detailed Graph Matching Inspector (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4 sticky top-20">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide font-mono">
                Bipartite Graph Matching Inspector
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Visualizing edge connectivity between Student Skill set U and Job Requirement set V.
              </p>
            </div>

            {activeJobDetails ? (
              <div className="space-y-4 text-xs">
                <div>
                  <div className="text-slate-500 font-semibold mb-1">Target Role:</div>
                  <div className="font-bold text-slate-900 text-sm">{activeJobDetails.job.role}</div>
                  <div className="text-slate-600">{activeJobDetails.job.company}</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg space-y-2 border border-slate-200 font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Graph Edge Weight:</span>
                    <span className="font-bold text-slate-900">
                      {(activeJobDetails.graphEdgeWeight * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Priority Heap Rank:</span>
                    <span className="font-bold text-rose-600">
                      Rank #{activeJobDetails.heapPriorityRank}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">CGPA Requirement:</span>
                    <span className={currentUser.cgpa >= activeJobDetails.job.minCgpa ? 'text-emerald-600 font-bold' : 'text-rose-600'}>
                      {currentUser.cgpa} / {activeJobDetails.job.minCgpa} (Met)
                    </span>
                  </div>
                </div>

                {/* Graph Skills Comparison */}
                <div className="space-y-2">
                  <div className="font-bold text-slate-800">Required Skills & Match:</div>
                  <div className="space-y-1.5">
                    {activeJobDetails.job.requiredSkills.map((req) => {
                      const hasIt = currentUser.skills.some(
                        (s) => s.toLowerCase() === req.toLowerCase()
                      );
                      return (
                        <div
                          key={req}
                          className="flex items-center justify-between p-2 rounded bg-slate-50 border border-slate-200"
                        >
                          <span className="font-mono text-slate-800">{req}</span>
                          {hasIt ? (
                            <span className="flex items-center gap-1 text-emerald-700 font-bold text-[11px]">
                              <CheckCircle className="w-3.5 h-3.5" /> Matched
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-rose-600 font-bold text-[11px]">
                              <XCircle className="w-3.5 h-3.5" /> Missing
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <div className="font-bold text-slate-800">Role Description:</div>
                  <p className="text-slate-600 leading-relaxed bg-slate-50 p-2.5 rounded border border-slate-200">
                    {activeJobDetails.job.description}
                  </p>
                </div>

                <button
                  onClick={() =>
                    handleApply(
                      activeJobDetails.job.id,
                      activeJobDetails.job.company,
                      activeJobDetails.job.role
                    )
                  }
                  disabled={appliedJobs[activeJobDetails.job.id]}
                  className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold text-xs transition-colors cursor-pointer"
                >
                  {appliedJobs[activeJobDetails.job.id] ? 'Applied' : 'Submit Application Now'}
                </button>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 space-y-2">
                <Briefcase className="w-8 h-8 mx-auto text-slate-300" />
                <p>Click any job posting on the left to inspect its bipartite graph edge breakdown and matching details.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
