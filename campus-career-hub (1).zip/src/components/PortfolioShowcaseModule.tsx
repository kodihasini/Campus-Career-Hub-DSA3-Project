import React, { useState } from 'react';
import { UserProfile } from '../types';
import { MOCK_PROJECTS, UNIVERSITY_INFO } from '../data/mockData';
import { Github, ExternalLink, Star, GitFork, CheckCircle, ShieldCheck, Mail, Download, Sparkles, Building, BookmarkCheck, Heart } from 'lucide-react';

interface PortfolioShowcaseModuleProps {
  currentUser: UserProfile;
  allUsers: UserProfile[];
  onSelectUser: (userId: string) => void;
}

export const PortfolioShowcaseModule: React.FC<PortfolioShowcaseModuleProps> = ({
  currentUser,
  allUsers,
  onSelectUser,
}) => {
  const [shortlisted, setShortlisted] = useState<boolean>(false);
  const [likes, setLikes] = useState<Record<string, number>>({
    proj_01: 34,
    proj_02: 19,
    proj_03: 27
  });

  const handleLike = (id: string) => {
    setLikes((prev) => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
  };

  return (
    <div className="space-y-8">
      {/* Portfolio Profile Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <div className="relative">
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.name}
                referrerPolicy="no-referrer"
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-2 border-slate-200 shadow-sm"
              />
              <div
                className="absolute -bottom-2 -right-2 bg-emerald-600 text-white p-1.5 rounded-full shadow-md"
                title="Verified Academic Record"
              >
                <ShieldCheck className="w-4 h-4" />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
                  {currentUser.name}
                </h1>
                <span className="font-mono text-xs text-rose-700 bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-200 font-bold">
                  Roll No: {currentUser.rollNumber}
                </span>
                <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                  {UNIVERSITY_INFO.team}
                </span>
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-600 font-mono flex-wrap">
                <span className="flex items-center gap-1 font-semibold text-slate-800">
                  <Building className="w-3.5 h-3.5 text-slate-400" />
                  {currentUser.university}
                </span>
                <span>·</span>
                <span>{currentUser.department}</span>
                <span>·</span>
                <span>{currentUser.semester}</span>
              </div>

              <p className="text-xs text-slate-600 max-w-2xl leading-relaxed pt-1">
                {currentUser.bio}
              </p>

              {/* Skills Tags */}
              <div className="pt-2 flex flex-wrap gap-1.5">
                {currentUser.skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-xs font-mono font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Student Switcher & Actions */}
          <div className="flex flex-col sm:items-end gap-3 w-full md:w-auto">
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs w-full sm:w-auto justify-center">
              <span className="text-slate-500 px-2 font-medium">Switch Student:</span>
              {allUsers.map((u) => (
                <button
                  key={u.id}
                  onClick={() => onSelectUser(u.id)}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                    u.id === currentUser.id
                      ? 'bg-white font-bold text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {u.name}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => setShortlisted(!shortlisted)}
                className={`flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                  shortlisted
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                }`}
              >
                <BookmarkCheck className="w-4 h-4" />
                <span>{shortlisted ? 'Candidate Shortlisted' : 'Recruiter Shortlist'}</span>
              </button>

              <button
                onClick={() => alert(`Downloading verified academic dossier for ${currentUser.name} (${currentUser.rollNumber}) with KL University Dean stamps.`)}
                className="flex items-center justify-center gap-1.5 px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                title="Download Verified Dossier"
              >
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Dossier</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Verified Academic & Faculty Guidance Section */}
      <div className="bg-gradient-to-r from-rose-900 to-slate-900 text-white rounded-2xl p-6 sm:p-7 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-rose-300 text-xs font-mono font-semibold">
            <Sparkles className="w-4 h-4" />
            <span>Academic Supervision & Verified Rubric</span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold font-display text-white">
            Supervised by {UNIVERSITY_INFO.mentor}
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            All code repositories, asymptotic complexity benchmarks, and data structures submitted by Team 13 have been validated in the Dept. of CS&IT laboratory under the 25CS2103E course criteria.
          </p>
        </div>

        <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/20">
          <div className="text-center font-mono">
            <div className="text-2xl font-black text-rose-400 tabular-nums">9.38</div>
            <div className="text-[11px] text-slate-300">Team Avg CGPA</div>
          </div>
          <div className="h-8 w-px bg-white/20" />
          <div className="text-center font-mono">
            <div className="text-2xl font-black text-emerald-400 tabular-nums">100%</div>
            <div className="text-[11px] text-slate-300">Lab Verification</div>
          </div>
        </div>
      </div>

      {/* Student Projects Showcase Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 font-display">
            Featured Engineering Projects & Repositories
          </h2>
          <span className="text-xs text-slate-500 font-mono">
            Slide 3 & 8: Projects & GitHub Repositories for Recruiters
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {MOCK_PROJECTS.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-xl p-5 border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-base font-bold text-slate-900 line-clamp-1">
                    {project.title}
                  </h3>
                  <button
                    onClick={() => handleLike(project.id)}
                    className="flex items-center gap-1 text-slate-400 hover:text-rose-600 transition-colors text-xs font-mono cursor-pointer"
                  >
                    <Heart className="w-3.5 h-3.5 fill-rose-500/20 hover:fill-rose-500" />
                    <span>{likes[project.id]}</span>
                  </button>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">
                  {project.description}
                </p>

                {/* Performance Metric */}
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs font-mono text-slate-700">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">
                    Benchmark Result:
                  </span>
                  <span className="text-emerald-700 font-semibold">{project.metrics}</span>
                </div>

                {/* Tech Stack */}
                <div className="flex flex-wrap gap-1">
                  {project.techStack.map((tech) => (
                    <span
                      key={tech}
                      className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[11px] font-mono"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Faculty Review Citation */}
                {project.facultyReview && (
                  <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-lg text-xs space-y-1">
                    <div className="flex items-center gap-1 text-amber-900 font-bold text-[11px]">
                      <CheckCircle className="w-3.5 h-3.5 text-amber-600" />
                      <span>Faculty Endorsement: {project.facultyReview.reviewerName}</span>
                    </div>
                    <p className="text-amber-800 text-[11px] italic">
                      "{project.facultyReview.comment}"
                    </p>
                  </div>
                )}
              </div>

              {/* Footer Actions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3 text-slate-500 font-mono">
                  <span className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 text-amber-500" />
                    {project.starsCount}
                  </span>
                  <span className="flex items-center gap-1">
                    <GitFork className="w-3.5 h-3.5 text-slate-400" />
                    {project.forksCount}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-slate-700 hover:text-slate-900 font-medium px-2 py-1 rounded hover:bg-slate-100 transition-colors"
                  >
                    <Github className="w-3.5 h-3.5" />
                    <span>Repo</span>
                  </a>
                  {project.liveUrl && (
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1 text-rose-600 hover:text-rose-700 font-semibold px-2 py-1 rounded hover:bg-rose-50 transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Live Demo</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
