import React from 'react';
import { ModuleType, UserProfile } from '../types';
import { UNIVERSITY_INFO } from '../data/mockData';
import { BookOpen, FileText, Briefcase, UserCheck, Cpu, Layers } from 'lucide-react';

interface NavbarProps {
  activeModule: ModuleType;
  setActiveModule: (module: ModuleType) => void;
  currentUser: UserProfile;
  onSelectUser: (userId: string) => void;
  allUsers: UserProfile[];
  onOpenSpecModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeModule,
  setActiveModule,
  currentUser,
  onSelectUser,
  allUsers,
  onOpenSpecModal
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Single Brand Wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveModule('search')}
              className="text-left group cursor-pointer"
            >
              <div className="flex items-baseline gap-2">
                <span className="font-display font-black text-xl tracking-tight text-slate-950 group-hover:text-rose-600 transition-colors">
                  Campus Career Hub
                </span>
                <span className="hidden sm:inline-block text-xs font-mono text-slate-400">
                  {UNIVERSITY_INFO.courseCode}
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Clean 5 Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveModule('search')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeModule === 'search'
                  ? 'text-rose-600 bg-rose-50 font-semibold'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Notes Search</span>
            </button>

            <button
              onClick={() => setActiveModule('resume')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeModule === 'resume'
                  ? 'text-rose-600 bg-rose-50 font-semibold'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Resume Analyzer</span>
            </button>

            <button
              onClick={() => setActiveModule('jobs')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeModule === 'jobs'
                  ? 'text-rose-600 bg-rose-50 font-semibold'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Briefcase className="w-4 h-4" />
              <span>Job Matcher</span>
            </button>

            <button
              onClick={() => setActiveModule('portfolio')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeModule === 'portfolio'
                  ? 'text-rose-600 bg-rose-50 font-semibold'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <UserCheck className="w-4 h-4" />
              <span>Portfolios</span>
            </button>

            <button
              onClick={() => setActiveModule('architecture')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeModule === 'architecture'
                  ? 'text-rose-600 bg-rose-50 font-semibold'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Cpu className="w-4 h-4" />
              <span>DSA Engine</span>
            </button>
          </nav>

          {/* Zone 3: Primary Actions & Persona Selector */}
          <div className="flex items-center gap-3">
            {/* Persona Quick Switcher */}
            <div className="flex items-center border border-slate-200 rounded-lg p-0.5 bg-slate-50 text-xs">
              {allUsers.map((user) => {
                const isSelected = user.id === currentUser.id;
                return (
                  <button
                    key={user.id}
                    onClick={() => onSelectUser(user.id)}
                    className={`px-2.5 py-1 rounded-md transition-all cursor-pointer whitespace-nowrap ${
                      isSelected
                        ? 'bg-white font-semibold text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title={`Logged in as ${user.name} (${user.rollNumber})`}
                  >
                    {user.name.split(' ')[1] || user.name}
                  </button>
                );
              })}
            </div>

            {/* Architecture PPT Defense Spec Button */}
            <button
              onClick={onOpenSpecModal}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer whitespace-nowrap shadow-xs"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Project Defense Spec</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Secondary Navigation Row */}
      <div className="md:hidden border-t border-slate-200 px-4 py-2 flex items-center justify-between gap-1 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveModule('search')}
          className={`px-2.5 py-1 rounded-md whitespace-nowrap ${
            activeModule === 'search' ? 'bg-rose-50 text-rose-700 font-semibold' : 'text-slate-600'
          }`}
        >
          Notes Search
        </button>
        <button
          onClick={() => setActiveModule('resume')}
          className={`px-2.5 py-1 rounded-md whitespace-nowrap ${
            activeModule === 'resume' ? 'bg-rose-50 text-rose-700 font-semibold' : 'text-slate-600'
          }`}
        >
          Resume
        </button>
        <button
          onClick={() => setActiveModule('jobs')}
          className={`px-2.5 py-1 rounded-md whitespace-nowrap ${
            activeModule === 'jobs' ? 'bg-rose-50 text-rose-700 font-semibold' : 'text-slate-600'
          }`}
        >
          Jobs
        </button>
        <button
          onClick={() => setActiveModule('portfolio')}
          className={`px-2.5 py-1 rounded-md whitespace-nowrap ${
            activeModule === 'portfolio' ? 'bg-rose-50 text-rose-700 font-semibold' : 'text-slate-600'
          }`}
        >
          Portfolio
        </button>
        <button
          onClick={() => setActiveModule('architecture')}
          className={`px-2.5 py-1 rounded-md whitespace-nowrap ${
            activeModule === 'architecture' ? 'bg-rose-50 text-rose-700 font-semibold' : 'text-slate-600'
          }`}
        >
          DSA Engine
        </button>
      </div>
    </header>
  );
};
