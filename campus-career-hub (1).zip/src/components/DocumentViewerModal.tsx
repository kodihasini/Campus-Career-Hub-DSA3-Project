import React from 'react';
import { AcademicResource } from '../types';
import { X, BookOpen, Download, Bookmark, Share2, Check } from 'lucide-react';

interface DocumentViewerModalProps {
  resource: AcademicResource | null;
  targetPageNumber?: number;
  highlightKeyword?: string;
  onClose: () => void;
}

export const DocumentViewerModal: React.FC<DocumentViewerModalProps> = ({
  resource,
  targetPageNumber,
  highlightKeyword,
  onClose,
}) => {
  const [copied, setCopied] = React.useState(false);
  const [currentPage, setCurrentPage] = React.useState<number>(targetPageNumber || 1);

  React.useEffect(() => {
    if (targetPageNumber) {
      setCurrentPage(targetPageNumber);
    } else if (resource && resource.pages.length > 0) {
      setCurrentPage(resource.pages[0].pageNumber);
    }
  }, [targetPageNumber, resource]);

  if (!resource) return null;

  const activePageData = resource.pages.find(p => p.pageNumber === currentPage) || resource.pages[0];

  const handleShare = () => {
    navigator.clipboard.writeText(
      `${window.location.origin}#view=${resource.id}&page=${currentPage}`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="relative w-full max-w-4xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
                <span>{resource.courseCode}</span>
                <span>·</span>
                <span>{resource.courseName}</span>
                <span>·</span>
                <span>{resource.type}</span>
              </div>
              <h2 className="text-base font-bold text-slate-900 line-clamp-1">
                {resource.title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 rounded-md transition-colors cursor-pointer"
              title="Copy Page Link"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
            </button>
            <button
              onClick={() => alert(`Downloading verified PDF archive: ${resource.title} (${resource.fileSize})`)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF ({resource.fileSize})</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-md hover:bg-slate-200/60 transition-colors cursor-pointer ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Page navigation banner */}
        <div className="px-6 py-2.5 bg-slate-100/70 border-b border-slate-200 flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span>Available Course Pages with Index:</span>
            <div className="flex items-center gap-1">
              {resource.pages.map((p) => (
                <button
                  key={p.pageNumber}
                  onClick={() => setCurrentPage(p.pageNumber)}
                  className={`px-2.5 py-0.5 rounded text-xs font-mono font-medium transition-colors cursor-pointer ${
                    currentPage === p.pageNumber
                      ? 'bg-rose-600 text-white'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  Page {p.pageNumber}
                </button>
              ))}
            </div>
          </div>
          <div className="font-mono text-slate-500">
            Total Course Volume: {resource.totalPages} Pages
          </div>
        </div>

        {/* Body / Exact Page Sheet */}
        <div className="p-8 overflow-y-auto bg-slate-50/50 flex-1 space-y-6">
          <div className="bg-white p-8 rounded-lg border border-slate-200 shadow-xs space-y-6">
            <div className="border-b border-slate-200 pb-4 flex items-center justify-between">
              <div>
                <span className="text-xs uppercase tracking-wider font-mono text-rose-600 font-semibold">
                  Page {currentPage} of {resource.totalPages}
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-1">
                  {activePageData ? activePageData.heading : 'Curriculum Material'}
                </h3>
              </div>
              <div className="flex items-center gap-1 text-xs text-slate-500">
                <Bookmark className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>Verified Syllabus Citation</span>
              </div>
            </div>

            {/* Snippet / Notes text */}
            <div className="prose prose-slate max-w-none text-slate-700 text-sm leading-relaxed space-y-4">
              <p className="bg-slate-50 p-4 rounded-md border border-slate-200 font-mono text-xs text-slate-800 leading-normal">
                {activePageData?.snippet}
              </p>

              <div className="space-y-2 pt-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Key Index Tokens on this Page
                </h4>
                <div className="flex items-center gap-2 text-xs text-slate-600 flex-wrap">
                  {activePageData?.keywords.map((kw, i) => {
                    const isMatched = highlightKeyword && kw.toLowerCase().includes(highlightKeyword.toLowerCase());
                    return (
                      <span
                        key={i}
                        className={`font-mono px-2 py-1 rounded text-xs ${
                          isMatched
                            ? 'bg-rose-100 text-rose-900 font-semibold border border-rose-300'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {kw}
                      </span>
                    );
                  })}
                </div>
              </div>

              <div className="bg-rose-50/50 border border-rose-200/70 p-4 rounded-lg text-xs text-rose-950 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-rose-800">
                  <span>Academic Citation Note:</span>
                </div>
                <p>
                  This page belongs to course syllabus module <strong>{resource.courseCode}</strong>.
                  Referenced in KL University Section 11 lecture materials for exam preparation and campus recruitment interviews.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-white flex items-center justify-between text-xs text-slate-500">
          <span>Campus Career Hub · Inverted Index Document Viewer</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-md transition-colors cursor-pointer"
          >
            Close Document
          </button>
        </div>
      </div>
    </div>
  );
};
