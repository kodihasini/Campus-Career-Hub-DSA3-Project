import React, { useState, useMemo } from 'react';
import { AcademicResource, SearchResult } from '../types';
import { TrieSearchEngine, InvertedIndexEngine } from '../utils/dsaEngine';
import { Search, BookOpen, FileCheck, ArrowRight, Zap, Filter, Sparkles, BookMarked, Download } from 'lucide-react';

interface NotesSearchModuleProps {
  resources: AcademicResource[];
  onOpenResource: (resource: AcademicResource, pageNumber: number, keyword?: string) => void;
}

export const NotesSearchModule: React.FC<NotesSearchModuleProps> = ({
  resources,
  onOpenResource,
}) => {
  const [searchQuery, setSearchQuery] = useState('trie');
  const [selectedCourse, setSelectedCourse] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [algorithmMode, setAlgorithmMode] = useState<'both' | 'trie' | 'inverted'>('both');
  const [executionTime, setExecutionTime] = useState<number>(14);

  // Initialize Trie & Inverted Index Engines
  const { trieEngine, invertedEngine } = useMemo(() => {
    const tEngine = new TrieSearchEngine();
    const iEngine = new InvertedIndexEngine();

    resources.forEach((res) => {
      // Index tags and titles
      res.tags.forEach((tag) => {
        tEngine.insert(tag, res.id, res.pages[0]?.pageNumber || 1);
      });

      // Index pages and keywords
      res.pages.forEach((page) => {
        page.keywords.forEach((kw) => {
          tEngine.insert(kw, res.id, page.pageNumber);
          iEngine.addPosting(kw, {
            resourceId: res.id,
            pageNumber: page.pageNumber,
            termFrequency: 3,
            heading: page.heading,
            snippet: page.snippet,
          });
        });

        // Also index words in the heading & snippet
        const words = (page.heading + ' ' + page.snippet)
          .toLowerCase()
          .replace(/[^a-z0-9\s]/g, '')
          .split(/\s+/)
          .filter((w) => w.length > 3);

        words.slice(0, 30).forEach((word) => {
          tEngine.insert(word, res.id, page.pageNumber);
          iEngine.addPosting(word, {
            resourceId: res.id,
            pageNumber: page.pageNumber,
            termFrequency: 1,
            heading: page.heading,
            snippet: page.snippet,
          });
        });
      });
    });

    return { trieEngine: tEngine, invertedEngine: iEngine };
  }, [resources]);

  // Live Trie Prefix Auto-Complete suggestions
  const trieSuggestions = useMemo(() => {
    if (!searchQuery.trim()) return [];
    return trieEngine.searchPrefix(searchQuery.trim(), 5);
  }, [searchQuery, trieEngine]);

  // Search Results execution
  const searchResults: SearchResult[] = useMemo(() => {
    const start = performance.now();
    const cleanQuery = searchQuery.toLowerCase().trim();
    if (!cleanQuery) return [];

    const resultsMap = new Map<string, SearchResult>();

    // 1. Run Trie lookup
    if (algorithmMode === 'both' || algorithmMode === 'trie') {
      const trieMatches = trieEngine.searchPrefix(cleanQuery, 10);
      trieMatches.forEach((match) => {
        match.postings.forEach((post) => {
          const res = resources.find((r) => r.id === post.resourceId);
          if (res) {
            const pageData = res.pages.find((p) => p.pageNumber === post.pageNumber);
            const key = `${res.id}-${post.pageNumber}`;
            resultsMap.set(key, {
              resource: res,
              matchedPage: post.pageNumber,
              snippet: pageData?.snippet || res.pages[0]?.snippet || '',
              score: 95,
              matchedKeyword: match.word,
              algorithmUsed: 'Trie Lookup',
            });
          }
        });
      });
    }

    // 2. Run Inverted Index search
    if (algorithmMode === 'both' || algorithmMode === 'inverted') {
      const invertedMatches = invertedEngine.searchMultiTerm(cleanQuery);
      invertedMatches.forEach((entry, _key) => {
        entry.postings.forEach((post) => {
          const res = resources.find((r) => r.id === post.resourceId);
          if (res) {
            const key = `${res.id}-${post.pageNumber}`;
            if (!resultsMap.has(key)) {
              resultsMap.set(key, {
                resource: res,
                matchedPage: post.pageNumber,
                snippet: post.snippet,
                score: Math.min(99, 70 + entry.totalScore * 5),
                matchedKeyword: cleanQuery,
                algorithmUsed: 'Inverted Index Posting',
              });
            }
          }
        });
      });
    }

    // Filter by course & type
    let finalResults = Array.from(resultsMap.values());
    if (selectedCourse !== 'all') {
      finalResults = finalResults.filter((r) => r.resource.courseCode === selectedCourse);
    }
    if (selectedType !== 'all') {
      finalResults = finalResults.filter((r) => r.resource.type === selectedType);
    }

    const end = performance.now();
    setExecutionTime(Math.max(2, Math.round(end - start)));

    return finalResults.sort((a, b) => b.score - a.score);
  }, [searchQuery, algorithmMode, selectedCourse, selectedType, trieEngine, invertedEngine, resources]);

  const quickTerms = [
    { label: 'Trie Prefix', query: 'trie' },
    { label: 'DSA-3 PYQs', query: 'pyq' },
    { label: 'Bipartite Matching', query: 'bipartite' },
    { label: 'PostgreSQL GIN', query: 'postgresql' },
    { label: 'Operating Systems Paging', query: 'paging' },
    { label: 'Max-Heap Ranking', query: 'heap' },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Banner with Search Deck */}
      <div className="relative rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-rose-950 p-6 md:p-10 text-white shadow-xl overflow-hidden">
        {/* Subtle grid pattern background */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-400/30 text-rose-300 text-xs font-mono">
            <Zap className="w-3.5 h-3.5" />
            <span>Slide 3 & 8 Spec: Sub-Second Page-Accurate Search Engine</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight font-display text-white">
            Smart Notes & Curriculum Search
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Query across course notes, Previous Year Questions (PYQs), lab manuals, and assignments with exact page-level pinpointing powered by Trie trees and Inverted Index postings.
          </p>

          {/* Search Box */}
          <div className="pt-2">
            <div className="relative flex items-center">
              <div className="absolute left-4 text-slate-400 pointer-events-none">
                <Search className="w-5 h-5" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search keywords (e.g. Trie, Bipartite Graph, GIN Index, Paging, Dynamic Programming)..."
                className="w-full pl-12 pr-28 py-3.5 text-sm sm:text-base bg-white text-slate-900 rounded-xl shadow-lg focus:outline-none focus:ring-2 focus:ring-rose-500 font-sans"
              />
              <button
                onClick={() => setSearchQuery(searchQuery)}
                className="absolute right-2 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                Search
              </button>
            </div>

            {/* Trie Auto-complete dropdown */}
            {trieSuggestions.length > 0 && searchQuery.length >= 2 && (
              <div className="mt-2 p-2 bg-white/95 backdrop-blur-md rounded-lg border border-slate-200 shadow-md text-slate-800 text-xs flex flex-wrap items-center gap-2">
                <span className="text-slate-500 font-mono flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  Trie Prefix Completions:
                </span>
                {trieSuggestions.map((s) => (
                  <button
                    key={s.word}
                    onClick={() => setSearchQuery(s.word)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-rose-50 hover:text-rose-700 rounded text-slate-700 font-mono transition-colors cursor-pointer"
                  >
                    {s.word} <span className="text-slate-400">({s.postings.length} pages)</span>
                  </button>
                ))}
              </div>
            )}

            {/* Quick Terms */}
            <div className="mt-3 flex items-center gap-2 overflow-x-auto text-xs text-slate-300">
              <span className="text-slate-400 shrink-0 font-medium">Quick Query:</span>
              {quickTerms.map((item) => (
                <button
                  key={item.label}
                  onClick={() => setSearchQuery(item.query)}
                  className={`px-2.5 py-1 rounded-md transition-colors shrink-0 cursor-pointer ${
                    searchQuery.toLowerCase() === item.query.toLowerCase()
                      ? 'bg-rose-500 text-white font-semibold'
                      : 'bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Control & Filter Deck */}
      <div className="bg-white rounded-xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        {/* Course Filter */}
        <div className="flex items-center gap-3 text-xs sm:text-sm">
          <Filter className="w-4 h-4 text-slate-500" />
          <span className="text-slate-600 font-medium">Course:</span>
          <select
            value={selectedCourse}
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
          >
            <option value="all">All Courses (3rd Year)</option>
            <option value="25CS2103E">25CS2103E: Data Structures - 3</option>
            <option value="25CS2101">25CS2101: Operating Systems</option>
            <option value="25CS2102">25CS2102: DBMS & PostgreSQL</option>
            <option value="25CS2104">25CS2104: Computer Networks</option>
          </select>

          <span className="text-slate-600 font-medium ml-2">Type:</span>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
          >
            <option value="all">All Formats</option>
            <option value="PYQ">PYQs (Past Questions)</option>
            <option value="Lecture Notes">Lecture Notes</option>
            <option value="Assignment">Assignments</option>
          </select>
        </div>

        {/* Algorithm Mode Toggle */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 font-medium">DSA Engine Mode:</span>
          <div className="inline-flex p-1 bg-slate-100 rounded-lg border border-slate-200">
            <button
              onClick={() => setAlgorithmMode('both')}
              className={`px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors ${
                algorithmMode === 'both' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Hybrid (Trie + Postings)
            </button>
            <button
              onClick={() => setAlgorithmMode('trie')}
              className={`px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors ${
                algorithmMode === 'trie' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Trie Only O(L)
            </button>
            <button
              onClick={() => setAlgorithmMode('inverted')}
              className={`px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors ${
                algorithmMode === 'inverted' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Inverted Index
            </button>
          </div>
        </div>
      </div>

      {/* Latency & Result Metrics Header */}
      <div className="flex items-center justify-between text-xs text-slate-500 px-1 font-mono">
        <div>
          <span>Retrieved {searchResults.length} page-level results for </span>
          <strong className="text-slate-800">"{searchQuery}"</strong>
        </div>
        <div className="flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
          <Zap className="w-3 h-3" />
          <span>Execution Time: {executionTime}ms (Sub-second retrieval)</span>
        </div>
      </div>

      {/* Results Feed */}
      {searchResults.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border border-slate-200 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">No exact page matches found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Try searching for core DSA topics like "trie", "bipartite", "radix", "gin index", "paging", or "pyq".
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {searchResults.map((result, idx) => (
            <div
              key={`${result.resource.id}-${result.matchedPage}-${idx}`}
              className="bg-white rounded-xl p-5 border border-slate-200 hover:border-rose-300 hover:shadow-md transition-all space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-rose-700 bg-rose-50 px-2.5 py-0.5 rounded border border-rose-200">
                    Exact Page {result.matchedPage}
                  </span>
                  <span className="text-xs font-mono text-slate-500">
                    {result.resource.courseCode} · {result.resource.courseName}
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-xs text-slate-500">
                    {result.resource.type}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="font-mono text-slate-400 text-[11px]">
                    Algorithm: {result.algorithmUsed}
                  </span>
                  <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-mono font-bold text-[11px]">
                    {result.score}% Match
                  </span>
                </div>
              </div>

              {/* Resource Title */}
              <div>
                <h3 className="text-base font-bold text-slate-900 hover:text-rose-600 transition-colors">
                  {result.resource.title}
                </h3>
              </div>

              {/* Matched Snippet Preview */}
              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 font-mono text-xs text-slate-700 leading-relaxed">
                <div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold mb-1">
                  Excerpt from Page {result.matchedPage}:
                </div>
                <p>
                  {result.snippet}
                </p>
              </div>

              {/* Action Bar */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <BookMarked className="w-3.5 h-3.5 text-slate-400" />
                  <span>Syllabus Volume: {result.resource.totalPages} Pages</span>
                  <span>·</span>
                  <span>{result.resource.downloadCount} Student Downloads</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => alert(`Downloading verified PDF archive: ${result.resource.title}`)}
                    className="p-1.5 text-slate-500 hover:text-slate-800 rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
                    title="Download document"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onOpenResource(result.resource, result.matchedPage, searchQuery)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-900 hover:bg-rose-600 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <span>View Page {result.matchedPage} in Viewer</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
