import React, { useState, useMemo } from 'react';
import { AcademicResource, ResumeSkillAnalysis, UserProfile } from '../types';
import { analyzeResumeATS } from '../utils/dsaEngine';
import { SAMPLE_RESUMES } from '../data/mockData';
import { FileText, CheckCircle2, AlertTriangle, ArrowRight, BookOpen, Sparkles, RefreshCw, Zap, Copy, Check } from 'lucide-react';

interface ResumeAnalyzerModuleProps {
  resources: AcademicResource[];
  currentUser: UserProfile;
  onOpenResource: (resource: AcademicResource, pageNumber: number, keyword?: string) => void;
}

export const ResumeAnalyzerModule: React.FC<ResumeAnalyzerModuleProps> = ({
  resources,
  currentUser,
  onOpenResource,
}) => {
  const [selectedPreset, setSelectedPreset] = useState<'hasini' | 'lavanya' | 'custom'>('hasini');
  const [resumeText, setResumeText] = useState<string>(SAMPLE_RESUMES.hasini);
  const [targetRole, setTargetRole] = useState<string>('SDE Intern');
  const [copied, setCopied] = useState<boolean>(false);

  // Sync with current user when user changes in top bar
  React.useEffect(() => {
    if (currentUser.id === 'user_lavanya') {
      setSelectedPreset('lavanya');
      setResumeText(SAMPLE_RESUMES.lavanya);
    } else if (currentUser.id === 'user_hasini') {
      setSelectedPreset('hasini');
      setResumeText(SAMPLE_RESUMES.hasini);
    }
  }, [currentUser]);

  const handleSelectPreset = (preset: 'hasini' | 'lavanya' | 'custom') => {
    setSelectedPreset(preset);
    if (preset === 'hasini') setResumeText(SAMPLE_RESUMES.hasini);
    else if (preset === 'lavanya') setResumeText(SAMPLE_RESUMES.lavanya);
  };

  // Run real-time ATS analysis
  const analysis: ResumeSkillAnalysis = useMemo(() => {
    return analyzeResumeATS(resumeText, targetRole, resources);
  }, [resumeText, targetRole, resources]);

  const handleCopyAnalysis = () => {
    const text = `ATS Score: ${analysis.atsScore}%\nTarget Role: ${targetRole}\nMatched Skills: ${analysis.matchedSkills.join(', ')}\nMissing Skills: ${analysis.missingSkills.join(', ')}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddSkillToResume = (skill: string) => {
    const addition = `\n• Demonstrated knowledge in ${skill} through completed academic coursework and lab assignments.`;
    setResumeText(prev => prev + addition);
    setSelectedPreset('custom');
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 border border-rose-200 text-rose-700 text-xs font-mono mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Slide 3 & 6: ATS Compatibility Scorer & Missing Skill Detector</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              Resume Analyzer & Curriculum Skill Bridge
            </h1>
            <p className="text-slate-600 text-sm max-w-2xl mt-1">
              Scans technical resumes against recruiter target profiles, computes ATS scores, and automatically links missing competencies to your university lecture notes and PYQs.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleCopyAnalysis}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              <span>Copy Scorecard</span>
            </button>
          </div>
        </div>

        {/* Target Role & Preset Switcher */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Target Career Track:</span>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
              {['SDE Intern', 'Full Stack Developer', 'AI / ML Engineer', 'Cloud / DevOps Engineer'].map((role) => (
                <button
                  key={role}
                  onClick={() => setTargetRole(role)}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                    targetRole === role
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Resume Source:</span>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
              <button
                onClick={() => handleSelectPreset('hasini')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                  selectedPreset === 'hasini' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                }`}
              >
                K. Hasini (Team 13)
              </button>
              <button
                onClick={() => handleSelectPreset('lavanya')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                  selectedPreset === 'lavanya' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                }`}
              >
                L. Lavanya (Team 13)
              </button>
              <button
                onClick={() => handleSelectPreset('custom')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                  selectedPreset === 'custom' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                }`}
              >
                Custom Text
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: ATS Results Dashboard + Resume Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: ATS Scorecard & Academic Skill Bridge (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[11px] uppercase tracking-wider font-mono text-slate-500 font-semibold">
                ATS Compatibility
              </span>
              <div className="text-3xl font-extrabold font-display tabular-nums text-slate-900 flex items-baseline gap-1">
                <span>{analysis.atsScore}</span>
                <span className="text-sm font-sans text-slate-400">/ 100</span>
              </div>
              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${
                    analysis.atsScore >= 80 ? 'bg-emerald-500' : analysis.atsScore >= 60 ? 'bg-amber-500' : 'bg-rose-500'
                  }`}
                  style={{ width: `${analysis.atsScore}%` }}
                />
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[11px] uppercase tracking-wider font-mono text-slate-500 font-semibold">
                Matched Core Skills
              </span>
              <div className="text-3xl font-extrabold font-display tabular-nums text-emerald-600">
                {analysis.matchedSkills.length}
              </div>
              <span className="text-xs text-slate-500">
                Found in target profile
              </span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[11px] uppercase tracking-wider font-mono text-slate-500 font-semibold">
                Missing Skills
              </span>
              <div className="text-3xl font-extrabold font-display tabular-nums text-rose-600">
                {analysis.missingSkills.length}
              </div>
              <span className="text-xs text-slate-500">
                Flagged by ATS filter
              </span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[11px] uppercase tracking-wider font-mono text-slate-500 font-semibold">
                Action Verbs
              </span>
              <div className="text-3xl font-extrabold font-display tabular-nums text-slate-800">
                {analysis.actionVerbsCount}
              </div>
              <span className="text-xs text-slate-500">
                Measurable verbs
              </span>
            </div>
          </div>

          {/* Matched & Missing Skills Breakdown */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide font-mono">
              Skill Coverage Breakdown ({targetRole})
            </h3>

            {/* Matched Skills */}
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Detected Keywords ({analysis.matchedSkills.length}):</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {analysis.matchedSkills.length === 0 ? (
                  <span className="text-xs text-slate-400 italic">No matching keywords found.</span>
                ) : (
                  analysis.matchedSkills.map((skill) => (
                    <span
                      key={skill}
                      className="px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-xs font-medium font-mono"
                    >
                      ✓ {skill}
                    </span>
                  ))
                )}
              </div>
            </div>

            {/* Missing Skills */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs font-semibold text-rose-800">
                <div className="flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  <span>Missing High-Priority Keywords ({analysis.missingSkills.length}):</span>
                </div>
                <span className="text-[11px] text-slate-400 font-normal">Click "+ Add" to patch</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {analysis.missingSkills.length === 0 ? (
                  <span className="text-xs text-emerald-600 font-medium">All target skills present in resume!</span>
                ) : (
                  analysis.missingSkills.map((skill) => (
                    <div
                      key={skill}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-rose-50 text-rose-800 border border-rose-200 rounded text-xs font-medium font-mono"
                    >
                      <span>✗ {skill}</span>
                      <button
                        onClick={() => handleAddSkillToResume(skill)}
                        className="text-[10px] bg-rose-200/80 hover:bg-rose-300 text-rose-900 px-1 py-0.5 rounded cursor-pointer transition-colors"
                        title="Add bullet to resume"
                      >
                        + Add
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Academic Bridge: Linking Missing Skills to University Resources */}
          <div className="bg-slate-900 text-white rounded-xl p-6 shadow-md space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-rose-400" />
                <h3 className="text-base font-bold font-display text-white">
                  Academic Skill Bridge (Syllabus Integration)
                </h3>
              </div>
              <span className="text-xs font-mono text-rose-300 bg-rose-500/20 px-2 py-0.5 rounded border border-rose-500/30">
                Core Value Proposition
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Unlike generic resume checkers (Zety, Resume Worded) that work in isolation, Campus Career Hub links detected skill gaps directly to your semester coursework and PYQs so you can immediately study and verify the concepts:
            </p>

            <div className="space-y-3 pt-1">
              {analysis.feedback.map((item, index) => {
                if (!item.recommendedResource) return null;
                const rec = item.recommendedResource;
                const res = resources.find((r) => r.courseCode === rec.courseCode);

                return (
                  <div
                    key={index}
                    className="p-3.5 bg-slate-800/90 rounded-lg border border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="text-rose-400 font-semibold flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5" />
                        <span>{item.message}</span>
                      </div>
                      <div className="text-slate-300 font-mono text-[11px]">
                        <strong>{rec.courseCode}</strong>: {rec.title} · Exact <strong>Page {rec.page}</strong>
                      </div>
                    </div>

                    {res && (
                      <button
                        onClick={() => onOpenResource(res, rec.page, '')}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
                      >
                        <span>Study Page {rec.page}</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                );
              })}

              {analysis.feedback.every((f) => !f.recommendedResource) && (
                <div className="p-3 bg-slate-800/50 rounded-lg text-xs text-slate-400 text-center">
                  All critical technical areas are fully backed by completed coursework!
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Live Resume Text & Interactive Editor (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col h-[650px] overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-slate-500" />
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono">
                Resume Content Buffer
              </span>
            </div>
            <button
              onClick={() => handleSelectPreset(selectedPreset)}
              className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 transition-colors cursor-pointer"
              title="Reset text"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>

          <div className="flex-1 p-3 bg-slate-900/5">
            <textarea
              value={resumeText}
              onChange={(e) => {
                setResumeText(e.target.value);
                setSelectedPreset('custom');
              }}
              placeholder="Paste student resume text here..."
              className="w-full h-full p-4 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-800 leading-relaxed focus:outline-none focus:ring-2 focus:ring-rose-500 resize-none"
            />
          </div>

          <div className="p-3 bg-white border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
            <span>{resumeText.length} characters · {resumeText.split(/\s+/).filter(Boolean).length} words</span>
            <span className="text-emerald-700 font-mono font-medium">Real-time Aho-Corasick Scan Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};
