import React, { useState } from 'react';
import { UNIVERSITY_INFO } from '../data/mockData';
import { Cpu, Network, Database, Layers, ArrowRight, Zap, Code2, GitBranch, CheckCircle } from 'lucide-react';

export const DsaArchitectureModule: React.FC = () => {
  const [interactivePrefix, setInteractivePrefix] = useState<string>('tri');

  const trieSampleTree = [
    { char: 'ROOT', level: 0, active: true },
    { char: 't', level: 1, active: interactivePrefix.toLowerCase().startsWith('t') },
    { char: 'r', level: 2, active: interactivePrefix.toLowerCase().startsWith('tr') },
    { char: 'i', level: 3, active: interactivePrefix.toLowerCase().startsWith('tri') },
    { char: 'e', level: 4, active: interactivePrefix.toLowerCase().startsWith('trie'), isWord: true, postings: 'Doc: 25CS2103E, Page 7' },
  ];

  const postingsMock = [
    { term: 'trie', docId: '25CS2103E_Notes', page: 7, tf: 8, heading: '7.1 Standard Trie Construction' },
    { term: 'inverted index', docId: '25CS2103E_Notes', page: 14, tf: 6, heading: '7.4 Inverted Index Architecture' },
    { term: 'bipartite', docId: '25CS2103E_PYQ_2025', page: 3, tf: 5, heading: 'Q2(b): Bipartite Graph Matching' },
    { term: 'gin index', docId: '25CS2102_DBMS', page: 11, tf: 4, heading: '11.3 Generalized Inverted Index' },
    { term: 'max-heap', docId: '25CS2103E_PYQ_2025', page: 3, tf: 4, heading: 'Q2(b): Max-Heap Priority Ranking' },
  ];

  return (
    <div className="space-y-8">
      {/* Module Title Banner */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-800 text-xs font-mono mb-2">
              <Code2 className="w-3.5 h-3.5 text-rose-600" />
              <span>Course: {UNIVERSITY_INFO.courseCode} · {UNIVERSITY_INFO.courseName}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              DSA Architecture & Core System Engine
            </h1>
            <p className="text-slate-600 text-sm max-w-2xl mt-1">
              Engineered by {UNIVERSITY_INFO.team} under guidance of {UNIVERSITY_INFO.mentor}. Unifying textbook algorithmic paradigms with production software architecture.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-rose-50 border border-rose-200 p-3 rounded-xl font-mono text-xs text-rose-900">
            <Zap className="w-4 h-4 text-rose-600" />
            <div>
              <div className="font-bold">Benchmarked Latency:</div>
              <div>Sub-second exact page lookup (&lt;150ms)</div>
            </div>
          </div>
        </div>
      </div>

      {/* 3-Tier Web Architecture Diagram */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-rose-400" />
            <h2 className="text-lg sm:text-xl font-bold font-display text-white">
              End-to-End Full-Stack System Architecture (Slide 3 & 9)
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-400 bg-slate-800 px-2.5 py-1 rounded">
            React · FastAPI · PostgreSQL
          </span>
        </div>

        {/* Visual 3-tier pipeline */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
          {/* Tier 1 */}
          <div className="bg-slate-800/90 rounded-xl p-5 border border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-rose-400 font-bold">
                Tier 1: Client Layer
              </span>
              <Cpu className="w-4 h-4 text-slate-400" />
            </div>
            <h3 className="text-base font-bold text-white">React.js Single Page App</h3>
            <ul className="text-xs text-slate-300 space-y-1.5 font-mono">
              <li>• Responsive Tailwind CSS v4 design</li>
              <li>• Client-side Trie auto-complete buffer</li>
              <li>• Interactive ATS resume editor</li>
              <li>• Portfolio & GitHub showcases</li>
              <li>• Zero-latency modal viewports</li>
            </ul>
          </div>

          {/* Tier 2 */}
          <div className="bg-slate-800/90 rounded-xl p-5 border border-rose-500/50 shadow-md space-y-3 relative">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-amber-400 font-bold">
                Tier 2: Algorithmic Engine
              </span>
              <GitBranch className="w-4 h-4 text-amber-400" />
            </div>
            <h3 className="text-base font-bold text-white">FastAPI Python REST API</h3>
            <ul className="text-xs text-slate-300 space-y-1.5 font-mono">
              <li>• Prefix Trie traversal ($O(L)$ time)</li>
              <li>• Inverted Index postings intersections</li>
              <li>• Bipartite Graph matching engine</li>
              <li>• Binary Max-Heap priority ranking</li>
              <li>• Aho-Corasick multi-string pattern scan</li>
            </ul>
          </div>

          {/* Tier 3 */}
          <div className="bg-slate-800/90 rounded-xl p-5 border border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-emerald-400 font-bold">
                Tier 3: Storage Layer
              </span>
              <Database className="w-4 h-4 text-emerald-400" />
            </div>
            <h3 className="text-base font-bold text-white">PostgreSQL with GIN Index</h3>
            <ul className="text-xs text-slate-300 space-y-1.5 font-mono">
              <li>• GIN tables for page-level inverted index</li>
              <li>• Composite index (course_id, page_no)</li>
              <li>• Student verified academic transcripts</li>
              <li>• Recruiter job postings & applicant tracking</li>
              <li>• ACID transactional guarantees</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Interactive Trie & Inverted Index Sandbox */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 font-display">
              Live Algorithmic Sandbox: Trie Traversal & Postings List
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              Type any prefix below to visualize real-time Trie path descent and corresponding inverted index postings lookup.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={interactivePrefix}
              onChange={(e) => setInteractivePrefix(e.target.value)}
              placeholder="e.g. trie, rad, gin..."
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-rose-500 w-36"
            />
          </div>
        </div>

        {/* Visual Trie Path */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
          <div className="text-xs font-bold text-slate-700 uppercase font-mono tracking-wider flex items-center justify-between">
            <span>Trie Prefix Node Chain</span>
            <span className="text-slate-400">Time Complexity: O(L) where L = {interactivePrefix.length} chars</span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto py-2">
            {trieSampleTree.map((node, i) => (
              <React.Fragment key={i}>
                <div
                  className={`flex flex-col items-center justify-center w-14 h-14 rounded-xl font-mono text-sm font-bold border transition-all ${
                    node.active
                      ? 'bg-rose-600 text-white border-rose-700 shadow-md scale-105'
                      : 'bg-white text-slate-400 border-slate-200'
                  }`}
                >
                  <span className="text-base">{node.char}</span>
                  <span className="text-[9px] opacity-80">Lvl {node.level}</span>
                </div>
                {i < trieSampleTree.length - 1 && (
                  <ArrowRight className="w-4 h-4 text-slate-400 shrink-0" />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Postings Table */}
        <div className="space-y-2">
          <div className="text-xs font-bold text-slate-700 uppercase font-mono tracking-wider">
            Inverted Index Postings Table: Keyword $\to$ (Document, Exact Page, Term Frequency)
          </div>
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-mono">
                <tr>
                  <th className="p-3">Keyword Token</th>
                  <th className="p-3">Document Reference</th>
                  <th className="p-3">Exact Page Coordinates</th>
                  <th className="p-3">Term Frequency (TF)</th>
                  <th className="p-3">Syllabus Heading</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {postingsMock.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80">
                    <td className="p-3 font-bold text-rose-700">{row.term}</td>
                    <td className="p-3 text-slate-700">{row.docId}</td>
                    <td className="p-3 font-bold text-slate-900">Page #{row.page}</td>
                    <td className="p-3 tabular-nums text-slate-600">{row.tf} occurrences</td>
                    <td className="p-3 font-sans text-slate-600">{row.heading}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Algorithmic Complexity Reference Matrix */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-lg font-bold text-slate-900 font-display">
          Course 25CS2103E Algorithmic Benchmark & Complexity Matrix
        </h2>

        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-mono">
              <tr>
                <th className="p-3.5">Module</th>
                <th className="p-3.5">Data Structure / Algorithm</th>
                <th className="p-3.5">Time Complexity</th>
                <th className="p-3.5">Space Complexity</th>
                <th className="p-3.5">System Advantage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-slate-700">
              <tr>
                <td className="p-3.5 font-bold text-slate-900">Smart Notes Search</td>
                <td className="p-3.5 text-rose-600 font-semibold">Trie (Prefix Tree)</td>
                <td className="p-3.5 tabular-nums">O(L) query time</td>
                <td className="p-3.5 tabular-nums">O(N · Σ) compacted</td>
                <td className="p-3.5 font-sans">Instant sub-second auto-complete across thousands of terms</td>
              </tr>
              <tr>
                <td className="p-3.5 font-bold text-slate-900">Page Pinpointing</td>
                <td className="p-3.5 text-rose-600 font-semibold">Inverted Index + Postings</td>
                <td className="p-3.5 tabular-nums">O(1) hash + O(P) postings</td>
                <td className="p-3.5 tabular-nums">O(Total Distinct Tokens)</td>
                <td className="p-3.5 font-sans">Direct jumps to exact page numbers without scanning full PDFs</td>
              </tr>
              <tr>
                <td className="p-3.5 font-bold text-slate-900">Job Skill Matching</td>
                <td className="p-3.5 text-rose-600 font-semibold">Bipartite Graph Matching</td>
                <td className="p-3.5 tabular-nums">O(|V| + |E|)</td>
                <td className="p-3.5 tabular-nums">O(|V| + |E|)</td>
                <td className="p-3.5 font-sans">Weighted edge coverage between candidate skills and job requirements</td>
              </tr>
              <tr>
                <td className="p-3.5 font-bold text-slate-900">Placement Ranking</td>
                <td className="p-3.5 text-rose-600 font-semibold">Binary Max-Heap (Priority Queue)</td>
                <td className="p-3.5 tabular-nums">O(K log N) for top-K</td>
                <td className="p-3.5 tabular-nums">O(N)</td>
                <td className="p-3.5 font-sans">Extracts highest-suitability matches in logarithmic time</td>
              </tr>
              <tr>
                <td className="p-3.5 font-bold text-slate-900">Resume Analyzer</td>
                <td className="p-3.5 text-rose-600 font-semibold">Aho-Corasick Multi-Pattern</td>
                <td className="p-3.5 tabular-nums">O(Text_Length + Matches)</td>
                <td className="p-3.5 tabular-nums">O(Total Pattern Length)</td>
                <td className="p-3.5 font-sans">Single linear pass extracts 120+ technical competencies simultaneously</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
