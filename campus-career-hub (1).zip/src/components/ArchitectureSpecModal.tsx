import React, { useState } from 'react';
import { UNIVERSITY_INFO } from '../data/mockData';
import { X, CheckCircle, ArrowRight, Layers, Cpu, Server, Terminal, BookOpen, ShieldAlert, Sparkles, ChevronRight } from 'lucide-react';

interface ArchitectureSpecModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureSpecModal: React.FC<ArchitectureSpecModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'flow' | 'requirements' | 'slides' | 'results' | 'future'>('flow');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs">
      <div className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600 flex items-center justify-center font-bold text-white shadow-xs">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-rose-300">
                <span>{UNIVERSITY_INFO.courseCode}</span>
                <span>·</span>
                <span>{UNIVERSITY_INFO.team}</span>
                <span>·</span>
                <span>{UNIVERSITY_INFO.institution}</span>
              </div>
              <h2 className="text-lg font-bold font-display text-white">
                Project Defense & Technical Architecture Specification
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="px-6 py-2.5 bg-slate-100 border-b border-slate-200 flex items-center gap-2 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('flow')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'flow' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Slide 7: System Flow Chart
          </button>
          <button
            onClick={() => setActiveTab('requirements')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'requirements' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Slide 9: Hardware & Software Stack
          </button>
          <button
            onClick={() => setActiveTab('results')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'results' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Slide 8: Results & Benchmark
          </button>
          <button
            onClick={() => setActiveTab('slides')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'slides' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Problem & Objectives (Slide 4, 5, 6)
          </button>
          <button
            onClick={() => setActiveTab('future')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'future' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Slide 11: Future Scope
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1 text-slate-800 text-sm">
          {activeTab === 'flow' && (
            <div className="space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-mono font-bold text-rose-600 uppercase tracking-wider">
                  Slide 7 · Architectural Flow Chart
                </span>
                <h3 className="text-xl font-bold font-display text-slate-900">
                  Step-by-Step User & Algorithmic Execution Pipeline
                </h3>
                <p className="text-xs text-slate-600">
                  The unified data pipeline transitions a student from authentication to high-speed academic lookup and targeted recruitment outcomes.
                </p>
              </div>

              {/* Interactive Flow Chart Boxes */}
              <div className="flex flex-col items-center space-y-4 max-w-xl mx-auto py-2">
                {/* Step 1 */}
                <div className="w-full bg-rose-50 border-2 border-rose-500 rounded-xl p-4 text-center shadow-xs">
                  <div className="text-xs font-mono font-bold text-rose-800 uppercase tracking-wider">Step 1</div>
                  <div className="font-bold text-slate-900 text-base">Student Login / Sign-up</div>
                  <div className="text-xs text-slate-600 mt-1">
                    Verified university roll number, department credentials, and loaded skill profile
                  </div>
                </div>

                <div className="flex justify-center text-rose-500">
                  <ArrowRight className="w-5 h-5 rotate-90" />
                </div>

                {/* Step 2 */}
                <div className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-4 text-center shadow-xs">
                  <div className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">Step 2</div>
                  <div className="font-bold text-slate-900 text-base">Choose Module</div>
                  <div className="text-xs text-slate-600 mt-1">
                    Smart Notes Search · Resume Analyzer · Job & Internship Matcher · Portfolio Showcase
                  </div>
                </div>

                <div className="flex justify-center text-slate-400">
                  <ArrowRight className="w-5 h-5 rotate-90" />
                </div>

                {/* Step 3 */}
                <div className="w-full bg-slate-900 text-white border-2 border-slate-950 rounded-xl p-4 text-center shadow-md">
                  <div className="text-xs font-mono font-bold text-rose-400 uppercase tracking-wider">Step 3 · Algorithmic Core</div>
                  <div className="font-bold text-white text-base">Query Processed via DSA Engine</div>
                  <div className="text-xs text-slate-300 mt-1 font-mono">
                    Trie (Prefix lookup) · Inverted Index (Postings) · Graph (Bipartite edge) · Priority Queue (Max-Heap)
                  </div>
                </div>

                <div className="flex justify-center text-slate-400">
                  <ArrowRight className="w-5 h-5 rotate-90" />
                </div>

                {/* Step 4 */}
                <div className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl p-4 text-center shadow-xs">
                  <div className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">Step 4</div>
                  <div className="font-bold text-slate-900 text-base">Ranked Results / Recommendations Returned</div>
                  <div className="text-xs text-slate-600 mt-1">
                    Exact note page number, computed ATS score, missing skills list, and max-heap opportunity order
                  </div>
                </div>

                <div className="flex justify-center text-slate-400">
                  <ArrowRight className="w-5 h-5 rotate-90" />
                </div>

                {/* Step 5 */}
                <div className="w-full bg-emerald-50 border-2 border-emerald-600 rounded-xl p-4 text-center shadow-xs">
                  <div className="text-xs font-mono font-bold text-emerald-800 uppercase tracking-wider">Step 5 · Actionable Outcome</div>
                  <div className="font-bold text-slate-900 text-base">Student Views Results & Takes Action</div>
                  <div className="text-xs text-slate-600 mt-1">
                    Read exact page of PYQ · Bridge missing skill via coursework · 1-click apply to ranked internship
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'requirements' && (
            <div className="space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-mono font-bold text-rose-600 uppercase tracking-wider">
                  Slide 9 · Hardware & Software Requirements
                </span>
                <h3 className="text-xl font-bold font-display text-slate-900">
                  Platform Technical Specifications
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Hardware */}
                <div className="p-6 rounded-xl border border-slate-200 bg-slate-50 space-y-4">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-5 h-5 text-rose-600" />
                    <h4 className="font-bold text-slate-900">Hardware Requirements</h4>
                  </div>
                  <ul className="text-xs text-slate-700 space-y-3 font-mono">
                    <li className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Processor:</span>
                      <span className="font-bold text-slate-900">Intel Core i5 / AMD Ryzen 5 or higher</span>
                    </li>
                    <li className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">RAM:</span>
                      <span className="font-bold text-slate-900">8 GB minimum (16 GB recommended)</span>
                    </li>
                    <li className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Storage:</span>
                      <span className="font-bold text-slate-900">256 GB SSD or higher</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-slate-500">Network:</span>
                      <span className="font-bold text-slate-900">Stable broadband internet connection</span>
                    </li>
                  </ul>
                </div>

                {/* Software */}
                <div className="p-6 rounded-xl border border-slate-200 bg-slate-50 space-y-4">
                  <div className="flex items-center gap-2">
                    <Server className="w-5 h-5 text-rose-600" />
                    <h4 className="font-bold text-slate-900">Software Requirements</h4>
                  </div>
                  <ul className="text-xs text-slate-700 space-y-3 font-mono">
                    <li className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Frontend:</span>
                      <span className="font-bold text-slate-900">React.js (SPA Architecture)</span>
                    </li>
                    <li className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Backend:</span>
                      <span className="font-bold text-slate-900">FastAPI (Python REST Engine)</span>
                    </li>
                    <li className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Database:</span>
                      <span className="font-bold text-slate-900">PostgreSQL (with GIN Indexes)</span>
                    </li>
                    <li className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Operating System:</span>
                      <span className="font-bold text-slate-900">Windows 10/11, Linux or macOS</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-slate-500">Development Tools:</span>
                      <span className="font-bold text-slate-900">VS Code, Git & GitHub, Postman</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'results' && (
            <div className="space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-mono font-bold text-rose-600 uppercase tracking-wider">
                  Slide 8 · Experimental Results & Validation
                </span>
                <h3 className="text-xl font-bold font-display text-slate-900">
                  Documented Platform Performance
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 space-y-2">
                  <div className="text-xs font-bold font-mono text-emerald-800 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Sub-Second Notes Search</span>
                  </div>
                  <p className="text-xs text-emerald-950 leading-relaxed">
                    Smart Notes Search returns keyword matches with exact page numbers in under a second, using Trie-based prefix lookup and inverted indexing.
                  </p>
                </div>

                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 space-y-2">
                  <div className="text-xs font-bold font-mono text-emerald-800 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>ATS Compatibility & Skill Flags</span>
                  </div>
                  <p className="text-xs text-emerald-950 leading-relaxed">
                    Resume Analyzer produces an ATS compatibility score along with a clear list of missing skills for each uploaded student resume.
                  </p>
                </div>

                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 space-y-2">
                  <div className="text-xs font-bold font-mono text-emerald-800 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Graph & Heap Opportunity Ranking</span>
                  </div>
                  <p className="text-xs text-emerald-950 leading-relaxed">
                    Job & Internship Matching ranks opportunities by skill-fit score, computed via graph-based matching and priority queues.
                  </p>
                </div>

                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 space-y-2">
                  <div className="text-xs font-bold font-mono text-emerald-800 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Portfolio & GitHub Repositories</span>
                  </div>
                  <p className="text-xs text-emerald-950 leading-relaxed">
                    Portfolio Showcase pages successfully display student projects and linked GitHub repositories to recruiters and faculty.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'slides' && (
            <div className="space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-mono font-bold text-rose-600 uppercase tracking-wider">
                  Slide 4, 5 & 6 · Academic Context & Motivation
                </span>
                <h3 className="text-xl font-bold font-display text-slate-900">
                  Problem Statement, Literature Survey & Objectives
                </h3>
              </div>

              <div className="space-y-4 text-xs leading-relaxed text-slate-700">
                <div className="p-4 bg-rose-50 rounded-xl border border-rose-200 space-y-2">
                  <h4 className="font-bold text-rose-900 text-sm">Problem Statement (Slide 6)</h4>
                  <p>
                    Students depend on fragmented platforms for notes, resumes, and job search, which wastes time and weakens career preparedness. There is no single system that connects academic performance with career readiness.
                  </p>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="font-bold text-slate-900 text-sm">Literature Survey & Research Gap (Slide 5)</h4>
                  <ul className="space-y-1.5 list-disc list-inside">
                    <li><strong>Existing Job Portals (LinkedIn, Naukri, Indeed):</strong> Focus only on job discovery — they have no link to a student's academic notes or coursework.</li>
                    <li><strong>Resume Screening Tools (Zety, Resume Worded):</strong> Score resumes but work in isolation, disconnected from a student's verified academic record.</li>
                    <li><strong>College LMS Platforms (Moodle, Google Classroom):</strong> Store notes and assignments but offer only basic keyword search with no page-level retrieval.</li>
                    <li><strong>Generic Search Engines:</strong> Not tuned for structured academic content such as PYQs, notes, and assignments.</li>
                    <li><strong>Research Gap:</strong> No existing system unifies fast academic content search, resume evaluation, and job/internship matching using efficient DSA-driven techniques in one platform.</li>
                  </ul>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="font-bold text-slate-900 text-sm">Team 13 Objectives (Slide 6)</h4>
                  <ul className="space-y-1 list-disc list-inside">
                    <li>Build a Smart Notes Search Engine using Tries and Inverted Indexing for fast, page-accurate retrieval.</li>
                    <li>Develop a Resume Analyzer that detects missing skills and computes an ATS compatibility score.</li>
                    <li>Design a Job & Internship Matching module using Graphs and Priority Queues to rank best-fit opportunities.</li>
                    <li>Enable a Portfolio Showcase for projects and GitHub repositories, visible to recruiters and faculty.</li>
                    <li>Ensure the platform is scalable, secure, and responsive using React, FastAPI, and PostgreSQL.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'future' && (
            <div className="space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-mono font-bold text-rose-600 uppercase tracking-wider">
                  Slide 11 · Future Scope & Roadmap
                </span>
                <h3 className="text-xl font-bold font-display text-slate-900">
                  Planned Platform Expansions
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { title: 'AI-Based Chatbot', desc: 'Personalized career and study guidance agent answering student doubts from lecture notes.' },
                  { title: 'Mobile Application', desc: 'Cross-platform mobile app for on-the-go access to notes, resumes, and instant job alerts.' },
                  { title: 'Deeper Job Portal Integration', desc: 'Real-time API sync with LinkedIn, Internshala, and Naukri for campus drive listings.' },
                  { title: 'Recruiter Dashboard Analytics', desc: 'Aggregate talent intelligence showcasing candidate skill trends and departmental performance.' },
                  { title: 'Peer Collaboration & Mentorship', desc: 'Direct alumni messaging and senior mentorship sessions connecting juniors with placed grads.' },
                  { title: 'Video-Based Mock Interviews', desc: 'AI-assisted technical interview simulation with real-time feedback on DSA explanations.' }
                ].map((item, i) => (
                  <div key={i} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
                    <div className="font-bold text-slate-900 flex items-center gap-1.5">
                      <ChevronRight className="w-4 h-4 text-rose-600" />
                      <span>{item.title}</span>
                    </div>
                    <p className="text-slate-600 pl-5">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Campus Career Hub · KL University (KLH) · 25CS2103E Project Spec</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-medium rounded-lg transition-colors cursor-pointer"
          >
            Close Spec
          </button>
        </div>
      </div>
    </div>
  );
};
