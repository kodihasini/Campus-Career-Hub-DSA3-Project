/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ModuleType, AcademicResource, UserProfile } from './types';
import { MOCK_STUDENT_USERS, MOCK_RESOURCES, MOCK_JOBS, UNIVERSITY_INFO } from './data/mockData';
import { Navbar } from './components/Navbar';
import { NotesSearchModule } from './components/NotesSearchModule';
import { ResumeAnalyzerModule } from './components/ResumeAnalyzerModule';
import { JobMatchingModule } from './components/JobMatchingModule';
import { PortfolioShowcaseModule } from './components/PortfolioShowcaseModule';
import { DsaArchitectureModule } from './components/DsaArchitectureModule';
import { DocumentViewerModal } from './components/DocumentViewerModal';
import { ArchitectureSpecModal } from './components/ArchitectureSpecModal';
import { BookOpen, FileText, Briefcase, UserCheck, Cpu, Layers, Sparkles, ShieldCheck } from 'lucide-react';

export default function App() {
  const [activeModule, setActiveModule] = useState<ModuleType>('search');
  const [currentUserId, setCurrentUserId] = useState<string>('user_hasini');
  const [isSpecModalOpen, setIsSpecModalOpen] = useState<boolean>(false);

  // Document Viewer Modal State
  const [viewerDoc, setViewerDoc] = useState<{
    resource: AcademicResource;
    pageNumber: number;
    keyword?: string;
  } | null>(null);

  const currentUser: UserProfile =
    MOCK_STUDENT_USERS.find((u) => u.id === currentUserId) || MOCK_STUDENT_USERS[0];

  const handleOpenResource = (resource: AcademicResource, pageNumber: number, keyword?: string) => {
    setViewerDoc({
      resource,
      pageNumber,
      keyword,
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-rose-500 selection:text-white">
      {/* Top Bar following Top Bar Contract */}
      <Navbar
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        currentUser={currentUser}
        onSelectUser={setCurrentUserId}
        allUsers={MOCK_STUDENT_USERS}
        onOpenSpecModal={() => setIsSpecModalOpen(true)}
      />

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Module Sub-Hero / Quick Context Bar */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 border-b border-slate-200/80 pb-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">{UNIVERSITY_INFO.institution}</span>
            <span>·</span>
            <span className="font-mono">{UNIVERSITY_INFO.courseCode}</span>
            <span>·</span>
            <span className="text-rose-600 font-semibold">{UNIVERSITY_INFO.team}</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-slate-400 hidden sm:inline">Current Student:</span>
            <div className="flex items-center gap-1.5 font-medium text-slate-800">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>{currentUser.name} ({currentUser.rollNumber})</span>
            </div>
          </div>
        </div>

        {/* Dynamic Module Rendering */}
        {activeModule === 'search' && (
          <NotesSearchModule
            resources={MOCK_RESOURCES}
            onOpenResource={handleOpenResource}
          />
        )}

        {activeModule === 'resume' && (
          <ResumeAnalyzerModule
            resources={MOCK_RESOURCES}
            currentUser={currentUser}
            onOpenResource={handleOpenResource}
          />
        )}

        {activeModule === 'jobs' && (
          <JobMatchingModule
            jobs={MOCK_JOBS}
            currentUser={currentUser}
          />
        )}

        {activeModule === 'portfolio' && (
          <PortfolioShowcaseModule
            currentUser={currentUser}
            allUsers={MOCK_STUDENT_USERS}
            onSelectUser={setCurrentUserId}
          />
        )}

        {activeModule === 'architecture' && (
          <DsaArchitectureModule />
        )}
      </main>

      {/* Page Citation Document Viewer Modal */}
      {viewerDoc && (
        <DocumentViewerModal
          resource={viewerDoc.resource}
          targetPageNumber={viewerDoc.pageNumber}
          highlightKeyword={viewerDoc.keyword}
          onClose={() => setViewerDoc(null)}
        />
      )}

      {/* 3rd Year Architecture Defense Specification Modal */}
      <ArchitectureSpecModal
        isOpen={isSpecModalOpen}
        onClose={() => setIsSpecModalOpen(false)}
      />

      {/* Clean Editorial Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-left">
            <div className="font-display font-bold text-slate-900 text-sm">
              Campus Career Hub · 25CS2103E Project
            </div>
            <div>
              Department of CS&IT, {UNIVERSITY_INFO.institution} · Guided by {UNIVERSITY_INFO.mentor}
            </div>
          </div>

          <div className="flex items-center gap-4 flex-wrap justify-center font-mono">
            <span>Hasini K. (2520090209)</span>
            <span>·</span>
            <span>Lavanya L. (2520090009)</span>
            <span>·</span>
            <button
              onClick={() => setIsSpecModalOpen(true)}
              className="text-rose-600 hover:text-rose-700 font-semibold cursor-pointer underline"
            >
              View Defense Spec
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
