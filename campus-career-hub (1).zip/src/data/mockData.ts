import { AcademicResource, JobPosting, StudentProject, UserProfile } from '../types';

export const UNIVERSITY_INFO = {
  institution: 'KL University (KLH Global City Campus)',
  courseCode: '25CS2103E',
  courseName: 'Data Structures and Algorithms - 3',
  team: 'Team 13 | Section 11',
  mentor: 'Mrs. Ch. Anitha, Asst. Professor, CS&IT',
  members: [
    { name: 'K. Hasini', roll: '2520090209', role: 'Full Stack & Graph Algorithms Lead' },
    { name: 'L. Lavanya', roll: '2520090009', role: 'DSA Engine & Inverted Index Lead' }
  ]
};

export const MOCK_STUDENT_USERS: UserProfile[] = [
  {
    id: 'user_hasini',
    name: 'K. Hasini',
    rollNumber: '2520090209',
    department: 'Computer Science & Engineering',
    university: 'KL University (KLH)',
    semester: '6th Semester (3rd Year)',
    cgpa: 9.35,
    avatarUrl: '/src/assets/images/avatar_hasini_1790651047588.jpg',
    role: 'student',
    skills: ['C++', 'Python', 'React', 'FastAPI', 'PostgreSQL', 'Tries', 'Graph Algorithms', 'Docker', 'Git'],
    bio: '3rd year B.Tech CS&IT student specializing in core Data Structures, Graph Theory, and modern full-stack web applications.'
  },
  {
    id: 'user_lavanya',
    name: 'L. Lavanya',
    rollNumber: '2520090009',
    department: 'Computer Science & Information Technology',
    university: 'KL University (KLH)',
    semester: '6th Semester (3rd Year)',
    cgpa: 9.42,
    avatarUrl: '/src/assets/images/avatar_lavanya_1790651061068.jpg',
    role: 'student',
    skills: ['Java', 'C++', 'Data Structures', 'Inverted Indexing', 'FastAPI', 'Algorithms', 'SQL', 'Git', 'OOP'],
    bio: 'Enthusiastic 3rd year student working on high-performance text search engines, Aho-Corasick pattern matching, and ATS systems.'
  }
];

export const MOCK_RESOURCES: AcademicResource[] = [
  {
    id: 'res_dsa_01',
    title: 'Unit 3: Advanced Tree Structures & Trie Indexing',
    courseCode: '25CS2103E',
    courseName: 'Data Structures & Algorithms - 3',
    type: 'Lecture Notes',
    semester: 'Sem 6',
    academicYear: '2025-26',
    totalPages: 48,
    fileSize: '4.2 MB',
    downloadCount: 382,
    tags: ['Trie', 'Prefix Search', 'Radix Tree', 'Suffix Tree', 'String Matching'],
    pages: [
      {
        pageNumber: 7,
        heading: '7.1 Standard Trie Construction & Prefix Retrieval',
        snippet: 'A Trie (pronounced "try") stores associative arrays where keys are usually strings. Lookups take O(L) time where L is key length, independent of tree size. Used in Campus Career Hub for instant sub-second auto-complete.',
        keywords: ['trie', 'prefix', 'lookup', 'complexity', 'autocomplete', 'tree']
      },
      {
        pageNumber: 14,
        heading: '7.4 Inverted Index Architecture & Document Postings',
        snippet: 'Inverted Index maintains a mapping from words to their locations in a document set. In Campus Career Hub, postings list stores (Document_ID, Page_Number, Term_Frequency) enabling instant page-level navigation.',
        keywords: ['inverted index', 'postings', 'page retrieval', 'frequency', 'indexing', 'hash table']
      },
      {
        pageNumber: 22,
        heading: '8.2 Radix Tree Memory Optimization',
        snippet: 'A Radix Tree (compact Trie) merges nodes with single children to save memory overhead in large vocabulary storage. Space complexity shrinks by up to 60% compared to standard alphabet trie nodes.',
        keywords: ['radix', 'compact trie', 'memory', 'optimization', 'prefix']
      }
    ]
  },
  {
    id: 'res_dsa_pyq_2025',
    title: 'Semester End Examination PYQ: 25CS2103E with Solutions',
    courseCode: '25CS2103E',
    courseName: 'Data Structures & Algorithms - 3',
    type: 'PYQ',
    semester: 'Sem 5/6',
    academicYear: '2024-25',
    totalPages: 16,
    fileSize: '1.8 MB',
    downloadCount: 654,
    tags: ['PYQ', 'Dijkstra', 'Bipartite Matching', 'Priority Queue', 'Max-Heap', 'Dynamic Programming'],
    pages: [
      {
        pageNumber: 3,
        heading: 'Question 2(b): Bipartite Graph Matching & Max-Heap Ranking',
        snippet: 'Given a set of students U and jobs V, construct a bipartite graph G=(U,V,E) where edge weight represents qualification ratio. Use a Max-Heap to extract the top-K highest suitability matches in O(K log N) time.',
        keywords: ['bipartite', 'graph matching', 'max-heap', 'priority queue', 'ranking', 'pyq']
      },
      {
        pageNumber: 8,
        heading: 'Question 4(a): Aho-Corasick Multi-Pattern String Searching',
        snippet: 'Compare Knuth-Morris-Pratt (KMP) single pattern matching with Aho-Corasick automaton for multiple dictionary matching in automated resume filtering. Construct the failure links table.',
        keywords: ['pattern matching', 'aho-corasick', 'kmp', 'resume parsing', 'failure links', 'pyq']
      },
      {
        pageNumber: 12,
        heading: 'Question 5: Dynamic Programming on State Graphs',
        snippet: 'Derive state transitions for traveling salesperson and shortest path DAGs with edge relaxation constraints. Tabulation versus Memoization benchmark analysis.',
        keywords: ['dynamic programming', 'memoization', 'tabulation', 'graph', 'dag', 'pyq']
      }
    ]
  },
  {
    id: 'res_dbms_01',
    title: 'PostgreSQL Internals: B+ Tree Indexing & GIN Inverted Indexes',
    courseCode: '25CS2102',
    courseName: 'Database Management Systems',
    type: 'Lecture Notes',
    semester: 'Sem 5',
    academicYear: '2024-25',
    totalPages: 36,
    fileSize: '3.1 MB',
    downloadCount: 290,
    tags: ['PostgreSQL', 'SQL', 'B+ Tree', 'GIN Index', 'Query Optimization'],
    pages: [
      {
        pageNumber: 11,
        heading: '11.3 Generalized Inverted Index (GIN) for Full-Text Search',
        snippet: 'PostgreSQL GIN indexes split text into lexemes and store posting lists. Campus Career Hub leverages GIN tables for sub-second page-accurate keyword search across thousands of academic lecture notes.',
        keywords: ['gin index', 'postgresql', 'full-text search', 'sql', 'database', 'postings']
      },
      {
        pageNumber: 18,
        heading: '12.1 Query Execution Plans & Index Scans',
        snippet: 'Understanding EXPLAIN ANALYZE: Sequential Scan vs Bitmap Index Scan. Utilizing composite indexes on (course_code, page_number) for optimal low-latency filtering.',
        keywords: ['explain analyze', 'index scan', 'query optimization', 'sql', 'postgresql']
      }
    ]
  },
  {
    id: 'res_os_01',
    title: 'Operating Systems: Concurrency, Semaphores & Memory Paging',
    courseCode: '25CS2101',
    courseName: 'Operating Systems',
    type: 'Lecture Notes',
    semester: 'Sem 5',
    academicYear: '2024-25',
    totalPages: 42,
    fileSize: '3.8 MB',
    downloadCount: 410,
    tags: ['Linux', 'Operating Systems', 'Paging', 'Concurrency', 'Semaphores', 'Virtual Memory'],
    pages: [
      {
        pageNumber: 5,
        heading: '5.2 Virtual Memory & Multi-Level Page Tables',
        snippet: 'Virtual memory separates user logical memory from physical memory. Multi-level paging allows hierarchical address translation without allocating contiguous memory tables.',
        keywords: ['virtual memory', 'paging', 'page table', 'operating systems', 'linux']
      },
      {
        pageNumber: 19,
        heading: '7.1 Process Synchronization & Reader-Writer Locks',
        snippet: 'Preventing race conditions using mutexes and counting semaphores. How FastAPI asynchronous worker threads interact with operating system process pools.',
        keywords: ['synchronization', 'semaphores', 'mutex', 'concurrency', 'fastapi', 'threads']
      }
    ]
  },
  {
    id: 'res_cn_01',
    title: 'Computer Networks: REST API Protocols & WebSocket Streaming',
    courseCode: '25CS2104',
    courseName: 'Computer Networks',
    type: 'Assignment',
    semester: 'Sem 6',
    academicYear: '2025-26',
    totalPages: 12,
    fileSize: '1.4 MB',
    downloadCount: 195,
    tags: ['Networking', 'REST API', 'HTTP/2', 'FastAPI', 'TCP/IP'],
    pages: [
      {
        pageNumber: 4,
        heading: 'Task 2: RESTful Endpoint Design for High-Throughput Search',
        snippet: 'Designing idempotent REST APIs with JSON serialization, HTTP status semantics, and caching headers for real-time note search querying.',
        keywords: ['rest api', 'networking', 'fastapi', 'http', 'json', 'endpoints']
      }
    ]
  }
];

export const MOCK_JOBS: JobPosting[] = [
  {
    id: 'job_google_01',
    company: 'Google',
    role: 'Software Engineering Intern (Summer 2026)',
    location: 'Hyderabad / Bengaluru, India',
    type: 'Internship',
    stipend: '₹1,25,000 / month',
    deadline: 'Oct 30, 2026',
    minCgpa: 8.5,
    openings: 8,
    requiredSkills: ['Data Structures', 'Algorithms', 'C++', 'Python', 'OOP'],
    preferredSkills: ['Tries', 'Graph Algorithms', 'System Design', 'Git'],
    description: 'Join the Core Infrastructure or Search team to build distributed indexing engines, perform algorithmic optimizations, and scale services to billions of queries.'
  },
  {
    id: 'job_msft_01',
    company: 'Microsoft',
    role: 'Cloud & Systems Software Engineer Intern',
    location: 'Hyderabad, India',
    type: 'Internship',
    stipend: '₹1,10,000 / month',
    deadline: 'Nov 15, 2026',
    minCgpa: 8.0,
    openings: 12,
    requiredSkills: ['C++', 'Data Structures', 'Algorithms', 'Operating Systems'],
    preferredSkills: ['FastAPI', 'Docker', 'Linux', 'SQL'],
    description: 'Work with the Azure Core Platform engineering team on distributed storage, kernel memory management, and asynchronous query pipelines.'
  },
  {
    id: 'job_amazon_01',
    company: 'Amazon',
    role: 'SDE Intern - Catalog & Search Indexing',
    location: 'Hyderabad, India',
    type: 'Internship',
    stipend: '₹1,00,000 / month',
    deadline: 'Nov 05, 2026',
    minCgpa: 7.5,
    openings: 15,
    requiredSkills: ['Java', 'Data Structures', 'Algorithms', 'SQL'],
    preferredSkills: ['Inverted Indexing', 'FastAPI', 'React', 'Git'],
    description: 'Build fast inverted indexing structures, inverted document frequency algorithms, and high-availability catalog search mechanisms.'
  },
  {
    id: 'job_oracle_01',
    company: 'Oracle',
    role: 'Database Systems & Cloud Intern',
    location: 'Bengaluru, India',
    type: 'Internship',
    stipend: '₹85,000 / month',
    deadline: 'Dec 01, 2026',
    minCgpa: 7.8,
    openings: 10,
    requiredSkills: ['SQL', 'PostgreSQL', 'C++', 'Operating Systems'],
    preferredSkills: ['GIN Index', 'Linux', 'FastAPI'],
    description: 'Optimize relational database engines, implement transactional storage managers, and analyze query execution pipelines.'
  },
  {
    id: 'job_startup_01',
    company: 'Zerodha Tech',
    role: 'Full Stack Web Developer Intern',
    location: 'Bengaluru / Remote',
    type: 'Internship',
    stipend: '₹75,000 / month',
    deadline: 'Oct 25, 2026',
    minCgpa: 7.0,
    openings: 6,
    requiredSkills: ['React', 'TypeScript', 'FastAPI', 'PostgreSQL'],
    preferredSkills: ['Tailwind CSS', 'Docker', 'Git', 'Linux'],
    description: 'Develop low-latency client financial dashboards and high-speed order book visualizers with responsive React architecture.'
  }
];

export const MOCK_PROJECTS: StudentProject[] = [
  {
    id: 'proj_01',
    title: 'Campus Career Hub: DSA-3 Core Engine',
    description: 'Unified academic learning and career readiness web platform built with Trie-based prefix lookup, Inverted Index postings, and Bipartite Graph matching.',
    techStack: ['React', 'FastAPI', 'PostgreSQL', 'Trie', 'Inverted Index', 'Tailwind CSS'],
    githubUrl: 'https://github.com/hasini-lavanya/campus-career-hub',
    liveUrl: 'https://ais-dev-ryjovvl4uktyxcsurpcsfu-1027424542307.asia-southeast1.run.app',
    starsCount: 42,
    forksCount: 14,
    metrics: '<150ms exact page query retrieval across 500+ syllabus pages',
    facultyReview: {
      reviewerName: 'Mrs. Ch. Anitha',
      designation: 'Asst. Professor, Dept of CS&IT, KL University',
      comment: 'Exceptional 3rd-year engineering design. Unifies textbook data structures with practical student placement needs seamlessly.',
      verified: true
    }
  },
  {
    id: 'proj_02',
    title: 'High-Throughput Trie Autocomplete & Suffix Tree Engine',
    description: 'Standalone C++ and WebAssembly engine utilizing compact Radix Trees for $O(L)$ dictionary prefix lookups with memory pool allocation.',
    techStack: ['C++', 'WebAssembly', 'Trie', 'Radix Tree', 'Data Structures'],
    githubUrl: 'https://github.com/hasini-lavanya/radix-prefix-engine',
    starsCount: 28,
    forksCount: 9,
    metrics: '99.8% memory compaction vs naive array trie',
    facultyReview: {
      reviewerName: 'Mrs. Ch. Anitha',
      designation: 'Asst. Professor, Dept of CS&IT, KL University',
      comment: 'Rigorous algorithmic benchmarks conforming to course 25CS2103E curriculum requirements.',
      verified: true
    }
  },
  {
    id: 'proj_03',
    title: 'ATS Resume Skill Parser & Aho-Corasick Matcher',
    description: 'Multi-pattern string matching tool that extracts 120+ technical skill tokens in linear time $O(n + m + z)$ with automatic curriculum gap identification.',
    techStack: ['Python', 'FastAPI', 'Aho-Corasick', 'Regex', 'PostgreSQL'],
    githubUrl: 'https://github.com/hasini-lavanya/ats-skill-matcher',
    starsCount: 35,
    forksCount: 11,
    metrics: 'Scans 10-page resume PDF in under 45ms',
    facultyReview: {
      reviewerName: 'Mrs. Ch. Anitha',
      designation: 'Asst. Professor, Dept of CS&IT, KL University',
      comment: 'Solid engineering application connecting students directly to missing curriculum units.',
      verified: true
    }
  }
];

export const SAMPLE_RESUMES: Record<string, string> = {
  hasini: `K. HASINI
Roll No: 2520090209 | B.Tech CSE (3rd Year), KL University (KLH)
Email: hasini.k@klh.edu.in | GitHub: github.com/hasini-k | CGPA: 9.35 / 10.0

EDUCATION
KL University, Hyderabad — B.Tech Computer Science & Engineering (2023 - 2027)
Coursework: Data Structures & Algorithms, Operating Systems, DBMS, Computer Networks

TECHNICAL SKILLS
Languages: C++, Python, TypeScript, SQL
Frontend & Backend: React, FastAPI, Node.js, Tailwind CSS, REST API
Core Computer Science: Tries, Graph Algorithms, Dynamic Programming, OOP, Inverted Indexing
Tools & Systems: Git, Docker, PostgreSQL, Linux

PROJECTS
Campus Career Hub — Lead Full-Stack & Algorithm Developer (2026)
• Architected a responsive React platform integrating Trie-based sub-second search and Bipartite Graph matching for university placements.
• Engineered Max-Heap priority queue ranking to score student resumes with recruiters, improving match accuracy by 40%.
• Reduced search query latency to <150ms using custom Inverted Index postings lists.

High-Throughput Trie Autocomplete Engine (2025)
• Developed compact Radix Tree in C++ achieving O(L) prefix retrieval.
• Implemented memory pooling to eliminate heap fragmentation during bulk dictionary lookups.

ACHIEVEMENTS & CERTIFICATIONS
• Winner: KLH University Hackathon 2025 (Track: EdTech Solutions)
• Top 5% in 25CS2103E Data Structures and Algorithms III`,

  lavanya: `L. LAVANYA
Roll No: 2520090009 | B.Tech CS&IT (3rd Year), KL University (KLH)
Email: lavanya.l@klh.edu.in | GitHub: github.com/lavanya-l | CGPA: 9.42 / 10.0

EDUCATION
KL University, Hyderabad — B.Tech Computer Science & Information Technology (2023 - 2027)
Relevant Coursework: Advanced Data Structures, Database Systems, Computer Architecture, OOP

TECHNICAL SKILLS
Languages: Java, C++, Python, SQL
Core Competencies: Data Structures, Algorithms, Inverted Indexing, Pattern Matching, Hash Tables
Web & DB: FastAPI, PostgreSQL, REST APIs, HTML5, CSS3, Git
Systems: Linux, Object-Oriented Programming (OOP)

PROJECTS
Campus Career Hub — Inverted Index & Search Lead (2026)
• Implemented an Inverted Indexing engine with document-page coordinate postings lists for instant academic notes retrieval.
• Designed ATS compatibility scorer applying Aho-Corasick multi-pattern search against standard industry role profiles.
• Optimized PostgreSQL GIN indexes to support concurrent multi-term searches across hundreds of PYQ questions.

Distributed Job Matching Engine (2025)
• Created bipartite matching pipeline matching candidate skill sets to corporate requirements.
• Optimized ranking using priority queues to evaluate candidate fit in logarithmic time.

ACADEMIC HONORS
• Academic Excellence Award 2024-25, Department of CS&IT
• CodeChef 4-Star Coder, LeetCode 350+ Problems Solved`
};
