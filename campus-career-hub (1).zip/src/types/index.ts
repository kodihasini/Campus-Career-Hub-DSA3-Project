export type ModuleType = 'search' | 'resume' | 'jobs' | 'portfolio' | 'architecture';

export type UserRole = 'student' | 'recruiter' | 'faculty';

export interface UserProfile {
  id: string;
  name: string;
  rollNumber: string;
  department: string;
  university: string;
  semester: string;
  cgpa: number;
  avatarUrl: string;
  role: UserRole;
  skills: string[];
  bio: string;
}

export interface AcademicResource {
  id: string;
  title: string;
  courseCode: string;
  courseName: string;
  type: 'PYQ' | 'Lecture Notes' | 'Assignment' | 'Lab Manual';
  semester: string;
  academicYear: string;
  totalPages: number;
  tags: string[];
  pages: {
    pageNumber: number;
    heading: string;
    snippet: string;
    keywords: string[];
  }[];
  fileSize: string;
  downloadCount: number;
}

export interface SearchResult {
  resource: AcademicResource;
  matchedPage: number;
  snippet: string;
  score: number;
  matchedKeyword: string;
  algorithmUsed: 'Trie Lookup' | 'Inverted Index Posting';
}

export interface ResumeSkillAnalysis {
  matchedSkills: string[];
  missingSkills: string[];
  atsScore: number;
  actionVerbsCount: number;
  formattingScore: number;
  domainMatchRatio: number;
  feedback: {
    type: 'positive' | 'warning' | 'critical';
    message: string;
    recommendedResource?: {
      courseCode: string;
      title: string;
      page: number;
    };
  }[];
}

export interface JobPosting {
  id: string;
  company: string;
  role: string;
  location: string;
  type: 'Internship' | 'Full-time' | 'Co-op';
  stipend: string;
  deadline: string;
  requiredSkills: string[];
  preferredSkills: string[];
  minCgpa: number;
  openings: number;
  description: string;
  applied?: boolean;
}

export interface JobMatchResult {
  job: JobPosting;
  matchScore: number;
  matchedSkills: string[];
  missingSkills: string[];
  graphEdgeWeight: number;
  heapPriorityRank: number;
  eligible: boolean;
}

export interface StudentProject {
  id: string;
  title: string;
  description: string;
  techStack: string[];
  githubUrl: string;
  liveUrl?: string;
  starsCount: number;
  forksCount: number;
  facultyReview?: {
    reviewerName: string;
    designation: string;
    comment: string;
    verified: boolean;
  };
  metrics: string;
}
