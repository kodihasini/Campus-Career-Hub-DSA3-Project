import { AcademicResource, JobPosting, JobMatchResult, ResumeSkillAnalysis } from '../types';

// ==========================================
// 1. TRIE DATA STRUCTURE (Prefix Search)
// ==========================================
export class TrieNode {
  children: Map<string, TrieNode> = new Map();
  isEndOfWord: boolean = false;
  postings: Array<{ resourceId: string; pageNumber: number }> = [];
  frequency: number = 0;
}

export class TrieSearchEngine {
  root: TrieNode = new TrieNode();

  insert(word: string, resourceId: string, pageNumber: number): void {
    let curr = this.root;
    const cleanWord = word.toLowerCase().trim();
    if (!cleanWord) return;

    for (const char of cleanWord) {
      if (!curr.children.has(char)) {
        curr.children.set(char, new TrieNode());
      }
      curr = curr.children.get(char)!;
    }

    curr.isEndOfWord = true;
    curr.frequency += 1;
    // avoid duplicate page listings for the same word
    if (!curr.postings.some(p => p.resourceId === resourceId && p.pageNumber === pageNumber)) {
      curr.postings.push({ resourceId, pageNumber });
    }
  }

  // Prefix auto-complete lookup: returns matched words and postings
  searchPrefix(prefix: string, limit: number = 6): Array<{ word: string; count: number; postings: Array<{ resourceId: string; pageNumber: number }> }> {
    let curr = this.root;
    const cleanPrefix = prefix.toLowerCase().trim();
    if (!cleanPrefix) return [];

    for (const char of cleanPrefix) {
      if (!curr.children.has(char)) {
        return [];
      }
      curr = curr.children.get(char)!;
    }

    const results: Array<{ word: string; count: number; postings: Array<{ resourceId: string; pageNumber: number }> }> = [];
    this.collectWords(curr, cleanPrefix, results, limit);
    return results;
  }

  private collectWords(
    node: TrieNode,
    currentWord: string,
    results: Array<{ word: string; count: number; postings: Array<{ resourceId: string; pageNumber: number }> }>,
    limit: number
  ): void {
    if (results.length >= limit) return;

    if (node.isEndOfWord) {
      results.push({
        word: currentWord,
        count: node.frequency,
        postings: [...node.postings],
      });
    }

    for (const [char, childNode] of node.children.entries()) {
      this.collectWords(childNode, currentWord + char, results, limit);
      if (results.length >= limit) break;
    }
  }
}

// ==========================================
// 2. INVERTED INDEX DATA STRUCTURE
// ==========================================
export interface InvertedPosting {
  resourceId: string;
  pageNumber: number;
  termFrequency: number;
  heading: string;
  snippet: string;
}

export class InvertedIndexEngine {
  // Hash map: Keyword -> Array of postings with exact page coordinates
  private index: Map<string, InvertedPosting[]> = new Map();

  addPosting(keyword: string, posting: InvertedPosting): void {
    const term = keyword.toLowerCase().trim();
    if (!term) return;

    if (!this.index.has(term)) {
      this.index.set(term, []);
    }

    const list = this.index.get(term)!;
    const existing = list.find(p => p.resourceId === posting.resourceId && p.pageNumber === posting.pageNumber);
    if (existing) {
      existing.termFrequency += posting.termFrequency;
    } else {
      list.push(posting);
    }
  }

  getPostings(term: string): InvertedPosting[] {
    const cleanTerm = term.toLowerCase().trim();
    return this.index.get(cleanTerm) || [];
  }

  getAllTerms(): string[] {
    return Array.from(this.index.keys());
  }

  // Multi-term search with ranking
  searchMultiTerm(query: string): Map<string, { totalScore: number; postings: InvertedPosting[] }> {
    const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
    const results = new Map<string, { totalScore: number; postings: InvertedPosting[] }>();

    for (const term of terms) {
      // Find exact or substring matches in dictionary
      for (const [dictTerm, postings] of this.index.entries()) {
        if (dictTerm.includes(term) || term.includes(dictTerm)) {
          for (const post of postings) {
            const key = `${post.resourceId}#${post.pageNumber}`;
            const existing = results.get(key) || { totalScore: 0, postings: [] };
            existing.totalScore += post.termFrequency * (dictTerm === term ? 3 : 1);
            if (!existing.postings.some(p => p.resourceId === post.resourceId && p.pageNumber === post.pageNumber)) {
              existing.postings.push(post);
            }
            results.set(key, existing);
          }
        }
      }
    }

    return results;
  }
}

// ==========================================
// 3. PRIORITY QUEUE (Max-Heap) for Rankings
// ==========================================
export class MaxHeapPriorityQueue<T> {
  private heap: Array<{ item: T; priority: number }> = [];

  insert(item: T, priority: number): void {
    this.heap.push({ item, priority });
    this.bubbleUp(this.heap.length - 1);
  }

  extractMax(): { item: T; priority: number } | null {
    if (this.heap.length === 0) return null;
    const max = this.heap[0];
    const end = this.heap.pop()!;
    if (this.heap.length > 0) {
      this.heap[0] = end;
      this.sinkDown(0);
    }
    return max;
  }

  size(): number {
    return this.heap.length;
  }

  toArray(): Array<{ item: T; priority: number }> {
    return [...this.heap].sort((a, b) => b.priority - a.priority);
  }

  private bubbleUp(index: number): void {
    const element = this.heap[index];
    while (index > 0) {
      const parentIndex = Math.floor((index - 1) / 2);
      const parent = this.heap[parentIndex];
      if (element.priority <= parent.priority) break;
      this.heap[index] = parent;
      this.heap[parentIndex] = element;
      index = parentIndex;
    }
  }

  private sinkDown(index: number): void {
    const length = this.heap.length;
    const element = this.heap[index];

    while (true) {
      const leftChildIndex = 2 * index + 1;
      const rightChildIndex = 2 * index + 2;
      let swap: number | null = null;

      if (leftChildIndex < length) {
        if (this.heap[leftChildIndex].priority > element.priority) {
          swap = leftChildIndex;
        }
      }

      if (rightChildIndex < length) {
        if (
          (swap === null && this.heap[rightChildIndex].priority > element.priority) ||
          (swap !== null && this.heap[rightChildIndex].priority > this.heap[leftChildIndex].priority)
        ) {
          swap = rightChildIndex;
        }
      }

      if (swap === null) break;
      this.heap[index] = this.heap[swap];
      this.heap[swap] = element;
      index = swap;
    }
  }
}

// ==========================================
// 4. BIPARTITE GRAPH SKILL MATCHING
// ==========================================
export function matchStudentToJobs(
  studentSkills: string[],
  studentCgpa: number,
  jobs: JobPosting[]
): JobMatchResult[] {
  const normalizedStudentSkills = new Set(studentSkills.map(s => s.toLowerCase().trim()));
  const heap = new MaxHeapPriorityQueue<JobMatchResult>();

  jobs.forEach(job => {
    const reqSet = new Set(job.requiredSkills.map(s => s.toLowerCase().trim()));
    const prefSet = new Set(job.preferredSkills.map(s => s.toLowerCase().trim()));

    const matchedReq = job.requiredSkills.filter(s => normalizedStudentSkills.has(s.toLowerCase().trim()));
    const missingReq = job.requiredSkills.filter(s => !normalizedStudentSkills.has(s.toLowerCase().trim()));
    const matchedPref = job.preferredSkills.filter(s => normalizedStudentSkills.has(s.toLowerCase().trim()));

    // Weighted Bipartite Edge Weights:
    // Core requirements carry 70% weight, Preferred 20%, CGPA threshold 10%
    const reqRatio = reqSet.size > 0 ? matchedReq.length / reqSet.size : 1;
    const prefRatio = prefSet.size > 0 ? matchedPref.length / prefSet.size : 0.5;
    const cgpaScore = studentCgpa >= job.minCgpa ? 1.0 : studentCgpa / job.minCgpa;

    const compositeScore = Math.round(
      (reqRatio * 0.7 + prefRatio * 0.2 + cgpaScore * 0.1) * 100
    );

    const eligible = studentCgpa >= job.minCgpa && reqRatio >= 0.4;

    const result: JobMatchResult = {
      job,
      matchScore: compositeScore,
      matchedSkills: [...matchedReq, ...matchedPref],
      missingSkills: missingReq,
      graphEdgeWeight: reqRatio,
      heapPriorityRank: 0,
      eligible,
    };

    heap.insert(result, compositeScore);
  });

  const ranked: JobMatchResult[] = [];
  let rank = 1;
  while (heap.size() > 0) {
    const max = heap.extractMax();
    if (max) {
      max.item.heapPriorityRank = rank++;
      ranked.push(max.item);
    }
  }

  return ranked;
}

// ==========================================
// 5. ATS RESUME ANALYZER (Pattern Matching)
// ==========================================
const COMMON_ACTION_VERBS = [
  'developed', 'engineered', 'implemented', 'designed', 'built',
  'optimized', 'architected', 'reduced', 'increased', 'orchestrated',
  'deployed', 'maintained', 'created', 'solved', 'automated', 'integrated'
];

const TARGET_ROLE_SKILL_SETS: Record<string, string[]> = {
  'SDE Intern': [
    'Data Structures', 'Algorithms', 'C++', 'Java', 'Python',
    'SQL', 'Git', 'OOP', 'Dynamic Programming', 'Tries', 'System Design'
  ],
  'Full Stack Developer': [
    'React', 'TypeScript', 'Node.js', 'FastAPI', 'PostgreSQL',
    'Tailwind CSS', 'REST API', 'Docker', 'Git', 'HTML5', 'CSS3'
  ],
  'AI / ML Engineer': [
    'Python', 'Machine Learning', 'Deep Learning', 'PyTorch',
    'TensorFlow', 'NumPy', 'Pandas', 'Linear Algebra', 'NLP', 'Computer Vision'
  ],
  'Cloud / DevOps Engineer': [
    'Linux', 'Docker', 'Kubernetes', 'AWS', 'GCP',
    'CI/CD', 'Git', 'Bash', 'Networking', 'Terraform'
  ]
};

export function analyzeResumeATS(
  resumeText: string,
  targetRole: string = 'SDE Intern',
  availableResources: AcademicResource[]
): ResumeSkillAnalysis {
  const lowerResume = resumeText.toLowerCase();

  // 1. Detect target skills
  const expectedSkills = TARGET_ROLE_SKILL_SETS[targetRole] || TARGET_ROLE_SKILL_SETS['SDE Intern'];
  const matchedSkills: string[] = [];
  const missingSkills: string[] = [];

  expectedSkills.forEach(skill => {
    const regex = new RegExp(`\\b${skill.toLowerCase().replace('++', '\\+\\+')}\\b`, 'i');
    if (regex.test(lowerResume)) {
      matchedSkills.push(skill);
    } else {
      missingSkills.push(skill);
    }
  });

  // 2. Count action verbs
  let actionVerbsFound = 0;
  COMMON_ACTION_VERBS.forEach(verb => {
    const regex = new RegExp(`\\b${verb}\\b`, 'g');
    const matches = lowerResume.match(regex);
    if (matches) actionVerbsFound += matches.length;
  });

  // 3. Formatting checks
  let formattingScore = 100;
  if (!lowerResume.includes('education') && !lowerResume.includes('b.tech') && !lowerResume.includes('university')) {
    formattingScore -= 20;
  }
  if (!lowerResume.includes('experience') && !lowerResume.includes('projects')) {
    formattingScore -= 25;
  }
  if (!lowerResume.includes('skills')) {
    formattingScore -= 15;
  }
  if (resumeText.length < 300) {
    formattingScore -= 20;
  }

  // 4. Calculate ATS score
  const skillCoverage = expectedSkills.length > 0 ? matchedSkills.length / expectedSkills.length : 0.8;
  const verbFactor = Math.min(actionVerbsFound / 8, 1.0);
  const atsScore = Math.min(
    100,
    Math.round(skillCoverage * 55 + (formattingScore / 100) * 30 + verbFactor * 15)
  );

  // 5. Construct feedback with links to academic resources
  const feedback: ResumeSkillAnalysis['feedback'] = [];

  if (atsScore >= 80) {
    feedback.push({
      type: 'positive',
      message: `Strong alignment with the ${targetRole} qualification benchmark. Key algorithmic proficiencies detected.`,
    });
  } else {
    feedback.push({
      type: 'warning',
      message: `ATS compatibility is currently at ${atsScore}%. Adding ${missingSkills.slice(0, 3).join(', ')} will elevate ranking above 85%.`,
    });
  }

  if (actionVerbsFound < 4) {
    feedback.push({
      type: 'warning',
      message: `Only ${actionVerbsFound} high-impact metric action verbs detected. Use verbs like 'Architected', 'Reduced latency by', 'Optimized'.`,
    });
  } else {
    feedback.push({
      type: 'positive',
      message: `Detected ${actionVerbsFound} impactful engineering action verbs driving measurable outcomes.`,
    });
  }

  // Match missing skills to campus notes/PYQs so students can study immediately!
  missingSkills.slice(0, 3).forEach(skill => {
    // Find an academic resource matching this skill
    const found = availableResources.find(res =>
      res.tags.some(t => t.toLowerCase().includes(skill.toLowerCase())) ||
      res.pages.some(p => p.keywords.some(k => k.toLowerCase().includes(skill.toLowerCase())))
    );

    if (found) {
      const pageMatch = found.pages.find(p =>
        p.keywords.some(k => k.toLowerCase().includes(skill.toLowerCase()))
      ) || found.pages[0];

      feedback.push({
        type: 'critical',
        message: `Missing skill "${skill}" flagged by recruiters. Recommended campus resource available:`,
        recommendedResource: {
          courseCode: found.courseCode,
          title: found.title,
          page: pageMatch.pageNumber,
        }
      });
    }
  });

  return {
    matchedSkills,
    missingSkills,
    atsScore,
    actionVerbsCount: actionVerbsFound,
    formattingScore: Math.max(0, formattingScore),
    domainMatchRatio: skillCoverage,
    feedback,
  };
}
